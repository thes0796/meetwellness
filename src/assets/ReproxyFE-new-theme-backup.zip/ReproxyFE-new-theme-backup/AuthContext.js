'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user_id, setUserId] = useState(null);
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [client_id, setClientId] = useState(null);
  const [singUpEmail, setSingUpEmail] = useState('');
  const [branchId, setBranchId] = useState(null);
  const [user_type, setUserType] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    const user_client_id = localStorage.getItem('client_id');
    const userId = localStorage.getItem('user_id');
    const userType = localStorage.getItem('user_type');

    if (token && role) {
      setUser(token);
      setUserId(userId);
      setRole(role);
      setUserType(userType);
      if (role == 1) setClientId(user_client_id);
    }
  }, []);

  //before made login
  // const login = (token) => {
  //   // Store the token in local storage
  //   localStorage.setItem("token", JSON.stringify(token));
  //   // Decode the token to get user information if needed
  //   // const decodedUser = decodeToken(token);
  //   // Set user data from the token (or decoded user object) to state
  //   setUser(JSON.stringify(token));
  // };

  // recently made login
  const login = (data, role = null) => {
    // Store the token in local storage
    console.log('login called');
    console.log('dataaaa', data);
    localStorage.setItem('user_id', data?.user_id);
    localStorage.setItem('token', data?.access_token);
    localStorage.setItem('role', role);
    localStorage.setItem('user_type', data?.user_type);
    // Decode the token to get user information if needed
    // const decodedUser = decodeToken(token);
    // Set user data from the token (or decoded user object) to state
    setUser(data?.access_token);
    setUserId(data?.user_id);
    // if (role == 1) {
    //   localStorage.setItem('client_id', data?.user_type);
    //   setClientId(localStorage.getItem('client_id'));
    // }
  };

  const logout = () => {
    // Remove the token from local storage
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('user_id');
    // Clear the user data from state
    setUser(null);
    setUserId(null);
    setRole(null);
    if (role == 1) {
      localStorage.removeItem('client_id');
      setClientId(null);
    }
  };

  const decodeToken = (token) => {
    // Decode the token to get user information
    // You can use a library like jwt-decode or implement your own decoding logic
    // For example, using jwt-decode library:
    // import jwtDecode from 'jwt-decode';
    // return jwtDecode(token);

    // For this example, assuming the token contains user data directly (not recommended in real applications)
    // You should validate and decode the token securely in a real application
    const decodedUser = token ? JSON.parse(atob(token.split('.')[1])) : null;
    return decodedUser;
  };

  const addEmailPass = (email, password) => {
    setEmail(email);
    setPassword(password);
  };

  const addRole = (user_role) => {
    setRole(user_role);
  };

  const addBranchId = (branchId) => {
    setBranchId(localStorage.setItem('branch_id', branchId));
  };
  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        email,
        password,
        addEmailPass,
        role,
        addRole,
        client_id,
        singUpEmail,
        setSingUpEmail,
        user_id,
        setUserId,
        branchId,
        setBranchId,
        addBranchId,
        user_type,
        setUserType,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
