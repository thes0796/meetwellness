'use client';

import { useEffect, useState } from 'react';
import { SubmitHandler, Controller } from 'react-hook-form';
import { PiDesktop } from 'react-icons/pi';
import cn from '@/utils/class-names';
import { Form } from '@/components/ui/form';
import { Title, Text } from '@/components/ui/text';
import { Input } from '@/components/ui/input';
import { PiClock, PiEnvelopeSimple } from 'react-icons/pi';
import { Button } from '@/components/ui/button';
import { ProfileHeader } from './profile-header';
import { Password } from '@/components/ui/password';
import HorizontalFormBlockWrapper from './horiozontal-block';
import { fetchClientDetails } from '@/redux/slices/clientsSlice/getClientDetails';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import {
  passwordFormSchema,
  PasswordFormTypes,
} from '@/utils/validators/password-settings.schema';
import toast from 'react-hot-toast';
import { resetPassword } from '@/redux/slices/authSlice/resetPassword';
import { useModal } from '@/app/shared/modal-views/use-modal';
import SendOTPModalView from './modal/send-otp';
import { Modal } from '@/components/ui/modal';
import moment from 'moment';
import { z, ZodError } from 'zod';
import { getUserRoleName } from '@/utils/transforms';
import { fetchServiceProviderProfile } from '@/redux/slices/serviceProviderSlice/getServiceProviderProfile'
import { updateClient } from '@/redux/slices/clientsSlice/updateClient';
import { updateServiceProviderProfile } from '@/redux/slices/serviceProviderSlice/updateServiceProviderProfile'
import { ROLES } from '@/config/constants'
import { updateSubsidiaryContact } from '@/redux/slices/subsidiarySlice/updateSubsidiaryContact'
import {updateClientContact} from '@/redux/slices/clientsSlice/updateClientContact'
import { updateServiceProviderPerson } from '@/redux/slices/serviceProviderSlice/updateSpPersonData'
import { updateWorker } from '@/redux/slices/workersSlice/updateWorker'

const role = getUserRoleName(null)

export default function PasswordSettingsView({
  settings,
}: {
  settings?: PasswordFormTypes;
}) {

  const now = moment();
  const time = now.utc().format('lll');

  const { closeModal, openModal } = useModal();
  const [isModalOpen, SetIsModalOpen] = useState<boolean>(false)
  const [isLoading, setLoading] = useState(false);
  const [reset, setReset] = useState({});
  const dispatch = useAppDispatch();
  const updatedPassword = useAppSelector((state: any) => state?.resetPasswordData)

  const spProfileData = useAppSelector((state) => state?.getSpPersonListData?.serviceProviderPersonListData?.data_list)
  const subsidiaryProfileData = useAppSelector((state) => state?.getSubsidiaryContactDataById?.subsidiaryContactByID)
  const clientContactData = useAppSelector((state) => state?.getClientContact?.clientContact?.rows)
  const workersProfileData: any = useAppSelector((state: any) => state?.allWorkersData?.workersData?.data_list)
  const verifiedOtp = useAppSelector((state) => state?.verifyOtpData)
  const [userAgentData, setUserAgentData] = useState<any>()
  const [adminProfileData, setAdminProfileData] = useState<any>()
  const [clientDetailData, setClientDetailData] = useState<any>()
  const [workerProfileData, setWorkerProfileData] = useState<any>()
  const [isEditMode, setIsEditMode] = useState<boolean>(false)
  const [isVerified, setIsVerified] = useState<boolean>(false)
  const [updateEmailAddress, SetUpdateEmailAddress] = useState<boolean>(false)
  const [updatePassword, SetUpdatePassword] = useState<boolean>(false)
  const [updateUsername, SetUpdateUsername] = useState<boolean>(false)

  const onSubmit: SubmitHandler<PasswordFormTypes> = async (data) => {

      const newData = {
        email_address: clientDetailData?.email_address || adminProfileData?.email_address || subsidiaryProfileData?.email_address || workerProfileData?.email_address,
        new_password: data.newPassword,
        confirm_password: data.confirmedPassword,
        type: 0
      }
      setLoading(true);
      try {
        const resultAction: any = await dispatch(resetPassword(newData))
        if(resetPassword.fulfilled.match(resultAction)) {
          const resetData = resultAction?.payload
          // toast.success(<Text as="b">{resetData?.message_key}</Text>);
          setIsEditMode(false)
          // setLoading(false);
          // if(role == ROLES.ADMIN) {
          //   let new_data = {
          //     email_address: data.email_address
          //   }
          //   try {
          //     const resultAction = await dispatch(updateServiceProviderPerson(new_data));
          //     if(updateServiceProviderPerson.fulfilled.match(resultAction)) {
          //       const editedData = resultAction?.payload
          //       toast.success(<Text as="b">{editedData?.message_key}</Text>);
          //       setLoading(false);
          //       setIsEditMode(true)
          //       setIsVerified(false)
          //     } else {
          //       if(resultAction.payload) {
          //         toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
          //         return
          //       } else {
          //         toast.error('Authentication Failed')
          //         return
          //       }
          //     }
          //   } catch (err) {
          //     console.error("err: ", err)
          //   }
          // }

          // if(role == ROLES.CLIENT) {
          //   let new_data = {
          //     client_contact_id: clientDetailData?.user_id,
          //     email_address: data.email_address
          //   }

          //   try {
          //     const resultAction = await dispatch(updateClientContact(new_data));
          //     if(updateClientContact.fulfilled.match(resultAction)) {
          //       const editedData = resultAction?.payload
          //       toast.success(<Text as="b">{editedData?.message_key}</Text>);
          //       setIsEditMode(true)
          //       setLoading(false);
          //       setIsVerified(false)
          //     } else {
          //       if(resultAction.payload) {
          //         toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
          //         return
          //       } else {
          //         toast.error('Authentication Failed')
          //         return
          //       }
          //     }
          //   } catch (err) {
          //     console.error("err: ", err)
          //   }
          // }

          // if(role === ROLES.WORKER_ADMIN) {
          //   let new_data = {
          //     worker_admin_id: subsidiaryProfileData?.user_id,
          //     email_address: data.email_address,
          //   }
          //   try {
          //     const resultAction = await dispatch(updateSubsidiaryContact(new_data));
          //     if(updateSubsidiaryContact.fulfilled.match(resultAction)) {
          //       const editedData = resultAction?.payload
          //       toast.success(<Text as="b">{editedData?.message_key}</Text>);
          //       setIsEditMode(true)
          //       setLoading(false);
          //       setIsVerified(false)
          //     } else {
          //       if(resultAction.payload) {
          //         toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
          //         return
          //       } else {
          //         toast.error('Authentication Failed')
          //         return
          //       }
          //     }
          //   } catch (err) {
          //     console.error("err: ", err)
          //   }
          // }

          // if(role === ROLES.WORKER) {
          //   let new_data = {
          //     email_address: data.email_address,
          //   }
          //   try {
          //     const resultAction = await dispatch(updateWorker(new_data));
          //     if(updateWorker.fulfilled.match(resultAction)) {
          //       const editedData = resultAction?.payload
          //       toast.success(<Text as="b">{editedData?.message_key}</Text>);
          //       // setIsEditMode(false)
          //       setIsEditMode(true)
          //       setLoading(false)
          //       setIsVerified(false)
          //     } else {
          //       if(resultAction.payload) {
          //         toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
          //         return
          //       } else {
          //         toast.error('Authentication Failed')
          //         return
          //       }
          //     }
          //   } catch (err) {
          //     console.error("err: ", err)
          //   }
          // }
          
        } else {
          setLoading(false);
          if(resultAction.payload) {
            toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
            return
          } else {
            toast.error('Authentication Failed')
            return
          }
        }
      } catch (err) {
        setLoading(false);
        console.error('Err: ', err)
      }
    

    
  };

  useEffect(() => {
    // if(role === "Client") {
    //   dispatch(fetchClientDetails())
    // }
    // if(role === "Admin") {
    //   dispatch(fetchServiceProviderProfile())
    // }
    if(navigator.userAgent) {
      setUserAgentData(navigator.userAgent)
    }
  }, [])

  useEffect(() => {
    if(role === ROLES.ADMIN && !!spProfileData === true) {
      setAdminProfileData(spProfileData[0])
    }
  }, [spProfileData])

  useEffect(() => {
    if(!!adminProfileData === true) {
      setIsEditMode(true)
    }
    
  }, [adminProfileData])

  useEffect(() => {
    if(role === ROLES.CLIENT && !!clientContactData === true) {
      setClientDetailData(clientContactData[0])
      // setIsEditMode(true)
    }
  }, [clientContactData])

  useEffect(() => {
    if(!!clientDetailData === true) {
      setIsEditMode(true)
    }
  }, [clientDetailData])

  useEffect(() => {
    if(!!subsidiaryProfileData === true && Object.keys(subsidiaryProfileData).length > 0) {
      setIsEditMode(true)
    }
  }, [subsidiaryProfileData])

  useEffect(() => {
    if(!!workersProfileData === true && role === ROLES.WORKER) {
      setWorkerProfileData(workersProfileData[0])
    }
  }, [workersProfileData])

  useEffect(() => {
    if(!!workerProfileData === true) {
      setIsEditMode(true)
    }
  }, [workerProfileData])

  return (
    <>

    <Modal 
      isOpen={isModalOpen}
      onClose={closeModal}
      customSize="520px"
      overlayClassName="dark:bg-opacity-40 dark:backdrop-blur-lg"
      containerClassName="dark:bg-gray-100"
      className="z-[9990]"
    >
      <SendOTPModalView  DetailData={role === ROLES.ADMIN ? adminProfileData : role === ROLES.CLIENT ? clientDetailData : role === ROLES.WORKER_ADMIN ? subsidiaryProfileData : workerProfileData} isOpened={SetIsModalOpen} setIsVerified={setIsVerified} SetUpdateEmailAddress={SetUpdateEmailAddress} updateEmailAddress={updateEmailAddress} updatePassword={updatePassword} SetUpdatePassword={SetUpdatePassword} SetUpdateUsername={SetUpdateUsername} updateUsername={updateUsername}/>

    </Modal>
    
      <Form<PasswordFormTypes>
        validationSchema={passwordFormSchema}
        resetValues={reset}
        onSubmit={onSubmit}
        className="@container"
        useFormProps={{
          mode: 'onChange',
          defaultValues: {
            ...settings,
          },
        }}
      >
        {({ register, control, formState: { errors }, getValues, setValue }) => {
          // useEffect(() => {
          //   if(isEditMode && !!adminProfileData === true && Object.keys(adminProfileData).length > 0) {
          //     setValue('email_address', adminProfileData?.email_address)
          //   }
          //   if(isEditMode && !!clientDetailData === true && Object.keys(clientDetailData).length > 0) {
          //     setValue('email_address', clientDetailData?.email_address)
          //   }
          //   if(isEditMode && !!subsidiaryProfileData === true && Object.keys(subsidiaryProfileData).length > 0) {
          //     setValue('email_address', subsidiaryProfileData?.email_address)
          //   }
          //   if(isEditMode && !!workerProfileData === true && Object.keys(workerProfileData).length > 0) {
          //     setValue('email_address', workerProfileData?.email_address)
          //   }
          // }, [isEditMode, clientDetailData, adminProfileData, subsidiaryProfileData, workerProfileData])
          return (
            <>
              <ProfileHeader
                title={clientDetailData?.first_name && clientDetailData?.first_name + ' ' + clientDetailData?.last_name || adminProfileData?.first_name && adminProfileData?.first_name + ' ' + adminProfileData?.last_name || subsidiaryProfileData?.first_name && subsidiaryProfileData?.first_name + ' ' + subsidiaryProfileData?.last_name || workerProfileData?.first_name && workerProfileData?.first_name + ' ' + workerProfileData?.last_name}
                description={clientDetailData?.email_address || adminProfileData?.email_address || subsidiaryProfileData?.email_address || workerProfileData?.email_address}
                image_url={role == ROLES.ADMIN ? adminProfileData?.profile_pic : role == ROLES.CLIENT ? clientDetailData?.profile_pic : role === ROLES.WORKER_ADMIN ? subsidiaryProfileData?.profile_pic : workerProfileData?.profile_pic}
                company_profile={false}
              />

              <div className="mx-auto w-full max-w-screen-2xl">
                <HorizontalFormBlockWrapper
                  title="Email Address"
                  titleClassName="text-base font-medium"
                >

                  {/* {!isVerified ? */}
                  
                    <> 
                      {
                        adminProfileData?.email_address || clientDetailData?.email_address || subsidiaryProfileData?.email_address || workerProfileData?.email_address
                      }
                      <div className='text-center'>
                        <Button className='w-40' onClick={() => {
                          SetIsModalOpen(true)
                          SetUpdateEmailAddress(true)
                        }}>
                          Update Email
                        </Button>
                      </div>
                    </>
                </HorizontalFormBlockWrapper>

                <HorizontalFormBlockWrapper
                  title="Password"
                  titleClassName="text-base font-medium"
                >
                  {/* {!isVerified ?  */}
                    <>
                      <p>******</p>
                      <div className='text-center'>
                        <Button className='w-40' onClick={() => {
                          SetIsModalOpen(true)
                          SetUpdatePassword(true)
                        }}>
                          Update Password
                        </Button>
                      </div>
                    </>
                </HorizontalFormBlockWrapper>

                <HorizontalFormBlockWrapper
                  title="Username"
                  titleClassName="text-base font-medium"
                >
                  {/* {!verifiedOtp?.isSuccess ? ""
                  : */}
                  {/* {!isVerified ?  */}
                    <>
                      <p>{adminProfileData?.user_name || clientDetailData?.user_name || subsidiaryProfileData?.user_name || workerProfileData?.user_name || '******'}</p>
                      <div className='text-center'>
                        <Button className='w-40' onClick={() => {
                          SetIsModalOpen(true)
                          SetUpdateUsername(true)
                        }}>
                          Update Username
                        </Button>
                      </div>
                    </>
                  
                </HorizontalFormBlockWrapper>

                <div className="mt-6 flex w-auto items-center justify-end gap-3">
                  
                </div>
              </div>
            </>
          );
        }}
      </Form>
      <LoggedDevices className="mt-10" clientData={clientDetailData} userAgentData={userAgentData} time={time} />
    </>
  );
}

// Logged devices
function LoggedDevices({ className, clientData, userAgentData, time }: { className?: string; clientData?: any; userAgentData?: any; time?: any }) {
  return (
    <div className={cn('mx-auto w-full max-w-screen-2xl', className)}>
      <div className="border-b border-dashed border-muted">
        <Title as="h2" className="mb-3 text-xl font-bold text-gray-900">
          Where you’re logged in
        </Title>
        <Text className="mb-6 text-sm text-gray-500">
          We’ll alert you via {clientData?.email} if there is any unusual
          activity on your account.
        </Text>
      </div>
      <div className="flex items-center gap-6 border-b border-dashed border-muted py-6">
        <PiDesktop className="h-7 w-7 text-gray-500" />
        <div>
          <div className="mb-2 flex items-center gap-2">
            <Title
              as="h3"
              className="text-base font-medium text-gray-900 dark:text-gray-700"
            >
              {userAgentData}
            </Title>
            {/* <Text
              as="span"
              className="relative hidden rounded-md border border-muted py-1.5 pe-2.5 ps-5 text-xs font-semibold text-gray-900 before:absolute before:start-2.5 before:top-1/2 before:h-1.5 before:w-1.5 before:-translate-y-1/2 before:rounded-full before:bg-green sm:block"
            >
              Active Now
            </Text> */}
          </div>
          <div className="flex items-center gap-2">
            {/* <Text className="text-sm text-gray-500">Melbourne, Australia</Text> */}
            {/* <span className="h-1 w-1 rounded-full bg-gray-600" /> */}
            <Text className="text-sm text-gray-500">{time}</Text>
          </div>
          {/* <Text
            as="span"
            className="relative mt-2 inline-block rounded-md border border-muted py-1.5 pe-2.5 ps-5 text-xs font-semibold text-gray-900 before:absolute before:start-2.5 before:top-1/2 before:h-1.5 before:w-1.5 before:-translate-y-1/2 before:rounded-full before:bg-green sm:hidden"
          >
            Active Now
          </Text> */}
        </div>
      </div>
      {/* <div className="flex items-center gap-6 py-6">
        <PiDesktop className="h-7 w-7 text-gray-500" />
        <div>
          <Title
            as="h3"
            className="mb-2 text-base font-medium text-gray-900 dark:text-gray-700"
          >
            2020 Macbook Air M1
          </Title>
          <div className="flex items-center gap-2">
            <Text className="text-sm text-gray-500">Melbourne, Australia</Text>
            <span className="h-1 w-1 rounded-full bg-gray-600" />
            <Text className="text-sm text-gray-500">22 Jan at 4:20pm</Text>
          </div>
        </div>
      </div> */}
    </div>
  );
}
