'use client';

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Controller, SubmitHandler } from 'react-hook-form';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Text, Title } from '@/components/ui/text';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { useForm, UseFormReturn } from 'react-hook-form';
import {
  sendOtpInput,
  sendOtpSchema,
} from '@/utils/validators/send-otp.schema';
import { sendOtp } from '@/redux/slices/authSlice/sendOtp';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { Modal } from '@/components/ui/modal';
import VerifyOtpModalView from './verfiy-otp';
import { getUserRoleName } from '@/utils/transforms';
import { ROLES } from '@/config/constants'

const role = getUserRoleName(null)
export default function SendOTPModalView({...props}: any) {
  const {updateEmailAddress, updatePassword, updateUsername} = props
  const { closeModal } = useModal();
  const Data = props?.DetailData
  const [reset, setReset] = useState({});
  const [isLoading, setLoading] = useState<boolean>(false);
  const dispatch = useAppDispatch();
  const [verifyModalOpen, setVerifyModalOpen] = useState<boolean>(false)

  const onSubmit: SubmitHandler<sendOtpInput> = async (data) => {
    setLoading(true);
    if(role == ROLES.CLIENT || role == ROLES.ADMIN || role == ROLES.WORKER_ADMIN || role == ROLES.WORKER) {
      const newData = {
        email_address: data.email,
        type: updateEmailAddress ? 2 : 0
      }
      try {
        const resultAction = await dispatch(sendOtp(newData))
        if(sendOtp.fulfilled.match(resultAction)) {
          const resetData = resultAction?.payload
          toast.success(<Text as="b">{resetData?.message_key}</Text>);
          setLoading(false);
          setVerifyModalOpen(true)
          // props.isOpened(false);
        } else {
          setLoading(false);
          if(resultAction.payload) {
            toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
            return
          } else {
            toast.error('Authentication Failed')
            return
          }
        }
      } catch (err) {
        console.error("Error: ", err)
      }
    }

  };

  const { control, register, setValue, formState: { errors } } = useForm<sendOtpInput>({
    // defaultValues: defaultValues,
    mode: 'onChange'
  });

  useEffect(() => {
    if(!!Data === true && Object.keys(Data).length > 0) {
      setValue('email', Data?.email || Data?.email_address)
    }
  }, [Data])

  return (
    <>
    {verifyModalOpen ? 
      <Modal 
        isOpen={verifyModalOpen}
        onClose={closeModal}
        customSize="520px"
        overlayClassName="dark:bg-opacity-40 dark:backdrop-blur-lg"
        containerClassName="dark:bg-gray-100"
        className="z-[9990]"
      >
        <VerifyOtpModalView {...props} setVerifyModalOpen={setVerifyModalOpen} />

      </Modal>
      :
      <div className="m-auto p-6">
        <Title as="h3" className="mb-6 text-lg">
          Verify Email
        </Title>
        <Form<sendOtpInput>
          validationSchema={sendOtpSchema}
          resetValues={reset}
          onSubmit={onSubmit}
        >
          {() => {

            return(
            <>
              <div className="flex flex-col gap-4 text-gray-700">
                {Data?.email || Data?.email_address ? 
                  <span>{Data?.email || Data?.email_address}</span>
                : ""
                }
              </div>
              <div className="mt-8 flex justify-end gap-3">
                <Button
                  className="w-auto"
                  variant="outline"
                  onClick={() => {
                    props.isOpened(false)
                    props.SetUpdateEmailAddress(false)
                    props.SetUpdatePassword(false)
                    props.SetUpdateUsername(false)
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" isLoading={isLoading} className="w-auto">
                  Get OTP
                </Button>
              </div>
            </>
          )}}
        </Form>
      </div>
    }
    </>
  );
}
