'use client';

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Controller, SubmitHandler } from 'react-hook-form';
import { PiClock, PiEnvelopeSimple } from 'react-icons/pi';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Text, Title } from '@/components/ui/text';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Select } from '@/components/ui/select';
import {
  passwordFormSchema,
  PasswordFormTypes,
} from '@/utils/validators/password-settings.schema';
import { Password } from '@/components/ui/password';
import { verifyOtp } from '@/redux/slices/authSlice/verifyOtp';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { sendOtp } from '@/redux/slices/authSlice/sendOtp';
import { resetPassword } from '@/redux/slices/authSlice/resetPassword';


export default function UpdatePasswordModalView({...props}: any) {
  // console.log('props-=-=-=-=-=-', props)

  const {updateEmailAddress, updatePassword, updateUsername} = props
  const { closeModal } = useModal();
  const Data = props?.DetailData
  const [reset, setReset] = useState({});
  const [isLoading, setLoading] = useState<boolean>(false);
  const dispatch = useAppDispatch();

  const onSubmit: SubmitHandler<PasswordFormTypes> = async (data) => {
    setLoading(true);
    const newData = {
      email_address: Data?.email_address,
      new_password: data.newPassword,
      confirm_password: data.confirmedPassword,
      type: 0
    }
    try {
      const resultAction = await dispatch(resetPassword(newData))
      if(resetPassword.fulfilled.match(resultAction)) {
        const resetData = resultAction?.payload
        toast.success(<Text as="b">{resetData?.message_key}</Text>);
        setLoading(false);
        // setVerifyModalOpen(true)
        if(updatePassword) {
          props.setVerifyModalOpen(false)
          props.isOpened(false);
          props.setIsOpenPasswordModal(false)
          props.setIsOpenEmailModal(false)
          props.setIsOpenUsernameModal(false)
          props.SetUpdatePassword(false)
          // props.verifyEmailOTP(data.email)
        }
      } else {
        setLoading(false);
        if(resultAction.payload) {
          toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
          return
        } else {
          toast.error('Authentication Failed')
          return
        }
      }
    } catch (err) {
      console.error("Error: ", err)
    }
  };

  return (
    <>
      
      <div className="m-auto p-6">
        <Title as="h3" className="mb-6 text-lg">
          Update Password
        </Title>
        <Form<PasswordFormTypes>
          validationSchema={passwordFormSchema}
          resetValues={reset}
          onSubmit={onSubmit}
        >
          {({ setValue, register, control, formState: { errors } }) => {
            
            return (
            <>
              <div className="flex flex-col gap-4 text-gray-700">
                {/* <Input
                  type="text"
                  label="Enter Otp"
                  labelClassName="text-sm font-medium text-gray-900"
                  placeholder="Enter OTP"
                  {...register('code')}
                  error={errors.code?.message}
                /> */}

                {/* <FormGroup
                  title="Email"
                  className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                > */}
                        
                    <Controller
                      control={control}
                      name="newPassword"
                      render={({ field: { onChange, value } }) => (
                        <Password
                          placeholder="Enter your password"
                          // helperText={
                          //   getValues().newPassword.length < 8 &&
                          //   'Your current password must be more than 8 characters'
                          // }
                          onChange={onChange}
                          error={errors.newPassword?.message}
                          // disabled={!isVerified}
                        />
                      )}
                    />

                  <Controller
                    control={control}
                    name="confirmedPassword"
                    render={({ field: { onChange, value } }) => (
                      <Password
                        placeholder="Confirm your password"
                        onChange={onChange}
                        error={errors.confirmedPassword?.message}
                        // disabled={!isVerified}
                      />
                    )}
                  />
                {/* </FormGroup> */}
              </div>
              <div className="mt-8 flex justify-end gap-3">
                <Button
                  className="w-auto"
                  variant="outline"
                  onClick={() => {
                    props.isOpened(false)
                    props.SetUpdateEmailAddress(false)
                    props.SetUpdatePassword(false)
                    props.SetUpdateUsername(false)
                    props.setIsOpenPasswordModal(false)
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" isLoading={isLoading} className="w-auto">
                  Apply
                </Button>
              </div>
            </>
          )}}
        </Form>
      </div>
    </>
  );
}
