'use client';

import React, { useEffect, useState, useMemo } from 'react';
import dynamic from 'next/dynamic';
import toast from 'react-hot-toast';
import { SubmitHandler, Controller } from 'react-hook-form';
import { PiClock, PiEnvelopeSimple } from 'react-icons/pi';
import { Form } from '@/components/ui/form';
import { Text } from '@/components/ui/text';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import FormGroup from '@/app/shared/form-group';
import FormFooter from '@/components/form-footer';
import { Select } from '@/components/ui/select';
import {
  defaultValues,
  personalInfoFormSchema,
  PersonalInfoFormTypes,
  personalInfoSPFormSchema,
  personalInfoSubsidiaryFormSchema
  // PersonalInfoSPFormTypes,
  // defaultValuesSP,
} from '@/utils/validators/personal-info.schema';
import { Textarea } from '@/components/ui/textarea';
import Link from 'next/link';
import { PhoneNumber } from '@/components/ui/phone-input';
import AvatarUpload from '@/components/ui/file-upload/avatar-upload';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';

import { fetchClientDetails } from '@/redux/slices/clientsSlice/getClientDetails';
import { updateClient } from '@/redux/slices/clientsSlice/updateClient';
import { getUserRoleName, getLoggedInUserId } from '@/utils/transforms';
import { updateServiceProviderProfile } from '@/redux/slices/serviceProviderSlice/updateServiceProviderProfile'
import { fetchServiceProviderProfile } from '@/redux/slices/serviceProviderSlice/getServiceProviderProfile'
import { editSubsidiary } from '@/redux/slices/subsidiarySlice/editSubsidiary'
import { fetchSubsidiaryContactByID } from '@/redux/slices/subsidiarySlice/getSubsidiaryContactById'
import { z, ZodError } from 'zod';
import {ProfileHeader} from './profile-header';
import { Button } from '@/components/ui/button';
import { routes } from '@/config/routes';
import { ROLES } from '@/config/constants'
import { useForm, UseFormReturn } from 'react-hook-form';

const entityOptions = [
  {
    value: 'sole_trader',
    label: 'Sole Trader',
  },
  {
    value: 'business',
    label: 'Business',
  },
  {
    value: 'non_profit',
    label: 'Non Profit',
  },
  {
    value: 'government',
    label: 'Government',
  },
  {
    value: 'others',
    label: 'Others',
  }
];

const role = getUserRoleName(null)
const schema = role === ROLES.ADMIN ? personalInfoSPFormSchema : role === ROLES.CLIENT ? personalInfoFormSchema : personalInfoSubsidiaryFormSchema
export default function PersonalInfoView() {
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [error, setError] = useState<any>();
  const [reRender, setRerender] = useState<boolean>(false)
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const [phoneDialCode, setPhoneDialCode] = useState<string>('')
  const [mainContactDialCode, setMainContactDialCode] = useState<string>('')
  const [mainContactNumber, setMainContactNumber] = useState<string>('')
  const [adminData, setAdminData] = useState<any>()
  const [openOthers, setOpenOthers] = useState<boolean>(false)
  const [errorOthers, setErrorOthers] = useState<any>()
  const [entityValue, setEntityValue] = useState<any>()
  const [isChangedEntity, setIsChangedEntity] = useState<boolean>(false)
  

  const dispatch = useAppDispatch();
  const clientDetailData: any = useAppSelector((state) => state?.getClientDetailData?.clientDetailsData);
  const spProfileData = useAppSelector((state) => state?.getServiceProviderProfileData?.serviceProviderProfileData?.data_list)
  const subsidiaryProfileData = useAppSelector((state) => state?.getSubsidiaryContactDataById?.subsidiaryContactByID)
  const headerProfileInfo = role == ROLES.ADMIN ? adminData : role == ROLES.CLIENT ? clientDetailData : subsidiaryProfileData?.branch_associate?.branch
  // console.log('subsidiaryProfileData--==-=-=', subsidiaryProfileData)


  

  useEffect(() => {
    if(role === ROLES.CLIENT && reRender) {
      setRerender(false)
      dispatch(fetchClientDetails())
    }
    if(role === ROLES.ADMIN && reRender) {
      setRerender(false)
      dispatch(fetchServiceProviderProfile())
    }
    if(role == ROLES.WORKER_ADMIN && reRender) {
      setRerender(false)
      dispatch(fetchSubsidiaryContactByID(getLoggedInUserId()))
    }
  }, [reRender, dispatch])

  useEffect(() => {
    if(!!clientDetailData === true && Object.keys(clientDetailData).length > 0) {
      setIsEditMode(true)
    }
  }, [clientDetailData, dispatch])

  useEffect(() => {
    if(!!spProfileData === true && spProfileData.length > 0) {
      setIsEditMode(true)
      setAdminData(spProfileData[0])
    }
  }, [spProfileData, dispatch])

  useEffect(() => {
    if(!!subsidiaryProfileData === true && Object.keys(subsidiaryProfileData).length > 0) {
      setIsEditMode(true)
    }
  }, [subsidiaryProfileData, dispatch])

  const isNonEmptyValue = (value: any) => {
    return value && value.trim() !== "";
  }
  const filterEmptyFields = (obj: any) => {
    if(!!obj === true) {
      return Object.fromEntries(
        Object.entries(obj).filter(([key, value]) => isNonEmptyValue(value))
      );
    }
  }

  const filterEmptyAddresses = (data: any) => {
    const addressFields = [
      'billing_address',
      'branch_location',
      'correspondence_address',
      'main_office_location'
    ];
  
    const filteredData = { ...data };
  
    addressFields.forEach(field => {
      const filteredAddress: any = filterEmptyFields(filteredData[field]);
      if (!!filteredAddress === true && Object.keys(filteredAddress).length > 0) {
        filteredData[field] = filteredAddress;
      } else {
        delete filteredData[field];
      }
    });
  
    return filteredData;
  }

  const onSubmit: SubmitHandler<PersonalInfoFormTypes> = async (data) => {
    // if(data?.entity_type?.value == 'others' && !data?.others_value) {
    //   setErrorOthers({required: true, message: 'Others is required.'})
    //   return
    // }

    try {
      // Parse the form data with the Zod schema
      schema.parse(data);

      if(role === ROLES.CLIENT) {
        const filtered_address_data = filterEmptyAddresses(data)
          let new_data = {
            ...(clientDetailData.client_id ? {client_id: clientDetailData.client_id} : {}),
            ...(data.borough ? {borough: data.borough} : {}),
            ...(data.client_name ? {client_name: data.client_name} : {}),
            ...(data.client_reference ? {client_reference: data.client_reference} : {}),
            ...(data.client_unique_name ? {client_unique_name: data.client_unique_name} : {}),
            ...(data.company_logo ? {company_logo: data.company_logo} : {}),
            ...(data.company_number ? {company_number: data.company_number} : {}),
            ...(mainContactNumber ? {main_contact: mainContactNumber} : {}),
            ...(mainContactDialCode ? {main_contact_dial_code: mainContactDialCode} : {}),
            ...(data.street_address ? {street_address: data.street_address} : {}),
            ...(data.town ? {town: data.town} : {}),
            ...(data.trading_name ? {trading_name: data.trading_name} : {}),
            ...(data.vat_number ? {vat_number: data.vat_number} : {}),
            ...(data.website ? {website: data.website} : {}),
            ...(phoneNumber ? {phone_number: phoneNumber} : {}),
            ...(phoneDialCode ? {phone_number_dial_code: phoneDialCode} : {}),
            ...(data.postcode ? {postcode: data.postcode} : {}),
            ...(data.country ? {country: data.country} : {}),
            ...(filtered_address_data.billing_address ? {billing_address: filtered_address_data.billing_address} : {}),
            ...(filtered_address_data.branch_location ? {branch_location: filtered_address_data.branch_location} : {}),
            ...(filtered_address_data.correspondence_address ? { correspondence_address: filtered_address_data.correspondence_address } : {}),
            ...(entityValue && entityValue.value ? {entity_type: entityValue.value} : {}),
            ...(data.legal_form ? {legal_form: data.legal_form} : {}),
            ...(filtered_address_data.main_office_location ? {main_office_location: filtered_address_data.main_office_location} : {}),
            ...(data.other_identifier ? {other_identifier: data.other_identifier} : {}),
            ...(data.others_value ? {others_value: data.others_value} : {}),
            ...(data.registration_number ? {registration_number: data.registration_number} : {}),
            ...(data.sector ? {sector: data.sector} : {}),
            ...(data.tax_id ? {tax_id: data.tax_id} : {}),
            ...(data.business_activities ? {business_activities: data.business_activities} : {}),
            ...(data.email ? {email: data.email} : {}),
            
          }
        try {
          const resultAction = await dispatch(updateClient(new_data));
          if(updateClient.fulfilled.match(resultAction)) {
            const editedData = resultAction?.payload
            toast.success(<Text as="b">{editedData?.message_key}</Text>);
            setIsEditMode(false)
            setRerender(true)
          } else {
            if(resultAction.payload) {
              toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
              return
            } else {
              toast.error('Authentication Failed')
              return
            }
          }
        } catch (err) {
          console.error("err: ", err)
        }
      }


      if(role === ROLES.ADMIN) {
        const filtered_address_data = filterEmptyAddresses(data)
        let new_data ={
            ...(data.company_name ? {company_name: data.company_name} : {}),
            ...(data.company_number ? {company_number: data.company_number} : {}),
            ...(data.vat_number ? {vat_number: data.vat_number} : {}),
            ...(phoneNumber ? {phone_number: phoneNumber} : {}),
            ...(data.company_logo ? {company_logo: data.company_logo} : {}),
            ...(data.website ? {website: data.website} : {}),
            ...(phoneDialCode ? {phone_number_dial_code: phoneDialCode} : {}),
            ...(data.street_address ? {street_address: data.street_address} : {}),
            ...(data.town ? {town: data.town} : {}),
            ...(data.borough ? {borough: data.borough} : {}),
            ...(data.postcode ? {postcode: data.postcode} : {}),
            ...(data.country ? {country: data.country} : {}),
            ...(filtered_address_data.billing_address ? {billing_address: filtered_address_data.billing_address} : {}),
            ...(filtered_address_data.branch_location ? {branch_location: filtered_address_data.branch_location} : {}),
            ...(filtered_address_data.correspondence_address ? { correspondence_address: filtered_address_data.correspondence_address } : {}),
            ...(entityValue && entityValue.value ? {entity_type: entityValue.value} : {}),
            ...(data.legal_form ? {legal_form: data.legal_form} : {}),
            ...(mainContactNumber ? {main_contact: mainContactNumber} : {}),
            ...(mainContactDialCode ? {main_contact_dial_code: mainContactDialCode} : {}),
            ...(filtered_address_data.main_office_location ? {main_office_location: filtered_address_data.main_office_location} : {}),
            ...(data.other_identifier ? {other_identifier: data.other_identifier} : {}),
            ...(data.others_value ? {others_value: data.others_value} : {}),
            ...(data.registration_number ? {registration_number: data.registration_number} : {}),
            ...(data.sector ? {sector: data.sector} : {}),
            ...(data.tax_id ? {tax_id: data.tax_id} : {}),
            ...(data.trading_name ? {trading_name: data.trading_name} : {}),
            ...(data.business_activities ? {business_activities: data.business_activities} : {}),
            ...(data.email ? {email_address: data.email} : {})
          }
        
        
        try {
          const resultAction = await dispatch(updateServiceProviderProfile(new_data));
          if(updateServiceProviderProfile.fulfilled.match(resultAction)) {
            const editedData = resultAction?.payload
            toast.success(<Text as="b">{editedData?.message_key}</Text>);
            setIsEditMode(false)
            setRerender(true)
          } else {
            if(resultAction.payload) {
              toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
              return
            } else {
              toast.error('Authentication Failed')
              return
            }
          }
        } catch (err) {
          console.error("err: ", err)
        }
      }

      if(role == ROLES.WORKER_ADMIN) {
        const filtered_address_data = filterEmptyAddresses(data)
        let new_data = {
            ...(subsidiaryProfileData.branch_associate.branch.branch_id ? {branch_id: subsidiaryProfileData.branch_associate.branch.branch_id} : {}),
            ...(data.branch_name ? {branch_name: data.branch_name} : {}),
            ...(data.company_number ? {company_number: data.company_number} : {}),
            ...(data.vat_number ? {vat_number: data.vat_number} : {}),
            ...(phoneNumber ? {phone_number: phoneNumber} : {}),
            ...(phoneDialCode ? {phone_number_dial_code: phoneDialCode} : {}),
            ...(data.company_logo ? {company_logo: data.company_logo} : {}),
            ...(data.website ? {website: data.website} : {}),
            ...(data.street_address ? {street_address: data.street_address} : {}),
            ...(data.town ? {town: data.town} : {}),
            ...(data.borough ? {borough: data.borough} : {}),
            ...(data.postcode ? {postcode: data.postcode} : {}),
            ...(data.country ? {country: data.country} : {}),
            ...(data.email ? {email: data.email} : {}),
            ...(filtered_address_data.billing_address ? {billing_address: filtered_address_data.billing_address} : {}),
            ...(filtered_address_data.branch_location ? {branch_location: filtered_address_data.branch_location} : {}),
            ...(filtered_address_data.correspondence_address ? { correspondence_address: filtered_address_data.correspondence_address } : {}),
            ...(entityValue && entityValue.value ? {entity_type: entityValue.value} : {}),
            ...(data.legal_form ? {legal_form: data.legal_form} : {}),
            ...(mainContactNumber ? {main_contact: mainContactNumber} : {}),
            ...(mainContactDialCode ? {main_contact_dial_code: mainContactDialCode} : {}),
            ...(filtered_address_data.main_office_location ? {main_office_location: filtered_address_data.main_office_location} : {}),
            ...(data.other_identifier ? {other_identifier: data.other_identifier} : {}),
            ...(data.others_value ? {others_value: data.others_value} : {}),
            ...(data.registration_number ? {registration_number: data.registration_number} : {}),
            ...(data.sector ? {sector: data.sector} : {}),
            ...(data.tax_id ? {tax_id: data.tax_id} : {}),
            ...(data.trading_name ? {trading_name: data.trading_name} : {}),
            ...(data.business_activities ? {business_activities: data.business_activities} : {}),
          }

        try {
          const resultAction = await dispatch(editSubsidiary(new_data));
          if(editSubsidiary.fulfilled.match(resultAction)) {
            const editedData = resultAction?.payload
            toast.success(<Text as="b">{editedData?.message_key}</Text>);
            setIsEditMode(false)
            setRerender(true)
          } else {
            if(resultAction.payload) {
              toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
              return
            } else {
              toast.error('Authentication Failed')
              return
            }
          }
        } catch (err) {
          console.error("err: ", err)
        }

      }

    } catch (error) {
      // Handle validation errors
      if (error instanceof ZodError) {
        const validationErrors: Record<string, string> = {};
        // Iterate over the validation errors
        error.errors.forEach((validationError) => {
          // toast.error(validationError.message)
          // console.error('Validation error:', validationError.message);
          validationErrors[validationError.path.join('.')] = validationError.message
        });
        setError(validationErrors)
      } else {
        console.error('Unknown validation error:', error);
      }
    }
    
    
  };

  const handleChange = (value: any, countryCode: any, e: any) => {
    // Update the phoneNumber state when the input value changes
    const splittedVal = e.target.value.split(' ')
    const concatenatedArray = [].concat(...splittedVal.slice(1))
    const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
    setPhoneNumber(concatenatedString);
    setPhoneDialCode(countryCode.dialCode)
  };

  const handleChangeMainContact = (value: any, countryCode: any, e: any) => {
    // Update the Main Contact Number state when the input value changes
    const splittedVal = e.target.value.split(' ')
    const concatenatedArray = [].concat(...splittedVal.slice(1))
    const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
    setMainContactNumber(concatenatedString);
    setMainContactDialCode(countryCode.dialCode)
  };

  const handleEntityType = ( e: any) => {
    if(e.value === 'others') {
      setOpenOthers(true)
    } else {
      setOpenOthers(false)
      setErrorOthers('')
    }
    setIsChangedEntity(true)
  }

  // const _handleOthersValue = (e: any) => {
  //   if(!!e.target.value === true) {
  //     setErrorOthers('')
  //   } 
  //   if(!!e.target.value === false) {
  //     setErrorOthers({required: true, message: 'Others is required.'})
  //   }
  // }
  
  const getEntityType = (type: any) => {
    switch(type) {
      case 'business':
        return 'Business'
      case 'sole_trader':
        return 'Sole Trader';
      case 'non_profit':
        return 'Non Profit';
      case 'government':
        return 'Government';
      case 'others':
        return 'Others';
    }
  }

  const { control, register, setValue, getValues, formState: { errors } } = useForm<PersonalInfoFormTypes>({
    defaultValues: defaultValues,
    mode: 'onChange'
  });

  useEffect(() => {
    if(isEditMode && !!clientDetailData === true && Object.keys(clientDetailData).length > 0) {
      let fields = ['phone_number_dial_code', 'main_contact_dial_code', 'email', 'client_name', 'client_reference', 'company_number', 'vat_number', 'phone_number', 'trading_name', 'client_unique_name', 'website', 'main_contact', 'address', 'correspondence_address', 'billing_address', 'main_office_location', 'branch_location', 'entity_type', 'registration_number', 'legal_form', 'sector', 'business_activities', 'email', 'tax_id', 'other_identifier', 'others_value'];
      let main_contact_dial_code = ''
      let phone_dial_code = ''
      fields.forEach((field: any) => {
        if(field === 'address') {
          const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          address_fields.forEach((addressValue: any) => {
            const address = clientDetailData[field]
            setValue(addressValue, address[addressValue])
          })
        } else if(field === 'correspondence_address') {
          const c_address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          c_address_fields.forEach((cAddressValue: any) => {
            const cAddress = clientDetailData[field]
            let ca: any = `${field}.${cAddressValue}`
            setValue(ca, cAddress[cAddressValue])
          })
        } else if(field === 'billing_address') {
          const b_address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          b_address_fields.forEach((bAddressValue: any) => {
            const bAddress = clientDetailData[field]
            let ba: any = `${field}.${bAddressValue}`
            setValue(ba, bAddress[bAddressValue])
          })
        } else if(field === "main_office_location") {
          const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          address_fields.forEach((AddressValue: any) => {
            const Address = clientDetailData[field]
            let a: any = `${field}.${AddressValue}`
            setValue(a, Address[AddressValue])
          })
        } else if(field === "branch_location") {
          const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          address_fields.forEach((AddressValue: any) => {
            const Address = clientDetailData[field]
            let a: any = `${field}.${AddressValue}`
            setValue(a, Address[AddressValue])
          })
        } else {
          setValue(field, clientDetailData[field])
          
          if(field === 'phone_number_dial_code') {
            phone_dial_code = clientDetailData[field]
            setPhoneDialCode(clientDetailData[field])
          }
          if(field === 'phone_number') {
            const phone_detail = `${phone_dial_code}${clientDetailData[field]}`
            setValue(field, phone_detail)
            setPhoneNumber(clientDetailData[field])
          }
          if(field == "main_contact_dial_code") {
            main_contact_dial_code = clientDetailData[field]
            setMainContactDialCode(clientDetailData[field])
          }
          if(field == "main_contact") {
            const contact_detail = `${main_contact_dial_code}${clientDetailData[field]}`
            setValue(field, contact_detail)
            setMainContactNumber(clientDetailData[field])
          }

          if(field === 'entity_type') {
            setValue(field, getEntityType(clientDetailData[field]))
            if(clientDetailData[field] == 'others' && isChangedEntity == false) {
              setOpenOthers(true)
            }
            if(isChangedEntity === false) {
              const entity: any = getEntityType(clientDetailData[field])
              setEntityValue(entity)
            }
          }
        }
      })
    }

    if(isEditMode && !!spProfileData === true && spProfileData.length > 0) {
      let fields = ['phone_number_dial_code', 'main_contact_dial_code', 'company_name', 'company_number', 'unique_name', 'vat_number', 'phone_number', 'website', 'address', 'correspondence_address', 'billing_address', 'main_office_location', 'branch_location', 'main_contact', 'entity_type', 'trading_name', 'registration_number', 'legal_form', 'sector', 'business_activities', 'email_address', 'tax_id', 'other_identifier', 'others_value'];
      let phone_dial_code = ''
      let main_dial_code = ''
      fields.forEach((field: any) => {
        if(field === 'address') {
          const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          address_fields.forEach((addressValue: any) => {
            const address = spProfileData[0][field]
            setValue(addressValue, address[addressValue])
          })
        } else if(field === 'correspondence_address') {
          const c_address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          c_address_fields.forEach((cAddressValue: any) => {
            const cAddress = spProfileData[0][field]
            let ca: any = `${field}.${cAddressValue}`
            setValue(ca, cAddress[cAddressValue])
          })
        } else if(field === 'billing_address') {
          const b_address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          b_address_fields.forEach((bAddressValue: any) => {
            const bAddress = spProfileData[0][field]
            let ba: any = `${field}.${bAddressValue}`
            setValue(ba, bAddress[bAddressValue])
          })
        } else if(field === "main_office_location") {
          const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          address_fields.forEach((AddressValue: any) => {
            const Address = spProfileData[0][field]
            let a: any = `${field}.${AddressValue}`
            setValue(a, Address[AddressValue])
          })
        } else if(field === "branch_location") {
          const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
          address_fields.forEach((AddressValue: any) => {
            const Address = spProfileData[0][field]
            let a: any = `${field}.${AddressValue}`
            setValue(a, Address[AddressValue])
          })
        } else {
          setValue(field, spProfileData[0][field])
          
          if(field === 'email_address') {
            setValue('email', spProfileData[0][field])
          }
          if(field === 'phone_number_dial_code') {
            phone_dial_code = spProfileData[0][field]
            setPhoneDialCode(spProfileData[0][field])
          }
          if(field === 'phone_number') {
            const phone_detail = `${phone_dial_code}${spProfileData[0][field]}`
            setValue(field, phone_detail)
            setPhoneNumber(spProfileData[0][field])
          }
          if(field === 'main_contact_dial_code') {
            main_dial_code = spProfileData[0][field]
            setMainContactDialCode(spProfileData[0][field])
          }
          if(field === 'main_contact') {
            const main_contact_detail = `${main_dial_code}${spProfileData[0][field]}`
            setValue(field, main_contact_detail)
            setMainContactNumber(spProfileData[0][field])
          }

          if(field === 'entity_type') {
            setValue(field, getEntityType(spProfileData[0][field]))
            if(spProfileData[0][field] == 'others' && isChangedEntity == false) {
              setOpenOthers(true)
            }
            if(isChangedEntity === false) {
              const entity: any = getEntityType(spProfileData[0][field])
              setEntityValue(entity)
            }
          }
        }
      })
    }

    if(isEditMode && !!subsidiaryProfileData === true && Object.keys(subsidiaryProfileData).length > 0) {
      let fields = ['branch_associate'];
      let phone_dial_code = ''
      let main_dial_code = ''
      fields.forEach((field: any) => {
        if(field == 'branch_associate') {
          const branch_associate_fields: any = ['branch']
          branch_associate_fields.forEach((branch_associate_field: any) => {
            const branch_fields: any = ['phone_number_dial_code', 'main_contact_dial_code', 'branch_name', 'branch_unique_name', 'company_number', 'website', 'vat_number', 'phone_number', 'address', 'email', 'trading_name', 'business_activities', 'company_number', 'entity_type', 'legal_form', 'main_contact', 'main_office_location', 'other_identifier', 'others_value', 'quick_name', 'registration_number', 'sector', 'tax_id', 'vat_number', 'website', 'branch_location', 'correspondence_address', 'billing_address']
            branch_fields.forEach((branch_field: any) => {
              let branchFieldData = subsidiaryProfileData?.branch_associate?.branch[branch_field]
              if(branch_field == 'address') {
                const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
                address_fields.forEach((addressValue: any) => {
                  const address = branchFieldData
                  if(!!address) {
                    setValue(addressValue, address[addressValue])
                  }
                })
              } else if(field === 'correspondence_address') {
                const c_address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
                c_address_fields.forEach((cAddressValue: any) => {
                  const cAddress = branchFieldData
                  let ca: any = `${field}.${cAddressValue}`
                  setValue(ca, cAddress[cAddressValue])
                })
              } else if(field === 'billing_address') {
                const b_address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
                b_address_fields.forEach((bAddressValue: any) => {
                  const bAddress = branchFieldData
                  let ba: any = `${field}.${bAddressValue}`
                  setValue(ba, bAddress[bAddressValue])
                })
              } else if(field === "main_office_location") {
                const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
                address_fields.forEach((AddressValue: any) => {
                  const Address = branchFieldData
                  let a: any = `${field}.${AddressValue}`
                  setValue(a, Address[AddressValue])
                })
              } else if(field === "branch_location") {
                const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town', 'country'];
                address_fields.forEach((AddressValue: any) => {
                  const Address = branchFieldData
                  let a: any = `${field}.${AddressValue}`
                  setValue(a, Address[AddressValue])
                })
              } else {
                setValue(branch_field, branchFieldData)

                if(branch_field === 'phone_number_dial_code') {
                  phone_dial_code = branchFieldData
                  setPhoneDialCode(branchFieldData)
                }
                if(branch_field === 'phone_number') {
                  const phone_detail = `${phone_dial_code}${branchFieldData}`
                  setValue(branch_field, phone_detail)
                  setPhoneNumber(branchFieldData)
                }
                if(branch_field === 'main_contact_dial_code') {
                  main_dial_code = branchFieldData
                  setMainContactDialCode(branchFieldData)
                }
                if(branch_field === 'main_contact') {
                  const main_contact_detail = `${main_dial_code}${branchFieldData}`
                  setValue(field, main_contact_detail)
                  setMainContactNumber(branchFieldData)
                }

                if(branch_field === 'entity_type') {
                  setValue(branch_field, getEntityType(branchFieldData))
                  if(branchFieldData == 'others' && isChangedEntity == false) {
                    setOpenOthers(true)
                  }
                  if(isChangedEntity === false) {
                    const entity: any = getEntityType(branchFieldData)
                    setEntityValue(entity)
                  }
                }
              }
            })
          })
        }
      })
    }
  }, [isEditMode])

  return (
    
    <Form<PersonalInfoFormTypes>
      // validationSchema={personalInfoFormSchema}
      // resetValues={reset}
      onSubmit={onSubmit}
      className="@container"
      useFormProps={{
        mode: 'onChange',
        // defaultValues,
      }}
    >
      {() => {

        return (
          <>
            <ProfileHeader
                title={role == ROLES.ADMIN ? adminData?.company_name : role === ROLES.CLIENT ? clientDetailData?.client_name : 
                  subsidiaryProfileData?.branch_associate?.branch?.branch_name}
                description="Update your photo and personal details."
                image_url={headerProfileInfo?.company_logo}
                company_profile={true}
              >
                <div className="w-full sm:w-auto md:ms-auto">
                  <Link href={routes.profile}>
                    <Button
                      as="span"
                      className="dark:bg-gray-100 dark:text-white dark:focus:bg-gray-100"
                    >
                      View Profile
                    </Button>
                  </Link>
                </div>
            </ProfileHeader>

            <FormGroup
              title="Account Info"
              description="Update your photo and company details here"
              className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
            />

            <div className="mb-10 grid gap-7 divide-y divide-dashed divide-gray-200 @2xl:gap-9 @3xl:gap-11">
              <FormGroup 
                title="Trading Entity"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                  {/* <Controller
                    name="entity_type"
                    // {...register('entity_type')}
                    control={control}
                    render={({ field }) => ( */}
                      <Select
                        {...register('entity_type')}
                        // {...field}
                        options={entityOptions}
                        value={entityValue}
                        onChange={(value: any) => {
                          // console.log('value-=-==-', value)
                          setEntityValue(value)
                          handleEntityType(value)
                          // if (value?.label === 'Others') {
                          //   setOpenOthers(true);
                          // } else {
                          //   setOpenOthers(false);
                          // }
                        }}
                        label="Entity type"
                        // error={errors?.system_access?.message}
                      />
                    {/* )}
                  />  */}
                  {openOthers && 
                    <Input
                      placeholder="Enter others"
                      label="Others value"
                      {...register('others_value')}
                      error={error?.others_value}
                      // onChange={_handleOthersValue}
                      // className="col-span-full"
                    />
                  }
              </FormGroup>
              {/* {role === ROLES.ADMIN &&
                <> */}
                <FormGroup
                  title="Company Details"
                  className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                >
                  {role === ROLES.ADMIN && 
                    <Input
                      placeholder="Enter Company Name"
                      label="Company Name"
                      {...register('company_name')}
                      error={error?.company_name ? error?.company_name : errors?.company_name?.message}
                      // className="col-span-full"
                    />
                  }
                  {role === ROLES.CLIENT && 
                    <>
                      <Input
                        label="Company Name"
                        placeholder="Enter Company Name"
                        {...register('client_name')}
                        error={error?.client_name ? error?.client_name : errors?.client_name?.message}
                        // className="col-span-full"
                      />
                      <Input
                        label="Unique Name"
                        placeholder="Unique Name"
                        {...register('client_unique_name')}
                        error={error?.client_unique_name ? error?.client_unique_name : errors.client_unique_name?.message}
                        // className="col-span-full"
                      />
                      <Input
                        label="Client reference"
                        placeholder="Client reference"
                        {...register('client_reference')}
                        error={error?.client_reference ? error?.client_reference : errors.client_reference?.message}
                        // className="col-span-full"
                      />
                    </>
                  }
                  {role === ROLES.WORKER_ADMIN &&
                    <>
                      <Input
                        label="Company Name"
                        placeholder="Enter Company Name"
                        {...register('branch_name')}
                        error={error?.branch_name ? error?.branch_name : errors?.branch_name?.message}
                        // className="col-span-full"
                      />
                      <Input
                        label="Unique Name"
                        placeholder="Unique Name"
                        {...register('branch_unique_name')}
                        error={error?.branch_unique_name ? error?.branch_unique_name : errors.branch_unique_name?.message}
                        // className="col-span-full"
                      />
                    </>
                  }
                  <Input
                    placeholder="Enter Trading Name"
                    label="Trading Name"
                    {...register('trading_name')}
                    error={error?.trading_name ? error?.trading_name : errors?.trading_name?.message}
                    // className="col-span-full"
                  />

                  <Input
                    placeholder="Enter Registration Number"
                    label="Registration Number"
                    {...register('registration_number')}
                    error={error?.registration_number ? error?.registration_number : errors?.registration_number?.message}
                    // className="col-span-full"
                  />

                  <Input
                    placeholder="Enter Legal Form"
                    label="Legal Form"
                    {...register('legal_form')}
                    error={error?.legal_form ? error?.legal_form : errors?.legal_form?.message}
                    // className="col-span-full"
                  />

                  <Input
                    placeholder="Enter Sector"
                    label="Sector"
                    {...register('sector')}
                    error={error?.sector ? error?.sector : errors?.sector?.message}
                    // className="col-span-full"
                  />

                  <Textarea
                      placeholder="Enter business activities"
                      {...register('business_activities')}
                      error={errors.business_activities?.message}
                      // textareaClassName="h-20"
                      // className="col-span-full"
                      label="Business Activities"
                      rows={3}
                    />
                  
                </FormGroup>

                {/* </>
              } */}

              <FormGroup
                title="Company Logo"
                description="This will be displayed on your company profile."
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <div className="flex flex-col gap-6 @container @3xl:col-span-2">
                  <AvatarUpload
                    name="company_logo"
                    setValue={setValue}
                    getValues={getValues}
                    error={errors?.company_logo?.message as string}
                  />
                </div>
              </FormGroup>

              <FormGroup
                title="Registered Address"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                >
                  <Textarea
                    // label="Address"
                    placeholder="Enter your address"
                    {...register('street_address')}
                    error={errors.street_address?.message}
                    // textareaClassName="h-20"
                    className="col-span-2"
                    label="Street Address"
                    rows={4}
                  />

                  <Input
                    placeholder="Town Name"
                    {...register('town')}
                    error={error?.town || errors.town?.message}
                    className="flex-grow"
                    label="Town"
                  />

                  <Input
                    placeholder="Postcode"
                    {...register('postcode')}
                    error={errors.postcode?.message}
                    className="flex-grow"
                    label="Postcode"
                  />

                  <Input
                    label="Borough"
                    placeholder="Borough"
                    {...register('borough')}
                    error={error?.borough}
                    className="flex-grow"
                  />

                  <Input
                    label="Country"
                    placeholder="Country"
                    {...register('country')}
                    error={error?.country}
                    // className="col-span-full"
                  />

              </FormGroup>

              <FormGroup
                title="Correspondence Address"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                >
                  <Textarea
                    // label="Address"
                    placeholder="Enter your address"
                    {...register('correspondence_address.street_address')}
                    // error={errors.correspondence_address.street_address?.message}
                    // textareaClassName="h-20"
                    className="col-span-2"
                    label="Street Address"
                    rows={4}
                  />

                  <Input
                    placeholder="Town Name"
                    {...register('correspondence_address.town')}
                    // error={error?.town || errors.correspondence_address.town?.message}
                    className="flex-grow"
                    label="Town"
                  />

                  <Input
                    placeholder="Postcode"
                    {...register('correspondence_address.postcode')}
                    error={errors.postcode?.message}
                    className="flex-grow"
                    label="Postcode"
                  />

                  <Input
                    label="Borough"
                    placeholder="Borough"
                    {...register('correspondence_address.borough')}
                    error={error?.borough}
                    className="flex-grow"
                  />

                  <Input
                    label="Country"
                    placeholder="Country"
                    {...register('correspondence_address.country')}
                    error={error?.country}
                    // className="col-span-full"
                  />

              </FormGroup>

              <FormGroup
                title="Billing Address"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                >
                  <Textarea
                    // label="Address"
                    placeholder="Enter your address"
                    {...register('billing_address.street_address')}
                    // error={errors.street_address?.message}
                    // textareaClassName="h-20"
                    className="col-span-2"
                    label="Street Address"
                    rows={4}
                  />

                  <Input
                    placeholder="Town Name"
                    {...register('billing_address.town')}
                    // error={error?.town || errors.town?.message}
                    className="flex-grow"
                    label="Town"
                  />

                  <Input
                    placeholder="Postcode"
                    {...register('billing_address.postcode')}
                    // error={errors.postcode?.message}
                    className="flex-grow"
                    label="Postcode"
                  />

                  <Input
                    label="Borough"
                    placeholder="Borough"
                    {...register('billing_address.borough')}
                    // error={error?.borough}
                    className="flex-grow"
                  />

                  <Input
                    label="Country"
                    placeholder="Country"
                    {...register('billing_address.country')}
                    // error={error?.country}
                    // className="col-span-full"
                  />

              </FormGroup>

              <FormGroup
                title="Contact details"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Input
                  // className="col-span-full"
                  label="Email Address"
                  prefix={
                    <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                  }
                  type="email"
                  placeholder="georgia.young@example.com"
                  {...register('email')}
                  error={errors.email?.message}
                />

                <Input
                  label="Website"
                  type="url"
                  // className="col-span-full"
                  // prefix="https://"
                  // prefixClassName="relative pe-2.5 before:w-[1px] before:h-[38px] before:absolute before:bg-gray-300 before:-top-[9px] before:right-0"
                  placeholder="Enter your website url"
                  {...register('website')}
                  error={error?.website}
                />

                <Controller
                  name="main_contact"
                  control={control}
                  render={({ field: { value, onChange } }) => (
                    <PhoneNumber
                      label="Main Contact"
                      error={error?.main_contact}
                      country="gb"
                      value={value}
                      onChange={handleChangeMainContact}
                      className="rtl:[&>.selected-flag]:right-0"
                      inputClassName="rtl:pr-12"
                      buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                    />
                  )}
                />

                  <Controller
                    name="phone_number"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <PhoneNumber
                        label="Phone Number"
                        error={error?.phone_number}
                        country="gb"
                        value={value}
                        onChange={handleChange}
                        className="rtl:[&>.selected-flag]:right-0"
                        inputClassName="rtl:pr-12"
                        buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                      />
                    )}
                  />

              </FormGroup>

              <FormGroup
                title="Financial details"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Input
                  label="Tax Identification Number"
                  placeholder="Enter Tax Identification number"
                  {...register('tax_id')}
                  error={error?.tax_id ? error?.tax_id : errors.tax_id?.message}
                  // className="col-span-full"
                />

                <Input
                  label="VAT Number"
                  placeholder="VAT number"
                  {...register('vat_number')}
                  error={error?.vat_number ? error?.vat_number : errors.vat_number?.message}
                  // className="col-span-full"
                />

                <Input
                  label="Other Identifier"
                  placeholder="Enter Other Identifier"
                  {...register('other_identifier')}
                  error={error?.other_identifier ? error?.other_identifier : errors.other_identifier?.message}
                  // className="col-span-full"
                />

                <Input
                  label="Company number"
                  placeholder="Company number"
                  {...register('company_number')}
                  error={error?.company_number ? error?.company_number : errors.company_number?.message}
                  // className="col-span-full"
                />
              </FormGroup>

              <FormGroup
                title="Operational details"
                description="Main Office Location"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Textarea
                    // label="Address"
                    placeholder="Enter your address"
                    {...register('main_office_location.street_address')}
                    error={errors.street_address?.message}
                    // textareaClassName="h-20"
                    className="col-span-2"
                    label="Street Address"
                    rows={4}
                  />

                  <Input
                    placeholder="Town Name"
                    {...register('main_office_location.town')}
                    error={error?.town || errors.town?.message}
                    className="flex-grow"
                    label="Town"
                  />

                  <Input
                    placeholder="Postcode"
                    {...register('main_office_location.postcode')}
                    error={errors.postcode?.message}
                    className="flex-grow"
                    label="Postcode"
                  />

                  <Input
                    label="Borough"
                    placeholder="Borough"
                    {...register('main_office_location.borough')}
                    error={error?.borough}
                    className="flex-grow"
                  />

                  <Input
                    label="Country"
                    placeholder="Country"
                    {...register('main_office_location.country')}
                    error={error?.country}
                    // className="col-span-full"
                  />

              </FormGroup>

              <FormGroup
                title=""
                description="Branch Location"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Textarea
                    // label="Address"
                    placeholder="Enter your address"
                    {...register('branch_location.street_address')}
                    error={errors.street_address?.message}
                    // textareaClassName="h-20"
                    className="col-span-2"
                    label="Street Address"
                    rows={4}
                  />

                  <Input
                    placeholder="Town Name"
                    {...register('branch_location.town')}
                    error={error?.town || errors.town?.message}
                    className="flex-grow"
                    label="Town"
                  />

                  <Input
                    placeholder="Postcode"
                    {...register('branch_location.postcode')}
                    error={errors.postcode?.message}
                    className="flex-grow"
                    label="Postcode"
                  />

                  <Input
                    label="Borough"
                    placeholder="Borough"
                    {...register('branch_location.borough')}
                    error={error?.borough}
                    className="flex-grow"
                  />

                  <Input
                    label="Country"
                    placeholder="Country"
                    {...register('branch_location.country')}
                    error={error?.country}
                    // className="col-span-full"
                  />

              </FormGroup>

              {/* {role === ROLES.CLIENT &&
                <FormGroup
                  title="Company Name"
                  className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                >
                  <Input
                    placeholder="Enter Company Name"
                    {...register('client_name')}
                    error={error?.client_name ? error?.client_name : errors?.client_name?.message}
                    className="col-span-full"
                  />
                  
                </FormGroup>
              } */}

              {/* {role === ROLES.WORKER_ADMIN &&
                <FormGroup
                  title="Company Name"
                  className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                >
                  <Input
                    placeholder="Enter Company Name"
                    {...register('branch_name')}
                    error={error?.branch_name ? error?.branch_name : errors?.branch_name?.message}
                    className="col-span-full"
                  />
                  
                </FormGroup>
              } */}

              
              
              {/* {role === ROLES.CLIENT && 
                <FormGroup
                  title="Client Reference"
                  className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                >
                  <Input
                    placeholder="Client reference"
                    {...register('client_reference')}
                    error={error?.client_reference ? error?.client_reference : errors.client_reference?.message}
                    className="col-span-full"
                  />
                </FormGroup>
              } */}
            
              {/* {role === ROLES.CLIENT &&
                <FormGroup
                  title="Trading Name"
                  className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                >
                  <Input
                    placeholder="Trading Name"
                    {...register('trading_name')}
                    error={error?.trading_name ? error?.trading_name : errors.trading_name?.message}
                    className="col-span-full"
                  />
                </FormGroup>
              } */}
              {/* {role === ROLES.CLIENT &&

              <FormGroup
                title="Unique Name"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
               
                <Input
                  placeholder="Unique Name"
                  {...register('client_unique_name')}
                  error={error?.client_unique_name ? error?.client_unique_name : errors.client_unique_name?.message}
                  className="col-span-full"
                />
                
              </FormGroup>
              } */}

              {/* <FormGroup
                title="Website"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Input
                  type="url"
                  className="col-span-full"
                  // prefix="https://"
                  // prefixClassName="relative pe-2.5 before:w-[1px] before:h-[38px] before:absolute before:bg-gray-300 before:-top-[9px] before:right-0"
                  placeholder="Enter your website url"
                  {...register('website')}
                  error={error?.website}
                />
              </FormGroup> */}

              {/* {role === ROLES.CLIENT &&
                <FormGroup
                    title="Main Contact"
                    className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                  >
                  <Controller
                    name="main_contact"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <PhoneNumber
                        // label="Phone Number"
                        error={error?.main_contact}
                        country="gb"
                        value={value}
                        onChange={handleChangeMainContact}
                        className="rtl:[&>.selected-flag]:right-0"
                        inputClassName="rtl:pr-12"
                        buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                      />
                    )}
                  />
                </FormGroup>
              } */}

              {/* {role == ROLES.ADMIN || role == ROLES.WORKER_ADMIN && 

              <FormGroup
                    title="Phone Number"
                    className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                  >
                  <Controller
                    name="phone_number"
                    control={control}
                    render={({ field: { value, onChange } }) => (
                      <PhoneNumber
                        // label="Phone Number"
                        error={error?.phone_number}
                        country="gb"
                        value={value}
                        onChange={handleChange}
                        className="rtl:[&>.selected-flag]:right-0"
                        inputClassName="rtl:pr-12"
                        buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                      />
                    )}
                  />
              </FormGroup>
              } */}


              

              {/* <FormGroup title="Company Address" className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11">
                   
                  <Textarea
                    // label="Address"
                    placeholder="Enter your address"
                    {...register('street_address')}
                    error={error?.street_address}
                    // textareaClassName="h-20"
                    className="col-span-full"
                    rows={5}
                  />
                    
              </FormGroup> */}

              {/* <FormGroup title="Town" className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11">
                  
                <Input
                  placeholder="Town Name"
                  {...register('town')}
                  error={error?.town}
                  className="col-span-full"
                />
              
              </FormGroup> */}

              {/* <FormGroup title="Country" className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11">
              
                <Input
                  placeholder="Country"
                  {...register('country')}
                  error={error?.country}
                  className="col-span-full"
                />
              
              </FormGroup> */}

              {/* <FormGroup title="Borough" className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11">
              
                <Input
                  placeholder="Borough"
                  {...register('borough')}
                  error={error?.borough}
                  className="col-span-full"
                />
              
              </FormGroup> */}

              {/* <FormGroup title="Post Code" className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11">
              
                <Input
                  placeholder="Postcode"
                  {...register('postcode')}
                  error={error?.postcode}
                  className="col-span-full"
                />
              
              </FormGroup> */}

              {/* <FormGroup
                title="Company Number"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Input
                  placeholder="Company number"
                  {...register('company_number')}
                  error={error?.company_number ? error?.company_number : errors.company_number?.message}
                  className="col-span-full"
                />
              </FormGroup> */}

              {/* <FormGroup
                title="VAT Number"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Input
                  placeholder="VAT number"
                  {...register('vat_number')}
                  error={error?.vat_number ? error?.vat_number : errors.vat_number?.message}
                  className="col-span-full"
                />
              </FormGroup> */}

              

              {/* <FormGroup
                title="Role"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Controller
                  control={control}
                  name="role"
                  render={({ field: { value, onChange } }) => (
                    <Select
                      placeholder="Select Role"
                      options={roles}
                      onChange={onChange}
                      value={value}
                      className="col-span-full"
                      getOptionValue={(option) => option.value}
                      displayValue={(selected) =>
                        roles?.find((r) => r.value === selected)?.label ?? ''
                      }
                      error={errors?.role?.message as string}
                    />
                  )}
                />
              </FormGroup> */}

              {/* <FormGroup
                title="Country"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Controller
                  control={control}
                  name="country"
                  render={({ field: { onChange, value } }) => (
                    <Select
                      placeholder="Select Country"
                      options={countries}
                      onChange={onChange}
                      value={value}
                      className="col-span-full"
                      getOptionValue={(option) => option.value}
                      displayValue={(selected) =>
                        countries?.find((con) => con.value === selected)
                          ?.label ?? ''
                      }
                      error={errors?.country?.message as string}
                    />
                  )}
                />
              </FormGroup> */}

              {/* <FormGroup
                title="Timezone"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Controller
                  control={control}
                  name="timezone"
                  render={({ field: { onChange, value } }) => (
                    <Select
                      prefix={<PiClock className="h-6 w-6 text-gray-500" />}
                      placeholder="Select Timezone"
                      options={timezones}
                      onChange={onChange}
                      value={value}
                      className="col-span-full"
                      getOptionValue={(option) => option.value}
                      displayValue={(selected) =>
                        timezones?.find((tmz) => tmz.value === selected)
                          ?.label ?? ''
                      }
                      error={errors?.timezone?.message as string}
                    />
                  )}
                />
              </FormGroup> */}

              {/* <FormGroup
                title="Bio"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <Controller
                  control={control}
                  name="bio"
                  render={({ field: { onChange, value } }) => (
                    <QuillEditor
                      value={value}
                      onChange={onChange}
                      className="@3xl:col-span-2 [&>.ql-container_.ql-editor]:min-h-[100px]"
                      labelClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                    />
                  )}
                />
              </FormGroup> */}

              {/* <FormGroup
                title="Portfolio Projects"
                description="Share a few snippets of your work"
                className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <div className="mb-5 @3xl:col-span-2">
                  <UploadZone
                    name="portfolios"
                    getValues={getValues}
                    setValue={setValue}
                    error={errors?.portfolios?.message as string}
                  />
                </div>
              </FormGroup> */}
            </div>

            <FormFooter
              // isLoading={isLoading}
              altBtnText="Cancel"
              submitBtnText="Save"
            />
          </>
        );
      }}
    </Form>
  );
}
