'use client';

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Controller, SubmitHandler } from 'react-hook-form';
import { PiClock, PiEnvelopeSimple } from 'react-icons/pi';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Text, Title } from '@/components/ui/text';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Select } from '@/components/ui/select';
import {
  verifyEmailInput,
  verifyEmailSchema,
} from '@/utils/validators/verify-email.schema';
import { verifyOtp } from '@/redux/slices/authSlice/verifyOtp';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { sendOtp } from '@/redux/slices/authSlice/sendOtp';


export default function UpdateEmailModalView({...props}: any) {
  // console.log('props-=-=-=-=-=-', props)
  const {updateEmailAddress, updatePassword, updateUsername} = props
  const { closeModal } = useModal();
  const Data = props?.DetailData
  const [reset, setReset] = useState({});
  const [isLoading, setLoading] = useState<boolean>(false);
  const dispatch = useAppDispatch();

  const onSubmit: SubmitHandler<verifyEmailInput> = async (data) => {
    setLoading(true);
    const newData = {
      email_address: data.email,
      type: 3
    }
    try {
      const resultAction = await dispatch(sendOtp(newData))
      if(sendOtp.fulfilled.match(resultAction)) {
        const resetData = resultAction?.payload
        toast.success(<Text as="b">{resetData?.message_key}</Text>);
        // props.isOpened(false);
        setLoading(false);
        // setVerifyModalOpen(true)
        if(updateEmailAddress) {
          props.setIsOpenPasswordModal(false)
          props.setIsOpenEmailModal(false)
          props.setIsOpenUsernameModal(false)
          props.verifyEmailOTP(data.email)
          // props.SetUpdateEmailAddress(false)
        }
      } else {
        setLoading(false);
        if(resultAction.payload) {
          toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
          return
        } else {
          toast.error('Authentication Failed')
          return
        }
      }
    } catch (err) {
      console.error("Error: ", err)
    }
  };

  return (
    <>
      
      <div className="m-auto p-6">
        <Title as="h3" className="mb-6 text-lg">
          Enter New Email
        </Title>
        <Form<verifyEmailInput>
          validationSchema={verifyEmailSchema}
          resetValues={reset}
          onSubmit={onSubmit}
        >
          {({ setValue, register, control, formState: { errors } }) => {
            
            return (
            <>
              <div className="flex flex-col gap-4 text-gray-700">
                {/* <Input
                  type="text"
                  label="Enter Otp"
                  labelClassName="text-sm font-medium text-gray-900"
                  placeholder="Enter OTP"
                  {...register('code')}
                  error={errors.code?.message}
                /> */}

                {/* <FormGroup
                  title="Email"
                  className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                > */}
                        
                  <Input
                    className="col-span-full"
                    prefix={
                      <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                    }
                    type="email"
                    placeholder="georgia.young@example.com"
                    {...register('email')}
                    error={errors.email?.message}
                  />
                
                {/* </FormGroup> */}
              </div>
              <div className="mt-8 flex justify-end gap-3">
                <Button
                  className="w-auto"
                  variant="outline"
                  onClick={() => {
                    props.isOpened(false)
                    props.SetUpdateEmailAddress(false)
                    props.SetUpdatePassword(false)
                    props.SetUpdateUsername(false)
                    props.setIsOpenEmailModal(false)
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" isLoading={isLoading} className="w-auto">
                  Send Otp
                </Button>
              </div>
            </>
          )}}
        </Form>
      </div>
    </>
  );
}
