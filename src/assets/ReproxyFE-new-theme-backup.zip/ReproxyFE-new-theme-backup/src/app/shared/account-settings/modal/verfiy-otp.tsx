'use client';

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Controller, SubmitHandler } from 'react-hook-form';
import { useModal } from '@/app/shared/modal-views/use-modal';
import { Text, Title } from '@/components/ui/text';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form } from '@/components/ui/form';
import { Select } from '@/components/ui/select';
import {
  verifyOtpInput,
  verifyOtpSchema,
} from '@/utils/validators/verify-otp.schema';
import { Modal } from '@/components/ui/modal';
import { verifyOtp } from '@/redux/slices/authSlice/verifyOtp';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import UpdateEmailModalView from './email-address';
import UpdatePasswordModalView from './update-password'
import UpdateUsernameModalView from './update-username'
import { fetchSpPersonListData } from '@/redux/slices/serviceProviderSlice/getSpPersonListData'
import { getUserRoleName, getUserRole, getLoggedInUserId } from '@/utils/transforms';
import { ROLES } from '@/config/constants';
import { fetchClientContact } from '@/redux/slices/clientsSlice/getClientContact'
import { fetchSubsidiaryContactByID } from '@/redux/slices/subsidiarySlice/getSubsidiaryContactById'
import { fetchAllWorkers } from '@/redux/slices/workersSlice/getWorkers'

const role = getUserRoleName(null)

export default function VerifyOtpModalView({...props}: any) {
  const {updateEmailAddress, updatePassword, updateUsername} = props
  const { closeModal } = useModal();
  const Data = props?.DetailData
  const [reset, setReset] = useState({});
  const [isLoading, setLoading] = useState<boolean>(false);
  const dispatch = useAppDispatch();
  const [isOpenEmailModal, setIsOpenEmailModal] = useState<boolean>(false)
  const [isVerifiedEmailOtp, setIsVerifiedEmailOtp] = useState<boolean>(false)
  const [newEmailForVerification, setNewEmailForVerification] = useState<any>()
  // const [isUpdatePasswordModal, setIsUpdatePasswordModal] = useState<boolean>(false)
  const [isOpenPasswordModal, setIsOpenPasswordModal] = useState<boolean>(false)
  const [isOpenUsernameModal, setIsOpenUsernameModal] = useState<boolean>(false)

  const verifyEmailOTP = (data: any) => {
    setIsVerifiedEmailOtp(true)
    setNewEmailForVerification(data)
  }

  // const verifyPasswordOTP = (data: any) => {

  // }

  const onSubmit: SubmitHandler<verifyOtpInput> = async (data) => {
    setLoading(true);
    let Type = 0
    if(updateEmailAddress) {
      Type = 2
      if(isVerifiedEmailOtp) {
        Type = 3
      }
    }
    const newData = {
      ...data,
      type: Type,
      email_address: isVerifiedEmailOtp ? newEmailForVerification : Data?.email || Data?.email_address,
    }
    try {
      const resultAction = await dispatch(verifyOtp(newData))
      if(verifyOtp.fulfilled.match(resultAction)) {
        const resetData = resultAction?.payload
        toast.success(<Text as="b">{resetData?.message_key}</Text>);
        setLoading(false);
        // props.isOpened(false);
        // props.setIsVerified(true)
        if(updateEmailAddress) {
          if(isVerifiedEmailOtp) {
            if(role == ROLES.ADMIN) {
              dispatch(fetchSpPersonListData())
            }
            if(role == ROLES.CLIENT) {
              dispatch(fetchClientContact())
            }
            if(role == ROLES.WORKER_ADMIN) {
              dispatch(fetchSubsidiaryContactByID(getLoggedInUserId()))
            }
            if(role == ROLES.WORKER) {
              dispatch(fetchAllWorkers())
            }
            props.SetUpdateEmailAddress(false)
            setIsOpenEmailModal(false)
            props.isOpened(false)
            setIsVerifiedEmailOtp(false)
            return;
          }
          setIsOpenEmailModal(true)
          // props.isOpened(false);
        }

        if (updatePassword) {
          setIsOpenPasswordModal(true)
          // props.SetUpdatePassword(false)
        }

        if (updateUsername) {
          setIsOpenUsernameModal(true)
          // props.SetUpdateUsername(false)
        }

      } else {
        setLoading(false);
        if(resultAction.payload) {
          toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
          return
        } else {
          toast.error('Authentication Failed')
          return
        }
      }
    } catch (err) {
      console.error("Error: ", err)
    }
  };

  return (
    <>
      {isOpenEmailModal ?
      <Modal 
        isOpen={isOpenEmailModal}
        onClose={closeModal}
        customSize="520px"
        overlayClassName="dark:bg-opacity-40 dark:backdrop-blur-lg"
        containerClassName="dark:bg-gray-100"
        className="z-[9990]"
      >
        <UpdateEmailModalView {...props} setIsOpenEmailModal={setIsOpenEmailModal} verifyEmailOTP={verifyEmailOTP} setIsOpenPasswordModal={setIsOpenPasswordModal} setIsOpenUsernameModal={setIsOpenUsernameModal} />

      </Modal>
      :

      isOpenPasswordModal ? 
        <Modal 
          isOpen={isOpenPasswordModal}
          onClose={closeModal}
          customSize="520px"
          overlayClassName="dark:bg-opacity-40 dark:backdrop-blur-lg"
          containerClassName="dark:bg-gray-100"
          className="z-[9990]"
        >
          <UpdatePasswordModalView {...props} setIsOpenEmailModal={setIsOpenEmailModal} setIsOpenPasswordModal={setIsOpenPasswordModal} setIsOpenUsernameModal={setIsOpenUsernameModal} />

        </Modal>
      :

      isOpenUsernameModal ? 
      
      <Modal 
        isOpen={isOpenUsernameModal}
        onClose={closeModal}
        customSize="520px"
        overlayClassName="dark:bg-opacity-40 dark:backdrop-blur-lg"
        containerClassName="dark:bg-gray-100"
        className="z-[9990]"
      >
        <UpdateUsernameModalView {...props} setIsOpenEmailModal={setIsOpenEmailModal} setIsOpenPasswordModal={setIsOpenPasswordModal} setIsOpenUsernameModal={setIsOpenUsernameModal} />

      </Modal>
      :
      
      <div className="m-auto p-6">
        <Title as="h3" className="mb-6 text-lg">
          Verify Otp
        </Title>
        <Form<verifyOtpInput>
          validationSchema={verifyOtpSchema}
          resetValues={reset}
          onSubmit={onSubmit}
        >
          {({ setValue, register, control, formState: { errors } }) => {
            
            return(
            <>
              <div className="flex flex-col gap-4 text-gray-700">
                <Input
                  type="text"
                  label="Enter Otp"
                  labelClassName="text-sm font-medium text-gray-900"
                  placeholder="Enter OTP"
                  {...register('code')}
                  error={errors.code?.message}
                />
              </div>
              <div className="mt-8 flex justify-end gap-3">
                <Button
                  className="w-auto"
                  variant="outline"
                  onClick={() => {
                    props.isOpened(false)
                    props.SetUpdateEmailAddress(false)
                    props.SetUpdatePassword(false)
                    props.SetUpdateUsername(false)
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" isLoading={isLoading} className="w-auto">
                  Verify Otp
                </Button>
              </div>
            </>
          )}}
        </Form>
      </div>
    }
    </>
  );
}
