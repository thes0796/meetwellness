'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import dynamic from 'next/dynamic';
import { SubmitHandler, Controller } from 'react-hook-form';
import { PiEnvelopeSimple, PiSealCheckFill } from 'react-icons/pi';
import { Form } from '@/components/ui/form';
import { Title, Text } from '@/components/ui/text';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Select } from '@/components/ui/select';
import { routes } from '@/config/routes';
import toast from 'react-hot-toast';
import AvatarUpload from '@/components/ui/file-upload/avatar-upload';
import {
  defaultValues,
  profileFormSchema,
  ProfileFormTypes,
  profileSPFormSchema,
  profileSubsidiaryFormSchema,
} from '@/utils/validators/profile-settings.schema';
import { Textarea } from '@/components/ui/textarea';
import { roles } from '@/data/forms/my-details';
import FormGroup from '@/app/shared/form-group';
import Link from 'next/link';
import FormFooter from '@/components/form-footer';
import UploadZone from '@/components/ui/file-upload/upload-zone';
import { PhoneNumber } from '@/components/ui/phone-input';
import cn from '@/utils/class-names';
import { useLayout } from '@/hooks/use-layout';
import { useBerylliumSidebars } from '@/layouts/beryllium/beryllium-utils';
import { LAYOUT_OPTIONS } from '@/config/enums';
import { fetchClientDetails } from '@/redux/slices/clientsSlice/getClientDetails';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { updateClient } from '@/redux/slices/clientsSlice/updateClient';
import { getUserRoleName, getLoggedInUserId } from '@/utils/transforms';
import { updateServiceProviderProfile } from '@/redux/slices/serviceProviderSlice/updateServiceProviderProfile'
import { fetchServiceProviderProfile } from '@/redux/slices/serviceProviderSlice/getServiceProviderProfile'
import { updateSubsidiaryContact } from '@/redux/slices/subsidiarySlice/updateSubsidiaryContact'
import { fetchClientContact } from '@/redux/slices/clientsSlice/getClientContact'
import { z, ZodError } from 'zod';
import {ProfileHeader} from './profile-header'
import { ROLES } from '@/config/constants'
import { fetchSubsidiaryContactByID } from '@/redux/slices/subsidiarySlice/getSubsidiaryContactById'
import {updateClientContact} from '@/redux/slices/clientsSlice/updateClientContact'
import { fetchSpPersonListData } from '@/redux/slices/serviceProviderSlice/getSpPersonListData'
import { updateServiceProviderPerson } from '@/redux/slices/serviceProviderSlice/updateSpPersonData'
import { updateWorker } from '@/redux/slices/workersSlice/updateWorker'
import { fetchAllWorkers } from '@/redux/slices/workersSlice/getWorkers'
import { useForm, UseFormReturn } from 'react-hook-form';


const role = getUserRoleName(null)

const schema = role === ROLES.ADMIN ? profileSPFormSchema : role === ROLES.CLIENT ? profileFormSchema : profileSubsidiaryFormSchema


export default function ProfileSettingsView() {

  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [reRender, setRerender] = useState<boolean>(false)
  const [error, setError] = useState<any>();
  const [adminData, setAdminData] = useState<any>()
  const [workerData, setWorkerData] = useState<any>()
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const dispatch = useAppDispatch();
  const clientDetailData = useAppSelector((state: any) => state?.getClientDetailData?.clientDetailsData);
  // const spProfileData = useAppSelector((state: any) => state?.getServiceProviderProfileData?.serviceProviderProfileData?.data_list)
  const spProfileData = useAppSelector((state) => state?.getSpPersonListData?.serviceProviderPersonListData?.data_list)
  const subsidiaryProfileData = useAppSelector((state) => state?.getSubsidiaryContactDataById?.subsidiaryContactByID)
  const clientContactData = useAppSelector((state) => state?.getClientContact?.clientContact?.rows)
  const workersProfileData: any = useAppSelector((state: any) => state?.allWorkersData?.workersData?.data_list)
  const [phoneDialCode, setPhoneDialCode] = useState<string>('')
  const [mainContactDialCode, setMainContactDialCode] = useState<string>('')
  const [mainContactNumber, setMainContactNumber] = useState<string>('')
  const [clientData, setClientData] = useState<any>()
  const headerProfileInfo = role == ROLES.ADMIN ? adminData : role === ROLES.CLIENT ? clientData : role === ROLES.WORKER_ADMIN ? subsidiaryProfileData : workerData
  // console.log('workersProfileData-=-=-=-=-=', workerData)
  
  const onSubmit: SubmitHandler<ProfileFormTypes> = async (data) => {
    // console.log('schema.parse(data)-=-=-=-=-', schema.parse(data))
    try {
      // Parse the form data with the Zod schema
      schema.parse(data);


      if(role === ROLES.CLIENT) {
        let new_data;
        if(!!data.profile_pic === true) {
          new_data = {
            client_contact_id: clientData.user_id,
            first_name: data.first_name,
            last_name: data.last_name,
            phone: phoneNumber,
            profile_pic: data.profile_pic,
            phone_dial_code: phoneDialCode,
          }
        } else {
          new_data = {
            client_contact_id: clientData.user_id,
            first_name: data.first_name,
            last_name: data.last_name,
            phone: phoneNumber,
            phone_dial_code: phoneDialCode,
          }
        }
        try {
          const resultAction = await dispatch(updateClientContact(new_data));
          if(updateClientContact.fulfilled.match(resultAction)) {
            const editedData = resultAction?.payload
            toast.success(<Text as="b">{editedData?.message_key}</Text>);
            // setIsEditMode(false)
            setRerender(true)
          } else {
            if(resultAction.payload) {
              toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
              return
            } else {
              toast.error('Authentication Failed')
              return
            }
          }
        } catch (err) {
          console.error("err: ", err)
        }
      } 

      if(role == ROLES.ADMIN) {
        let new_data;
        if(!!data.profile_pic === true) {
           new_data = {
            first_name: data.first_name,
            last_name: data.last_name,
            phone: phoneNumber,
            profile_pic: data.profile_pic,
            phone_dial_code: phoneDialCode,
          }
        } else {
          new_data = {
            first_name: data.first_name,
            last_name: data.last_name,
            phone: phoneNumber,
            phone_dial_code: phoneDialCode,
          }
        }

        try {
          const resultAction = await dispatch(updateServiceProviderPerson(new_data));
          if(updateServiceProviderPerson.fulfilled.match(resultAction)) {
            const editedData = resultAction?.payload
            toast.success(<Text as="b">{editedData?.message_key}</Text>);
            // setIsEditMode(false)
            setRerender(true)
          } else {
            if(resultAction.payload) {
              toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
              return
            } else {
              toast.error('Authentication Failed')
              return
            }
          }
        } catch (err) {
          console.error("err: ", err)
        }
      } 


      if(role == ROLES.WORKER_ADMIN) {
        let new_data;
        if(!!data.profile_pic === true) {
           new_data = {
            worker_admin_id: subsidiaryProfileData?.user_id,
            phone: phoneNumber,
            profile_pic: data.profile_pic,
            first_name: data.first_name,
            last_name: data.last_name,
            phone_dial_code: phoneDialCode,
          }
        } else {
          new_data = {
            worker_admin_id: subsidiaryProfileData?.user_id,
            phone: phoneNumber,
            first_name: data.first_name,
            last_name: data.last_name,
            phone_dial_code: phoneDialCode,
          }
        }

        try {
          const resultAction = await dispatch(updateSubsidiaryContact(new_data));
          if(updateSubsidiaryContact.fulfilled.match(resultAction)) {
            const editedData = resultAction?.payload
            toast.success(<Text as="b">{editedData?.message_key}</Text>);
            // setIsEditMode(false)
            setRerender(true)
          } else {
            if(resultAction.payload) {
              toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
              return
            } else {
              toast.error('Authentication Failed')
              return
            }
          }
        } catch (err) {
          console.error("err: ", err)
        }
      }

      if(role == ROLES.WORKER) {
        let new_data;
        if(!!data.profile_pic === true) {
           new_data = {
            // worker_admin_id: workersProfileData?.user_id,
            phone: phoneNumber,
            profile_pic: data.profile_pic,
            first_name: data.first_name,
            last_name: data.last_name,
            phone_dial_code: phoneDialCode,
          }
        } else {
          new_data = {
            // worker_admin_id: workersProfileData?.user_id,
            phone: phoneNumber,
            first_name: data.first_name,
            last_name: data.last_name,
            phone_dial_code: phoneDialCode,
          }
        }

        try {
          const resultAction = await dispatch(updateWorker(new_data));
          if(updateWorker.fulfilled.match(resultAction)) {
            const editedData = resultAction?.payload
            toast.success(<Text as="b">{editedData?.message_key}</Text>);
            // setIsEditMode(false)
            setRerender(true)
          } else {
            if(resultAction.payload) {
              toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
              return
            } else {
              toast.error('Authentication Failed')
              return
            }
          }
        } catch (err) {
          console.error("err: ", err)
        }
      }

    } catch (error) {
      // Handle validation errors
      if (error instanceof ZodError) {
        const validationErrors: Record<string, string> = {};
        // Iterate over the validation errors
        error.errors.forEach((validationError) => {
          // toast.error(validationError.message)
          // console.error('Validation error:', validationError.message);
          validationErrors[validationError.path.join('.')] = validationError.message
        });
        setError(validationErrors)
      } else {
        console.error('Unknown validation error:', error);
      }
    }
    
    // toast.success(<Text as="b">Profile successfully updated!</Text>);
    // console.log('Profile settings data ->', data);
  };

  

  useEffect(() => {
    if(role === ROLES.CLIENT && reRender) {
      setRerender(false)
      dispatch(fetchClientContact())
    }
    if(role === ROLES.ADMIN && reRender) {
      setRerender(false)
      dispatch(fetchSpPersonListData())
    }
    if(role === ROLES.WORKER_ADMIN && reRender) {
      setRerender(false)
      dispatch(fetchSubsidiaryContactByID(getLoggedInUserId()))
    }
    if(role === ROLES.WORKER && reRender) {
      setRerender(false)
      dispatch(fetchAllWorkers())
    }
  }, [reRender])

  useEffect(() => {
    if(clientContactData && !!clientContactData === true && clientContactData.length > 0) {
      setIsEditMode(true)
      setClientData(clientContactData[0])
    }
  }, [clientContactData])

  useEffect(() => {
    if(!!spProfileData === true && spProfileData.length > 0) {
      setIsEditMode(true)
      setAdminData(spProfileData[0])
    }
  }, [spProfileData])

  useEffect(() => {
    if(!!subsidiaryProfileData === true && Object.keys(subsidiaryProfileData).length > 0) {
      setIsEditMode(true)
    }
  }, [subsidiaryProfileData])

  useEffect(() => {
    if(!!workersProfileData === true && Object.keys(workersProfileData).length > 0) {
      setIsEditMode(true)
      setWorkerData(workersProfileData[0])
    }
  }, [workersProfileData])

  const handleChange = (value: any, countryCode: any, e: any) => {
    // Update the phoneNumber state when the input value changes
    const splittedVal = e.target.value.split(' ')
    const concatenatedArray = [].concat(...splittedVal.slice(1))
    const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
    setPhoneNumber(concatenatedString);
    setPhoneDialCode(countryCode.dialCode)
  };

  const handleChangeMainContact = (value: any, countryCode: any, e: any) => {
    // Update the Main Contact Number state when the input value changes
    const splittedVal = e.target.value.split(' ')
    const concatenatedArray = [].concat(...splittedVal.slice(1))
    const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
    setMainContactNumber(concatenatedString);
    setMainContactDialCode(countryCode.dialCode)
  };

  const { control, register, setValue, getValues, formState: { errors } } = useForm<ProfileFormTypes>({
    defaultValues: defaultValues,
    mode: 'onChange'
  });

  useEffect(() => {
    if(isEditMode && !!clientData === true && Object.keys(clientData).length > 0) {
      const fields = ['phone_dial_code', 'first_name', 'last_name', 'phone'];
      let phone_dial_code = ''
      fields.forEach((field: any) => {
        setValue(field, clientData[field])
        if(field == "phone_dial_code") {
          phone_dial_code = clientData[field]
          setPhoneDialCode(clientData[field])
        }
        if(field === "phone") {
          const phone_detail = `${phone_dial_code}${clientData[field]}`
          setValue(field, phone_detail)
          setPhoneNumber(clientData[field])
        }
      })
    }

    if(isEditMode &&  !!spProfileData === true && spProfileData.length > 0) {
      const fields = ['phone_dial_code', 'first_name', 'last_name', 'phone'];
      let phone_dial_code = ''
      fields.forEach((field: any) => {
        setValue(field, spProfileData[0][field])
        if(field == "phone_dial_code") {
          phone_dial_code = spProfileData[0][field]
          setPhoneDialCode(spProfileData[0][field])
        }
        if(field === "phone") {
          const phone_detail = `${phone_dial_code}${spProfileData[0][field]}`
          setValue(field, phone_detail)
          setPhoneNumber(spProfileData[0][field])
        }
      })
    }

    if(isEditMode && !!subsidiaryProfileData === true && Object.keys(subsidiaryProfileData).length > 0) {
      const fields = ['phone_dial_code', 'first_name', 'last_name', 'phone'];
      let phone_dial_code = ''
      fields.forEach((field: any) => {
        setValue(field, subsidiaryProfileData[field])
        if(field == "phone_dial_code") {
          phone_dial_code = subsidiaryProfileData[field]
          setPhoneDialCode(subsidiaryProfileData[field])
        }
        if(field === "phone") {
          const phone_detail = `${phone_dial_code}${subsidiaryProfileData[field]}`
          setValue(field, phone_detail)
          setPhoneNumber(subsidiaryProfileData[field])
        }
      })
    }

    if(isEditMode && !!workerData === true && Object.keys(workerData).length > 0) {
      const fields = ['phone_dial_code', 'first_name', 'last_name', 'phone'];
      let phone_dial_code = ''
      fields.forEach((field: any) => {
        setValue(field, workerData[field])
        if(field == "phone_dial_code") {
          phone_dial_code = workerData[field]
          setPhoneDialCode(workerData[field])
        }
        if(field === "phone") {
          const phone_detail = `${phone_dial_code}${workerData[field]}`
          setValue(field, phone_detail)
          setPhoneNumber(workerData[field])
        }
      })
    }


  }, [isEditMode])


  return (
    <>
      <Form<ProfileFormTypes>
        // validationSchema={profileFormSchema}
        onSubmit={onSubmit}
        className="@container"
        useFormProps={{
          mode: 'onChange',
          defaultValues,
        }}
      >
        {() => {

          return (
            <>
              <ProfileHeader
                title={role === ROLES.ADMIN ? adminData?.first_name && adminData?.first_name + ' ' + adminData?.last_name : role === ROLES.CLIENT ? clientData?.first_name && clientData?.first_name + ' ' + clientData?.last_name : role === ROLES.WORKER_ADMIN ? subsidiaryProfileData?.first_name + ' ' + subsidiaryProfileData?.last_name : workerData?.first_name + ' ' + workerData?.last_name}
                description="Update your photo and personal details."
                image_url={headerProfileInfo?.profile_pic}
                company_profile={false}
              >
                <div className="w-full sm:w-auto md:ms-auto">
                  <Link href={routes.profile}>
                    <Button
                      as="span"
                      className="dark:bg-gray-100 dark:text-white dark:focus:bg-gray-100"
                    >
                      View Profile
                    </Button>
                  </Link>
                </div>
              </ProfileHeader>

              <div className="mx-auto mb-10 grid w-full max-w-screen-2xl gap-7 divide-y divide-dashed divide-gray-200 @2xl:gap-9 @3xl:gap-11">
             
                {/* {role == ROLES.WORKER_ADMIN || role == ROLES.CLIENT || role == ROLES.ADMIN &&  */}
                <>
                  <FormGroup
                    title="First Name"
                    className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                  >
                  
                    <Input
                      className="col-span-full"
                      placeholder="Name"
                      prefixClassName="relative pe-2.5 before:w-[1px] before:h-[38px] before:absolute before:bg-gray-300 before:-top-[9px] before:right-0"
                      {...register('first_name')}
                      error={error?.first_name}
                    />
                  
                  </FormGroup>

                  <FormGroup
                    title="Last Name"
                    className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                  >
                  
                    <Input
                      className="col-span-full"
                      placeholder="Last Name"
                      prefixClassName="relative pe-2.5 before:w-[1px] before:h-[38px] before:absolute before:bg-gray-300 before:-top-[9px] before:right-0"
                      {...register('last_name')}
                      error={error?.last_name}
                    />
                  
                  </FormGroup>

                  <FormGroup
                      title="Phone Number"
                      className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                    >
                    <Controller
                      name="phone"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <PhoneNumber
                          // label="Phone Number"
                          error={error?.phone}
                          country="gb"
                          value={value}
                          onChange={handleChange}
                          className="col-span-full"
                          inputClassName="rtl:pr-12"
                          buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                        />
                      )}
                    />
                  </FormGroup>
                </>
                {/* } */}


                <FormGroup
                  title="Profile Photo"
                  description="This will be displayed on your profile."
                  className="pt-7 @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
                >
                  <div className="col-span-2 flex flex-col items-center gap-4 @xl:flex-row">
                    <AvatarUpload
                      name="profile_pic"
                      setValue={setValue}
                      getValues={getValues}
                      error={error?.profile_pic as string}
                    />
                  </div>
                </FormGroup>

              </div>
              <FormFooter
                // isLoading={isLoading}
                altBtnText="Cancel"
                submitBtnText="Save"
              />
            </>
          );
        }}
      </Form>
    </>
  );
}
