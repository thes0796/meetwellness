'use client';

import type { CalendarEvent } from '@/types';
import dayjs from 'dayjs';
import { useCallback, useMemo, useState } from 'react';
import { Calendar, dayjsLocalizer } from 'react-big-calendar';
import EventForm from '@/app/shared/event-calendar/event-form';
import DetailsEvents from '@/app/shared/event-calendar/details-event';
import { useModal } from '@/app/shared/modal-views/use-modal';
import useEventCalendar from '@/hooks/use-event-calendar';
import cn from '@/utils/class-names';
import { useRouter } from 'next/navigation';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const localizer = dayjsLocalizer(dayjs);

// rbc-active -> black button active
const calendarToolbarClassName =
  '[&_.rbc-toolbar_.rbc-toolbar-label]:whitespace-nowrap [&_.rbc-toolbar_.rbc-toolbar-label]:my-2 [&_.rbc-toolbar]:flex [&_.rbc-toolbar]:flex-col [&_.rbc-toolbar]:items-center @[56rem]:[&_.rbc-toolbar]:flex-row [&_.rbc-btn-group_button:hover]:bg-gray-300 [&_.rbc-btn-group_button]:duration-200 [&_.rbc-btn-group_button.rbc-active:hover]:bg-gray-600 dark:[&_.rbc-btn-group_button.rbc-active:hover]:bg-gray-300 [&_.rbc-btn-group_button.rbc-active:hover]:text-gray-50 dark:[&_.rbc-btn-group_button.rbc-active:hover]:text-gray-900';

interface User {
  id: number;
  name: string;
}

export default function EventCalendarView() {
  const router = useRouter();
  const { events } = useEventCalendar();
  const { openModal } = useModal();
  const userList: User[] = [
    { id: 1, name: 'Username 1' },
    { id: 2, name: 'Username 2' },
    { id: 3, name: 'Username 3' },
    { id: 4, name: 'Username 4' },
    { id: 5, name: 'Username 5' },
    { id: 6, name: 'Username 6' },
    { id: 7, name: 'Username 7' },
    { id: 8, name: 'Username 8' },
    { id: 9, name: 'Username 9' },
    { id: 10, name: 'Username 10' },
    // Add more users as needed
  ];
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedUser, setSelectedUser] = useState<User | null>(userList[0]);
  const [currentDate, setCurrentDate] = useState(
    new Date(selectedYear, selectedMonth)
  );

  const handleMonthYearChange = useCallback((month: number, year: number) => {
    setSelectedMonth(month);
    setSelectedYear(year);

    // Set currentDate to the first day of the selected month
    setCurrentDate(new Date(year, month));
  }, []);

  const handleNavigate = useCallback((newDate: any) => {
    setCurrentDate(newDate);
  }, []);

  const handleSelectSlot = useCallback(
    ({ start, end }: { start: Date; end: Date }) => {
      if (selectedUser) {
        openModal({
          view: (
            <EventForm startDate={start} endDate={end} user={selectedUser} />
          ),
          customSize: '650px',
        });
      }
    },
    [openModal, selectedUser]
  );

  const handleSelectEvent = useCallback(
    (event: CalendarEvent) => {
      openModal({
        view: <DetailsEvents event={event} />,
        customSize: '500px',
      });
    },
    [openModal]
  );

  const { views, scrollToTime, formats } = useMemo(
    () => ({
      views: {
        month: true,
        week: true,
        day: true,
        agenda: false,
      },
      scrollToTime: new Date(2023, 10, 27, 6),
      formats: {
        dateFormat: 'D',
        weekdayFormat: (date: Date, culture: any, localizer: any) =>
          localizer.format(date, 'ddd', culture),
        dayFormat: (date: Date, culture: any, localizer: any) =>
          localizer.format(date, 'ddd M/D', culture),
        timeGutterFormat: (date: Date, culture: any, localizer: any) =>
          localizer.format(date, 'hh A', culture),
      },
    }),
    []
  );

  return (
    <div className="flex @container">
      <div className="w-1/6 p-4">
        <ul>
          {userList.map((user) => (
            <li
              key={user.id}
              className={`relative flex items-center border-b border-gray-300 p-4 ${
                selectedUser?.id === user.id ? 'font-bold' : ''
              }`}
            >
              <span
                className="mr-3 cursor-pointer transition duration-300 hover:text-red-800"
                onClick={() => router.push(`/profile/${user.id}`)}
                title="Click to view profile"
              >
                <FontAwesomeIcon icon={faUser} />
              </span>
              <span
                onClick={() => setSelectedUser(user)}
                className={`flex-grow cursor-pointer hover:text-gray-900${
                  selectedUser?.id === user.id ? 'font-bold' : ''
                }`}
                title="Click to view Rota"
              >
                {user.name}
              </span>
              {selectedUser?.id === user.id && (
                <span className="absolute right-0 top-1/2 -translate-y-1/2 transform cursor-pointer">
                  ➤
                </span>
              )}
            </li>
          ))}
        </ul>
      </div>

      <div className="w-5/6 p-4">
        <div className="mb-4 flex items-center justify-end">
          <label className="mr-2 text-sm">Select Month:</label>
          <select
            value={selectedMonth}
            onChange={(e) =>
              handleMonthYearChange(parseInt(e.target.value), selectedYear)
            }
            className="mr-2 rounded border border-gray-300 p-2 text-xs"
          >
            {/* Generate month options */}
            {Array.from({ length: 12 }, (_, index) => (
              <option key={index} value={index} className="text-xs">
                {dayjs().month(index).format('MMMM')}
              </option>
            ))}
          </select>

          <label className="mx-2 text-sm">Select Year:</label>
          <select
            value={selectedYear}
            onChange={(e) =>
              handleMonthYearChange(selectedMonth, parseInt(e.target.value))
            }
            className="mr-2 rounded border border-gray-300 p-2 text-xs"
          >
            {/* Generate year options, you can adjust the range based on your requirements */}
            {Array.from({ length: 100 }, (_, index) => (
              <option
                key={index}
                value={new Date().getFullYear() - 50 + index}
                className="text-xs"
              >
                {new Date().getFullYear() - 50 + index}
              </option>
            ))}
          </select>
        </div>

        {selectedUser && (
          <Calendar
            localizer={localizer}
            events={events}
            views={views}
            formats={formats}
            startAccessor="start"
            endAccessor="end"
            dayLayoutAlgorithm="no-overlap"
            onSelectEvent={handleSelectEvent}
            onSelectSlot={handleSelectSlot}
            selectable
            scrollToTime={scrollToTime}
            date={currentDate}
            onNavigate={handleNavigate}
            className={cn('h-[650px] md:h-[1000px]', calendarToolbarClassName)}
          />
        )}
      </div>
    </div>
  );
}
