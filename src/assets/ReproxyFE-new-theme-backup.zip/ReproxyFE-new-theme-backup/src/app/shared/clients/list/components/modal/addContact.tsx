'use client';

import React, { useEffect, useState, memo } from 'react';
import { SubmitHandler, Controller } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Text, Title } from '@/components/ui/text';
import { Form } from '@/components/ui/form';
import cn from '@/utils/class-names';
import { useForm, UseFormReturn } from 'react-hook-form';

import UploadZone from '@/components/ui/file-upload/upload-zone';
import { ActionIcon } from '@/components/ui/action-icon';
import { PiPlusBold, PiXBold } from 'react-icons/pi';
import { PhoneNumber } from '@/components/ui/phone-input';
import { PiEnvelopeSimple } from 'react-icons/pi';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import toast from 'react-hot-toast';
import DeletePopover from '@/app/shared/delete-popover';
import {
  clientContactInfoFormTypes,
  contactClientInfoFormSchema,
  defaultValues,
} from '@/utils/validators/contactClient-info.schema';
import { createClientContact } from '@/redux/slices/clientsSlice/createClientContact';
import SearchListComponent from '@/components/SearchListComponent'
import { createSubsidiaryContact } from '@/redux/slices/subsidiarySlice/createSubsidiaryContact'
import { getUserRoleName } from '@/utils/transforms';
import { ROLES } from '@/config/constants'
const role = getUserRoleName(null)

// a reusable form wrapper component
function HorizontalFormBlockWrapper({
  title,
  description,
  children,
  className,
  isModalView = true,
}: React.PropsWithChildren<{
  title: string;
  description?: string;
  className?: string;
  isModalView?: boolean;
}>) {
  return (
    <div
      className={cn(
        className,
        isModalView ? '@5xl:grid @5xl:grid-cols-6' : ' '
      )}
    >
      {isModalView && (
        <div className="col-span-2 mb-6 pe-4 @5xl:mb-0">
          <Title as="h6" className="font-semibold">
            {title}
          </Title>
          <Text className="mt-1 text-sm text-gray-500">{description}</Text>
        </div>
      )}

      <div
        className={cn(
          'grid grid-cols-2 gap-3 @lg:gap-4 @2xl:gap-5',
          isModalView ? 'col-span-4' : ' '
        )}
      >
        {children}
      </div>
    </div>
  );
}


// main category form component for create and update category
export default function AddContactModalView({...props}: any) {
  // console.log('props-=-=-=-=', props)
  const dispatch = useAppDispatch();
  const [reset, setReset] = useState<any>({});
  const [isLoading, setLoading] = useState<boolean>(false);
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const [phoneDialCode, setPhoneDialCode] = useState<string>('')
  const [isOpenSearch, setIsOpenSearch] = useState<boolean>(false)
  const [contactName, setContactName] = useState<string>('')

  // const getSubsidiaryDetail = useAppSelector((state) => state?.getSubsidiaryDetailById);
  // const subsidiaryDetailData = getSubsidiaryDetail?.subsidiaryDetailData;


  const onSubmit: SubmitHandler<clientContactInfoFormTypes> = async (data) => {
    setLoading(true)


    if(props?.contactType == "client") {
      const newdata = {
        client_id: props?.clientId,
        email_address: data.email_address,
        first_name: data.name,
        last_name: data.user_name,
        phone: phoneNumber,
        phone_dial_code: phoneDialCode
      }
      try {
        const resultAction = await dispatch(createClientContact(newdata));
        if (createClientContact.fulfilled.match(resultAction)) {
          const clientContactData = resultAction.payload;
          // setClientContactId(clientContactData?.data?.contact_id);
          toast.success(<Text as="b">Invitation Sent!</Text>);
          setLoading(false)
          setReset(defaultValues);
          setPhoneNumber('')
          props.isOpened(false)
        } else {
          if (resultAction.payload) {
            toast.error(<Text as="b"> {resultAction.payload?.response?.data?.message_key}</Text>);
            setLoading(false)
            return;
          } else {
            toast.error('Authentication Failed');
            setLoading(false)
            return;
          }
        }
  
      } catch (err) {
        console.log('err: ', err)
      }
    } else if (props?.contactType == "worker-admin") {
      let newdata;
      if(role == ROLES.ADMIN) {
        newdata = {
          branch_id: props?.data?.branch_id,
          client_id: props?.data?.client_id,
          email_address: data.email_address,
          first_name: data.name,
          last_name: data.user_name,
          phone: phoneNumber,
          phone_dial_code: phoneDialCode
        }
      } else {
        newdata = {
          branch_id: props?.data?.branch_id,
          // client_id: props?.data?.client_id,
          email_address: data.email_address,
          first_name: data.name,
          last_name: data.user_name,
          phone: phoneNumber,
          phone_dial_code: phoneDialCode
        }
      }
      try {
        const resultAction = await dispatch(createSubsidiaryContact(newdata));
        if (createSubsidiaryContact.fulfilled.match(resultAction)) {
          const clientContactData = resultAction.payload;
          // setClientContactId(clientContactData?.data?.contact_id);
          toast.success(<Text as="b">Invitation Sent!</Text>);
          setLoading(false)
          setReset(defaultValues);
          setPhoneNumber('')
          props.isOpened(false)
        } else {
          if (resultAction.payload) {
            toast.error(<Text as="b"> {resultAction.payload?.response?.data?.message_key}</Text>);
            setLoading(false)
            return;
          } else {
            toast.error('Authentication Failed');
            setLoading(false)
            return;
          }
        }
  
      } catch (err) {
        console.log('err: ', err)
      }

    }

  };
  

  // const handleChange = (value: any, country: any, e: any) => {
  //   // Update the phoneNumber state when the input value changes
  //   const splittedVal = e.target.value.split(' ')
  //   const concatenatedArray = [].concat(...splittedVal.slice(1))
  //   const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
  //   setPhoneNumber(concatenatedString);
  // };

  const handleChange = (value: any, countryCode: any, e: any) => {
    // Update the phoneNumber state when the input value changes
    const splittedVal = e.target.value.split(' ')
    const concatenatedArray = [].concat(...splittedVal.slice(1))
    const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
    setPhoneNumber(concatenatedString);
    setPhoneDialCode(countryCode.dialCode)
  };

  const addNewContact = (data: any) => {
    if(data == 'new') {
      setIsOpenSearch(false)
      setContactName('')
    } else {
      setIsOpenSearch(false)
      setContactName(data)
    }
  }

  const { control, register, setValue, formState: { errors } } = useForm<clientContactInfoFormTypes>({
    defaultValues: defaultValues,
    mode: 'onChange'
  });


  useEffect(() => {
    if(!!contactName === true) {
      setValue('name', contactName)
    } else {
      if(!!contactName === false) {
        setValue('name', '')
      }
    }
  }, [contactName, setValue])


  return (
    <div className="m-auto px-5 pb-8 pt-5 @lg:pt-6 @2xl:px-7">
        <div className="mb-7 flex items-center justify-between">
        <Title as="h4" className="font-semibold">
          Add Contact Person
        </Title>
        <ActionIcon size="sm" variant="text" onClick={() => props.isOpened(false)}>
          <PiXBold className="h-auto w-5" />
        </ActionIcon>
      </div>
      <SearchListComponent isOpen={isOpenSearch} data={props?.data?.contacts} contactAddition={addNewContact} setIsOpened={setIsOpenSearch} />
    <Form<clientContactInfoFormTypes>
      validationSchema={contactClientInfoFormSchema}
      resetValues={reset}
      onSubmit={onSubmit}
      useFormProps={{
        mode: 'onChange',
        defaultValues: defaultValues,
      }}
      className="isomorphic-form flex flex-grow flex-col @container pt-4"
    >
      {() => {

        return (
        <>
          <div className="flex-grow pb-10">
            <div
              className={cn(
                'grid grid-cols-1 ',
                props?.isModalView
                  ? 'grid grid-cols-1 gap-8 divide-y divide-dashed  divide-gray-200 @2xl:gap-10 @3xl:gap-12 [&>div]:pt-7 first:[&>div]:pt-0 @2xl:[&>div]:pt-9 @3xl:[&>div]:pt-11'
                  : 'gap-5'
              )}
            >
              <HorizontalFormBlockWrapper
                title={'Add details'}
                description={'Add your information from here'}
                isModalView={props?.isModalView}
              >
                
                
                <Input
                  label="First Name"
                  placeholder="Enter First Name"
                  {...register('name')}
                  error={errors.name?.message}
                />

                {/* <MemoizedInput name="name" placeholder="Name" register={register} /> */}
                {/* <SearchListComponent /> */}
                

                <Input
                label="Surname"
                placeholder="Enter Surname"
                {...register('user_name')}
                error={errors.user_name?.message}
                />
                  
                <Input
                  label="Email"
                  {...register('email_address')}
                  prefix={
                  <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                  }
                  type="email"
                  placeholder="georgia.young@example.com"
                  error={errors.email_address?.message}
                />

                <Controller
                  name="phone"
                  control={control}
                  render={({ field: { value, onChange } }) => (
                    <PhoneNumber
                      label="Phone"
                      error={errors.phone?.message}
                      country={'gb'}
                      value={value}
                      onChange={handleChange}
                      placeholder="Enter Phone Number"
                      inputClassName="rtl:pr-12"
                      buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                    />
                  )}
                />

              </HorizontalFormBlockWrapper>
              
            </div>
          </div>

          <div className="mt-4 flex justify-end gap-3">
            
            <Button
                className="w-auto"
                variant="outline"
                onClick={() => props.isOpened(false)}
            >
                Cancel
            </Button>
            <Button type="submit" isLoading={isLoading} className="w-auto">
              Invite
            </Button>
        </div>
        </>
      )}}
    </Form>
    </div>
  );
}
