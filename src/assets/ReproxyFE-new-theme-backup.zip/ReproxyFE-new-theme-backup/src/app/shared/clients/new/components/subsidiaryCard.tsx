'use client';

import { useEffect, useState, useRef } from 'react';
import { Dropdown } from '@/components/ui/dropdown ';
import { ActionIcon } from '@/components/ui/action-icon';
import { PiDotsThreeBold } from 'react-icons/pi';
// import styles from './subsidiaryForm.module.css';

const SubsidiaryCard: any = (props: any) => {
  const _handleEdit: any = () => {
    props.setIsOpenFormDetail(false);
    props.editMode(true);
  };

  return (
    <div className="mt-5 inline-block gap-6 p-3 md:p-5">
      <div
        className={`w-full rounded-lg border border-gray-200 bg-white pl-3 shadow dark:border-gray-700 dark:bg-gray-800 `}
      >
        <header className="flex items-center justify-between gap-2 pb-3">
          <div className="flex items-center gap-3 rounded-t-lg pl-5 pt-8">
            <h5 className="mb-2 text-xl font-semibold tracking-tight text-gray-900 dark:text-white">
              Subsidiary Details
            </h5>
          </div>
          <Dropdown
            className={`relative inline-block pr-4 pt-4`}
            placement="bottom-end"
          >
            <Dropdown.Trigger>
              <ActionIcon variant="text" className="ml-auto h-auto w-auto p-1">
                <PiDotsThreeBold className="h-auto w-6" />
              </ActionIcon>
            </Dropdown.Trigger>
            <Dropdown.Menu>
              <Dropdown.Item className="gap-2 text-xs sm:text-sm">
                <span
                  className="w-full text-left"
                  onClick={() =>
                    // openModal({
                    //     view: <CreateUser />,
                    // })
                    _handleEdit()
                  }
                >
                  Edit
                </span>
              </Dropdown.Item>
              {/* <Dropdown.Item className="gap-2 text-xs sm:text-sm">
              Delete
              </Dropdown.Item> */}
              {/* <Dropdown.Item className="gap-2 text-xs sm:text-sm">
              Remove Role
              </Dropdown.Item> */}
            </Dropdown.Menu>
          </Dropdown>
        </header>
        {/* <hr /> */}
        <div className="px-6 pb-5">
          <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
            <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
              Name:
              <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
                {/* branch_name */}
                {props.subsidiaryDetailData?.branch_name}
              </p>
            </span>
            {/* <span className='text-lg font-medium dark:text-white text-gray-700 tracking-tight'>
                  branch_name
              </span> */}
          </div>
          <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
            <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
              Unique Name:
              <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
                {/* branch_unique_name */}
                {props.subsidiaryDetailData?.branch_unique_name}
              </p>
            </span>
            {/* <span className='text-lg font-medium dark:text-white text-gray-700 tracking-tight'>
                  branch_unique_name
              </span> */}
          </div>
          <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
            <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
              Email Address:
              <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
                {/* email@email.com */}
                {props.subsidiaryDetailData?.email}
              </p>
            </span>
            {/* <span className='text-lg font-semibold dark:text-white text-gray-900 tracking-tight'>
                  email@email.com
              </span> */}
          </div>
          <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
            <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
              Mobile Number:
              <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
                {/* 123456765432 */}
                {props.subsidiaryDetailData?.phone}
              </p>
            </span>
            {/* <span className='text-lg font-semibold dark:text-white text-gray-900 tracking-tight'>
              </span> */}
          </div>
          <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
            <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
              Address:
              <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
                {/* 123 Main Street, Anytown, USA 12345 */}
                {props?.subsidiaryDetailData?.address?.street_address +
                  ', ' +
                  props?.subsidiaryDetailData?.address?.town}
              </p>
            </span>
            {/* <span className='text-lg font-semibold dark:text-white text-gray-900 tracking-tight'>
                  123 Main Street, Anytown, USA 12345
              </span> */}
          </div>
          <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
            <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
              Post code:
              <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
                {/* 94402 */}
                {props.subsidiaryDetailData?.address?.postcode}
              </p>
            </span>
            {/* <span className='text-lg font-semibold dark:text-white text-gray-900 tracking-tight'>
                  94402
              </span> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubsidiaryCard;
