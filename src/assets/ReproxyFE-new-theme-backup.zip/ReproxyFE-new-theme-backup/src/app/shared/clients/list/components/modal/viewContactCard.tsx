'use client';

import { useEffect, useState } from 'react';
import { SubmitHandler, Controller } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Text, Title } from '@/components/ui/text';
import { Form } from '@/components/ui/form';
import cn from '@/utils/class-names';
import {
  ClientInfoFormTypes,
  clientInfoFormSchema,
  defaultValues,
} from '@/utils/validators/client-info.schema';
import { ActionIcon } from '@/components/ui/action-icon';
import { Tooltip } from '@/components/ui/tooltip';
import { PiPhoneCallDuotone, PiEnvelopeDuotone, PiUserBold, PiUserLight, PiPlusBold, PiPlusLight } from 'react-icons/pi';


// main category form component for create and update category
export default function ViewContactCard({ data }: { data: any; }) {

  return (
    // <div className="m-auto px-5 pb-8 pt-5 @lg:pt-6 @2xl:px-7">
      <>
        <section className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700 pt-9">
          <div className="flex flex-col items-center pb-10">
            <img className="w-24 h-24 mb-3 rounded-full shadow-lg" src={data?.user?.profile_pic} alt={data?.user?.first_name} />
            <h4 className="mb-1 text-xl font-medium text-gray-900 dark:text-white">
              {data?.user?.first_name} {data?.user?.last_name}
            </h4>
            <h6 className='text-sm text-gray-500 dark:text-gray-400'>@{data?.user?.user_name}</h6>
            <span className="text-sm text-gray-500 dark:text-gray-400">{data?.user?.user_type}</span>
            <span className="text-sm text-gray-500 dark:text-gray-400">#{data?.company_name}</span>
            <div className="flex mt-4 md:mt-6">
              <a href={`mailto:${data?.user?.email_address}`} className="py-2 px-4">
                <Tooltip
                  size="sm"
                  content={data?.user?.email_address}
                  placement="top"
                  color="invert"
                  className="z-[9999]"
                >
                  <ActionIcon
                    as="span"
                    size="sm"
                    variant="outline"
                    className="hover:cursor-pointer hover:text-gray-700"
                  >
                    <PiEnvelopeDuotone className="h-4 w-4" />
                  </ActionIcon>
                </Tooltip>
              </a>
              <a href={`tel:${data?.user?.phone}`} className="py-2 px-4">
                <Tooltip
                  size="sm"
                  content={data?.user?.phone}
                  placement="top"
                  color="invert"
                  className="z-[9999]"
                >
                  <ActionIcon
                    as="span"
                    size="sm"
                    variant="outline"
                    className="hover:cursor-pointer hover:text-gray-700"
                  >
                    <PiPhoneCallDuotone className="h-4 w-4" />
                  </ActionIcon>
                </Tooltip>
              </a>
            </div>
          </div>
        </section>
      </>
    // </div>
  );
}