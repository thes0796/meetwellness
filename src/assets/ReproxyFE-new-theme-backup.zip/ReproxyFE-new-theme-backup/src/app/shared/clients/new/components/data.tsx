export const orderData = [
  {
    id: '3413',
    name: 'Dr. Ernest Fritsch-Shanahan',
    email: 'August17@hotmail.com',
    avatar:
      'https://isomorphic-furyroad.s3.amazonaws.com/public/avatars-blur/avatar-15.webp',
    items: 83,
    price: '457.00',
    status: 'Cancelled',
    createdAt: '2023-08-06T00:01:51.735Z',
    updatedAt: '2023-08-10T22:39:21.113Z',
    products: [
      {
        id: '0o02051402',
        name: 'Tasty Metal Shirt',
        category: 'Shoes',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/7.webp',
        price: '410.00',
        quantity: 2,
      },
      {
        id: '0o17477064',
        name: 'Modern Cotton Gloves',
        category: 'Watch',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/5.webp',
        price: '342.00',
        quantity: 3,
      },
      {
        id: '0o02374305',
        name: 'Rustic Steel Computer',
        category: 'Shoes',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/6.webp',
        price: '948.00',
        quantity: 1,
      },
    ],
  },
  {
    id: '9192',
    name: 'Mr. Gregory Medhurst-Lubowitz',
    email: 'General.Bergstrom@yahoo.com',
    avatar:
      'https://isomorphic-furyroad.s3.amazonaws.com/public/avatars-blur/avatar-14.webp',
    items: 21,
    price: '426.00',
    status: 'Cancelled',
    createdAt: '2023-07-22T10:53:43.612Z',
    updatedAt: '2023-08-13T08:39:41.230Z',
    products: [
      {
        id: '0o02602714',
        name: 'Licensed Concrete Cheese',
        category: 'Shirt',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/7.webp',
        price: '410.00',
        quantity: 2,
      },
      {
        id: '0o24033230',
        name: 'Gorgeous Bronze Gloves',
        category: 'Watch',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/1.webp',
        price: '948.00',
        quantity: 1,
      },
    ],
  },
  {
    id: '4983',
    name: 'Becky Goodwin',
    email: 'Daniella_Littel@gmail.com',
    avatar:
      'https://isomorphic-furyroad.s3.amazonaws.com/public/avatars-blur/avatar-13.webp',
    items: 93,
    price: '544.00',
    status: 'Refunded',
    createdAt: '2023-07-29T08:46:59.211Z',
    updatedAt: '2023-08-08T22:08:04.564Z',
    products: [
      {
        id: '0o02374305',
        name: 'Rustic Steel Computer',
        category: 'Shoes',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/2.webp',
        price: '948.00',
        quantity: 1,
      },
    ],
  },
  {
    id: '9114',
    name: 'Mrs. Ann Leuschke Jr.',
    email: 'Favian49@yahoo.com',
    avatar:
      'https://isomorphic-furyroad.s3.amazonaws.com/public/avatars-blur/avatar-12.webp',
    items: 63,
    price: '282.00',
    status: 'Cancelled',
    createdAt: '2023-07-25T20:22:56.250Z',
    updatedAt: '2023-08-12T00:03:41.358Z',
    products: [
      {
        id: '0o02051402',
        name: 'Tasty Metal Shirt',
        category: 'Shoes',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/4.webp',
        price: '410.00',
        quantity: 2,
      },
      {
        id: '0o17477064',
        name: 'Modern Cotton Gloves',
        category: 'Watch',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/5.webp',
        price: '342.00',
        quantity: 3,
      },
      {
        id: '0o02374305',
        name: 'Rustic Steel Computer',
        category: 'Shoes',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/6.webp',
        price: '948.00',
        quantity: 1,
      },
    ],
  },
  {
    id: '4849',
    name: 'Elmer Heathcote',
    email: 'Efren.Wehner@gmail.com',
    avatar:
      'https://isomorphic-furyroad.s3.amazonaws.com/public/avatars-blur/avatar-11.webp',
    items: 89,
    price: '971.00',
    status: 'Refunded',
    createdAt: '2023-07-18T14:45:23.679Z',
    updatedAt: '2023-08-14T10:42:39.616Z',
    products: [
      {
        id: '0o02051402',
        name: 'Tasty Metal Shirt',
        category: 'Shoes',
        image:
          'https://isomorphic-furyroad.s3.amazonaws.com/public/products/modern/4.webp',
        price: '410.00',
        quantity: 2,
      },
    ],
  },
];

export const contactss = [
  {
    user_name: 'Dr. Ernest Fritsch-Shanahan',
    email_address: 'August17@hotmail.com',
    phone: '5858585858',
  },
];
