'use client';

import { useEffect, useState } from 'react';
import { SubmitHandler, Controller } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Text, Title } from '@/components/ui/text';
import { Form } from '@/components/ui/form';
import cn from '@/utils/class-names';
import {
  ClientInfoFormTypes,
  clientInfoFormSchema,
  defaultValues,
} from '@/utils/validators/client-info.schema';




// a reusable form wrapper component
function HorizontalFormBlockWrapper({
  title,
  description,
  children,
  className,
  isModalView = true,
}: React.PropsWithChildren<{
  title: string;
  description?: string;
  className?: string;
  isModalView?: boolean;
}>) {
  return (
    <div
      className={cn(
        className,
        isModalView ? '@5xl:grid @5xl:grid-cols-6' : ' '
      )}
    >
      {isModalView && (
        <div className="col-span-2 mb-6 pe-4 @5xl:mb-0">
          <Title as="h6" className="font-semibold">
            {title}
          </Title>
          <Text className="mt-1 text-sm text-gray-500">{description}</Text>
        </div>
      )}

      <div
        className={cn(
          'grid grid-cols-2 gap-3 @lg:gap-4 @2xl:gap-5',
          isModalView ? 'col-span-4' : ' '
        )}
      >
        {children}
      </div>
    </div>
  );
}


// main category form component for create and update category
export default function Viewdata({ data, view, isModalView }: { data: any; view: any, isModalView:any }) {
  
  const [reset, setReset] = useState({});


  const onSubmit: SubmitHandler<ClientInfoFormTypes> = async (data) => {
    
  };


  return (
    <div className="m-auto px-5 pb-8 pt-5 @lg:pt-6 @2xl:px-7">

    <Form<ClientInfoFormTypes>
      validationSchema={clientInfoFormSchema}
      resetValues={reset}
      onSubmit={onSubmit}
      useFormProps={{
        mode: 'onChange',
        defaultValues: defaultValues,
      }}
      className="isomorphic-form flex flex-grow flex-col @container"
    >
      {({ register, control, getValues, setValue, formState: { errors } }) => {
      

        return (
        <>
          <div className="flex-grow pb-10">
            <div
              className={cn(
                'grid grid-cols-1 ',
                isModalView
                  ? 'grid grid-cols-1 gap-8 divide-y divide-dashed  divide-gray-200 @2xl:gap-10 @3xl:gap-12 [&>div]:pt-7 first:[&>div]:pt-0 @2xl:[&>div]:pt-9 @3xl:[&>div]:pt-11'
                  : 'gap-5'
              )}
            >
            {view == "Client" && (
                <>
              <HorizontalFormBlockWrapper
                title={'Client Details'}
                description={''}
                isModalView={isModalView}
              >
                <label className='block'>
                  <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                    Company Name: 
                  </span>
                  <span>
                    {data?.client_name}
                  </span>
                </label>
             

                <label className='block'>
                  <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                    Unique Name: 
                  </span>
                  <span>
                    {data?.client_unique_name}
                  </span>
                </label>

               
                

                <label className='block'>
                  <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                    Trading name: 
                  </span>
                  <span>
                    {data?.trading_name}
                  </span>
                </label>
                
              </HorizontalFormBlockWrapper>


              <HorizontalFormBlockWrapper
                title="Contact"
                description=""
                isModalView={isModalView}
              >
                <label className='block'>
                  <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                    Email: 
                  </span>
                  <span>
                    {data?.email}
                  </span>
                </label>

                <label className='block'>
                  <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                    Mobile Number: 
                  </span>
                  <span>
                    {`+${data?.phone_number_dial_code} ${data?.phone_number}`}
                  </span>
                </label>

                <label className='block'>
                  <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                    Main contact number: 
                  </span>
                  <span>
                    {`+${data?.main_contact_dial_code} ${data?.main_contact}`}
                  </span>
                </label>

              </HorizontalFormBlockWrapper>


              <HorizontalFormBlockWrapper
                title="Address"
                description=""
                isModalView={isModalView}
              >
               
                  
                <div className="col-span-2">
                  <label className='block'>
                    <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                      Street Address: 
                    </span>
                    <span>
                      {data?.address?.street_address}
                    </span>
                  </label>
                </div>


                <label className='block'>
                  <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                    Town: 
                  </span>
                  <span>
                    {data?.address?.town}
                  </span>
                </label>
                  
                <label className='block'>
                  <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                    Post Code: 
                  </span>
                  <span>
                    {data?.address?.postcode}
                  </span>
                </label>
                    
              </HorizontalFormBlockWrapper>
              </>
              )}

              {view == "Contact" && (
                <HorizontalFormBlockWrapper
                  title={'Manager Details'}
                  description={''}
                  isModalView={isModalView}
                >
                  {/* <label className='block'> */}
                    <span className='rizzui-input-label block text-sm mb-1.5 font-semibold'>
                      First name: 
                    </span>
                    <span>
                      {data?.user?.first_name}
                    </span>
                  {/* </label> */}

                  {/* <label className='block'> */}
                    <span className='rizzui-input-label block text-sm mb-1.5 font-semibold'>
                      Surname: 
                    </span>
                    <span>
                      {data?.user?.last_name}
                    </span>
                  {/* </label> */}

                  {/* <label className='block'> */}
                    <span className='rizzui-input-label block text-sm mb-1.5 font-semibold'>
                      Email: 
                    </span>
                    <span>
                      {data?.user?.email_address}
                    </span>
                  {/* </label> */}

                  {/* <label className='block'> */}
                    <span className='rizzui-input-label block text-sm mb-1.5 font-semibold'>
                      Phone Number: 
                    </span>
                    <span>
                     +{data?.user?.phone_dial_code} {data?.user?.phone}
                    </span>
                  {/* </label> */}

                </HorizontalFormBlockWrapper>
              )}

              {view == "Subsidiary" && (
                <>
                  <HorizontalFormBlockWrapper
                    title={'Subsidiary Details'}
                    description={''}
                    isModalView={isModalView}
                  >

                    <label className='block'>
                      <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                        Name: 
                      </span>
                      <span>
                        {data?.branch_name}
                      </span>
                    </label>

                    <label className='block'>
                      <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                        Quickname: 
                      </span>
                      <span>
                        {data?.branch_unique_name}
                      </span>
                    </label>

                    <label className='block'>
                      <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                        Trading name: 
                      </span>
                      <span>
                        {data?.trading_name}
                      </span>
                    </label>

                  </HorizontalFormBlockWrapper>

                  <HorizontalFormBlockWrapper
                    title={'Contact Details'}
                    description={''}
                    isModalView={isModalView}
                  >

                    <label className='block'>
                      <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                        Email: 
                      </span>
                      <span>
                        {data?.email}
                      </span>
                    </label>

                    <label className='block'>
                      <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                        Phone Number: 
                      </span>
                      <span>
                        {data?.phone}
                      </span>
                    </label>

                  </HorizontalFormBlockWrapper>

                  <HorizontalFormBlockWrapper
                    title={'Address Details'}
                    description={''}
                    isModalView={isModalView}
                  >

                    <label className='block'>
                      <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                        Street Address: 
                      </span>
                      <span>
                        {data?.address?.street_address}
                      </span>
                    </label>

                    <label className='block'>
                      <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                        Town: 
                      </span>
                      <span>
                        {data?.address?.town}
                      </span>
                    </label>

                    <label className='block'>
                      <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
                        Post Code: 
                      </span>
                      <span>
                        {data?.address?.postcode}
                      </span>
                    </label>

                  </HorizontalFormBlockWrapper>
                </>
              )}
            </div>
          </div>
        </>
      )}}
    </Form>
    </div>
  );
}