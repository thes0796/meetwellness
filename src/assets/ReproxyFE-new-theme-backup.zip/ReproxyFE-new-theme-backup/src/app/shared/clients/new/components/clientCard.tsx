'use client';

import { useEffect, useState, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dropdown } from '@/components/ui/dropdown ';
import { ActionIcon } from '@/components/ui/action-icon';
import { PiDotsThreeBold, PiEnvelopeSimple } from 'react-icons/pi';
import FormGroup from '@/app/shared/form-group';
import { Controller } from 'react-hook-form';
import { PhoneNumber } from '@/components/ui/phone-input';
import Image from 'next/image';
// import styles from './subsidiaryForm.module.css';
import checked from '../../../../../../public/checked.png';

const ClientCard: any = (props: any) => {
  const _handleEdit: any = () => {
    props.setIsOpenFormDetail(false);
    props.editMode(true);
  };

  return (
    <div>
      {/* <div
        className={`w-full rounded-lg border border-gray-200 bg-white pl-3 shadow dark:border-gray-700 dark:bg-gray-800 `}
      > */}
      <header className="flex items-center justify-between gap-2 pb-3">
        <div className="flex items-center gap-3 rounded-t-lg pl-5 pt-8">
          <h5 className="mb-2 text-xl font-semibold tracking-tight text-gray-900 dark:text-white">
            Client Details
          </h5>
        </div>
        {props?.isOpenFormDetail && (
          <Image src={checked} alt="image" height="23" width="23" />
        )}
        <Dropdown
          className={`relative inline-block pr-4 pt-4`}
          placement="bottom-end"
        >
          <Dropdown.Trigger>
            <ActionIcon variant="text" className="ml-auto h-auto w-auto p-1">
              <PiDotsThreeBold className="h-auto w-6" />
            </ActionIcon>
          </Dropdown.Trigger>
          <Dropdown.Menu>
            <Dropdown.Item className="gap-2 text-xs sm:text-sm">
              <span
                className="w-full text-left"
                // onClick={() =>
                // openModal({
                //     view: <CreateUser />,
                // })
                // _handleEdit()
                // }
              >
                Edit
              </span>
            </Dropdown.Item>
            {/* <Dropdown.Item className="gap-2 text-xs sm:text-sm">
              Delete
              </Dropdown.Item> */}
            {/* <Dropdown.Item className="gap-2 text-xs sm:text-sm">
              Remove Role
              </Dropdown.Item> */}
          </Dropdown.Menu>
        </Dropdown>
      </header>
      {/* <hr /> */}
      <div className="p-5">
        {/* <FormGroup
          title="Company Info Section"
          description="Update company details here"
          // className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
        /> */}
        <div className="mb-5 grid gap-7 @2xl:gap-9 @3xl:gap-11">
          <FormGroup
            title="Company Name"
            className="pt-5 @2xl:pt-7 @3xl:grid-cols-12 @3xl:pt-9"
          >
            <Input
              placeholder="Company Name"
              disabled
              value={props.clientDetailData?.client_name}
              className="flex-grow"
            />
          </FormGroup>
          <FormGroup title="Unique Name" className=" @3xl:grid-cols-12">
            <Input
              placeholder="Unique Name"
              disabled
              value={props.clientDetailData?.client_unique_name}
              className="flex-grow"
            />
          </FormGroup>
          <FormGroup title="Trading Name" className=" @3xl:grid-cols-12">
            <Input
              placeholder="Trading Name"
              value={props.clientDetailData?.trading_name}
              disabled
              className="flex-grow"
            />
          </FormGroup>
          <FormGroup title="Email Address" className="@3xl:grid-cols-12">
            <Input
              className="flex-grow"
              disabled
              value={props.clientDetailData?.email_address}
              prefix={<PiEnvelopeSimple className="h-6 w-6 text-gray-500" />}
              type="email"
              placeholder="georgia.young@example.com"
            />
          </FormGroup>
          <FormGroup title="Mobile Number" className=" @3xl:grid-cols-12 ">
            <Input
              placeholder="Trading Name"
              value={props.clientDetailData?.phone_number}
              disabled
              className="flex-grow"
            />
          </FormGroup>
          <FormGroup
            title="Main Contact Number"
            className=" @3xl:grid-cols-12 "
          >
            <Input
              placeholder="Trading Name"
              value={props.clientDetailData?.main_contact}
              disabled
              className="flex-grow"
            />
          </FormGroup>
          <FormGroup
            title="Address:"
            className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
          />
          <FormGroup title="Street" className="@3xl:grid-cols-12">
            {/* <Input
                            placeholder="Street"
                            {...register('street_address')}
                            error={errors.street_address?.message}
                            className="col-span-full"
                          />{' '} */}
            <Textarea
              // label="Address"
              placeholder="Enter your address"
              // textareaClassName="h-20"
              value={props.clientDetailData?.address?.street_address}
              disabled
              className="flex-grow"
              rows={5}
            />
          </FormGroup>

          <FormGroup title="Town" className="@3xl:grid-cols-12">
            <Input
              placeholder="Town Name"
              value={props.clientDetailData?.address?.town}
              disabled
              className="flex-grow"
            />{' '}
          </FormGroup>

          <FormGroup title="Post Code" className="@3xl:grid-cols-12">
            <Input
              placeholder="Postcode"
              value={props.clientDetailData?.address?.postcode}
              disabled
              className="flex-grow"
            />
          </FormGroup>
        </div>
      </div>
    </div>
    // </div>
    // <div className="px-6 pb-5">
    //   <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
    //     <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
    //       Name:
    //       <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
    //         {/* branch_name */}
    //         {props.clientDetailData?.client_name}
    //       </p>
    //     </span>
    //     {/* <span className='text-lg font-medium dark:text-white text-gray-700 tracking-tight'>
    //           branch_name
    //       </span> */}
    //   </div>
    //   <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
    //     <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
    //       Unique Name:
    //       <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
    //         {/* branch_unique_name */}
    //         {props.clientDetailData?.client_unique_name}
    //       </p>
    //     </span>
    //     {/* <span className='text-lg font-medium dark:text-white text-gray-700 tracking-tight'>
    //           branch_unique_name
    //       </span> */}
    //   </div>
    //   <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
    //     <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
    //       Email Address:
    //       <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
    //         {/* email@email.com */}
    //         {props.clientDetailData?.email_address}
    //       </p>
    //     </span>
    //     {/* <span className='text-lg font-semibold dark:text-white text-gray-900 tracking-tight'>
    //           email@email.com
    //       </span> */}
    //   </div>
    //   <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
    //     <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
    //       Mobile Number:
    //       <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
    //         {/* 123456765432 */}
    //         {props.clientDetailData?.phone_number}
    //       </p>
    //     </span>
    //     {/* <span className='text-lg font-semibold dark:text-white text-gray-900 tracking-tight'>
    //       </span> */}
    //   </div>
    //   <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
    //     <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
    //       Address:
    //       <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
    //         {/* 123 Main Street, Anytown, USA 12345 */}
    //         {props?.clientDetailData?.address?.street_address +
    //           ', ' +
    //           props?.clientDetailData?.address?.town}
    //       </p>
    //     </span>
    //     {/* <span className='text-lg font-semibold dark:text-white text-gray-900 tracking-tight'>
    //           123 Main Street, Anytown, USA 12345
    //       </span> */}
    //   </div>
    //   <div className="mb-5 mt-2.5 flex items-center space-x-1 rtl:space-x-reverse">
    //     <span className="text-base font-semibold tracking-tight text-gray-900 dark:text-white">
    //       Post code:
    //       <p className="text-base font-medium tracking-tight text-gray-700 dark:text-white">
    //         {/* 94402 */}
    //         {props.clientDetailData?.address?.postcode}
    //       </p>
    //     </span>
    //     {/* <span className='text-lg font-semibold dark:text-white text-gray-900 tracking-tight'>
    //           94402
    //       </span> */}
    //   </div>
    // </div>
  );
};

export default ClientCard;
