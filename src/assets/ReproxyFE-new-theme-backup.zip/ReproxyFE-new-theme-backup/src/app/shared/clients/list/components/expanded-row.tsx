"use client";
import Image from 'next/image';
import { PiHouseBold, PiXBold } from 'react-icons/pi';
import { Title, Text } from '@/components/ui/text';
import { Tooltip } from '@/components/ui/tooltip';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { fetchClientContactByClientId } from '@/redux/slices/clientsSlice/getClientContactByClientId';
import { useEffect, useState } from 'react';
import { fetchSubsidiaryByClientId } from '@/redux/slices/subsidiarySlice/getSubsidiaryByClientId';
import Spinner from '@/components/ui/spinner';
import { Button } from '@/components/ui/button';
import { Modal } from '@/components/ui/modal';
import BasicTableWidget from '@/components/controlled-table/basic-table-widget';
import { getColumns } from './client-subsidiaries-columns';
import { getContactsColumns } from './client-contacts-columns';
import ViewData from './view-data';
import { deleteSubsidiary } from '@/redux/slices/subsidiarySlice/deleteSubsidiary';
import toast from 'react-hot-toast';
import { deleteClientContactByClientContactId } from '@/redux/slices/clientsSlice/deleteClientContactByClientContactId';
import { useRouter } from 'next/navigation';
import { BsPlusCircleFill } from 'react-icons/bs';
import {getLoggedInUserId} from '@/utils/transforms'
import AddSubsidiaryModalView from './modal/addSubsidiary'
import AddContactModalView from './modal/addContact'
import EditContactModalView from './modal/editContact'
import EditSubsidiaryModalView from './modal/editSubsidiary'
import ViewContactCard from './modal/viewContactCard'

const user_id = getLoggedInUserId()

export default function ExpandedOrderRow({ record, index, indent, expanded }: any) {
  // console.log('record-=-=-=-', record)
  const dispatch = useAppDispatch();
  const router = useRouter();
  const [isSubsidiaryModalOpen, setISubsidiaryModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [selectedSubsidiary, setSelectedSubsidiary] = useState<any>([]);
  const [selectedContact, setSelectedContact] = useState<any>([]);
  const [isOpenedModal, setisOpenedModal] = useState<boolean>(false)
  const [modaltype, setModaltype] = useState<string>('')
  const [isOpenAddContact, setIsOpenAddContact] = useState<boolean>(false)
  const [subsidiaryData, setSubsidiaryData] = useState<any>()
  const [viewContact, setViewContact] = useState<boolean>(false)
  const [viewContactData, setViewContactData] = useState<any>()
  const [isEditCompleted, setIsEditCompleted] = useState<boolean>(false)

  // Function to handle opening the modal and setting the selected client subsidiary
  const handleViewSubsidiary = (subsidiary: any) => {
    setSelectedSubsidiary(subsidiary);
    setISubsidiaryModalOpen(true);
  };

  const handleEditSubsidiary = (subsidiary: any) => {
    setSelectedSubsidiary(subsidiary);
    setisOpenedModal(true);
    setModaltype('editSubsidiary')
  }

  const handleDeleteSubsidiary = async (subsidiary: any) => {
    const response = await dispatch(deleteSubsidiary(subsidiary));
    console.log('handleDeleteSubsidiary', response);
    if (response?.payload?.status === 'SUCCESS') {
      toast.success(<Text as="b">{response.payload?.message_key}</Text>);
      window.location.reload();
    } else {
      toast.error(
        <Text as="b">{response.payload?.response?.data?.message_key}</Text>
      );
    }
  };

  // Function to handle opening the modal and setting the selected client contact
  const handleViewContact = (subsidiary: any) => {
    setViewContactData(subsidiary);
    setisOpenedModal(true);
    setModaltype('viewContact')
  };
  const handleEditContact = (clientDetail: any) => {
    // console.log('clientDetail-=-=-==-=', clientDetail)
    setSelectedContact(clientDetail)
    setModaltype('editContact')
    setisOpenedModal(true)
  }
  const handleDeleteContact = async (contact: any) => {
    // console.log('rowwwww', contact);

    const response = await dispatch(
      deleteClientContactByClientContactId(contact)
    );
    console.log('deletcontact', response);
    if (response?.payload?.status === 'SUCCESS') {
      toast.success(<Text as="b">{response.payload?.message_key}</Text>);
      window.location.reload();
    } else {
      toast.error(
        <Text as="b">{response.payload?.response?.data?.message_key}</Text>
      );
    }
  };
  const clientContactByClientId = useAppSelector(
    (state) => state?.clientContactByClientId
  );
  const clientContactData = clientContactByClientId?.clientContactByClientId;
  const subsidiaryById = useAppSelector((state) => state?.getSubsidiaryDetailByClientId);
  const subsidiaryDetailData = subsidiaryById?.subsidiaryDataByClientId;
  // console.log('clientContactData-=-=-=', clientContactData)
  // console.log('subsidiaryDetailData-=-=-=-=', subsidiaryById)

  useEffect(() => {
    if(expanded) {
      // dispatch(fetchClientContactByClientId(record?.client_id));
      dispatch(fetchSubsidiaryByClientId(record?.client_id));
    }
  }, [expanded]);

  useEffect(() => {
    if(isOpenedModal === false) {
      // dispatch(fetchClientContactByClientId(record?.client_id));
      dispatch(fetchSubsidiaryByClientId(record?.client_id));
    }
  }, [isOpenedModal])

  const handleAddContact = (data: any) => {
    setisOpenedModal(true)
    setIsOpenAddContact(true)
    setSubsidiaryData(data)
    setModaltype('contact')
  }

  const handleEditProject = () => {
    setIsEditCompleted(true)
  }

  useEffect(() => {
    if(isEditCompleted) {
      dispatch(fetchSubsidiaryByClientId(record?.client_id));
      setIsEditCompleted(false)
    }
  }, [isEditCompleted])

  // if (record?.products?.length === 0) {
  //   return <Text>No product available</Text>;
  // }
  // console.log('reode', record);
  // console.log('clientContactData', subsidiaryById, clientContactByClientId);
  return (
    <>
    {isOpenedModal ? 


    <Modal 
      isOpen={isOpenedModal}
      onClose={() => setisOpenedModal(false)}
      customSize={modaltype === "contact" || modaltype === 'editContact' ? '720px' : modaltype === "viewContact" ? "320px" : "1080px"}
      overlayClassName="dark:bg-opacity-40 dark:backdrop-blur-lg"
      containerClassName="dark:bg-gray-100"
      className="z-[9990]"
    >
      {modaltype === 'contact' ?
        <AddContactModalView isModalView={false} isOpened={setisOpenedModal} clientId={record?.client_id} data={subsidiaryData} contactType={'worker-admin'} />
      :
      modaltype === 'editContact' ? 
        <EditContactModalView isModalView={false} isOpened={setisOpenedModal} data={selectedContact} />
      :
      modaltype === 'editSubsidiary' ? 
        <EditSubsidiaryModalView isModalView={true} isOpened={setisOpenedModal} data={selectedSubsidiary} />
      :
      modaltype === 'viewContact' ? 
        <ViewContactCard data={viewContactData} />
      :
        <AddSubsidiaryModalView isModalView={true} isOpened={setisOpenedModal} clientId={record?.client_id} />
      }
    </Modal>
    : 
    
    <div className="grid grid-cols-1 bg-gray-0 px-3.5 dark:bg-gray-50">


    {/* {clientContactByClientId?.isLoading ? (
        <Spinner />
      ) : (
        <>
          <BasicTableWidget
            data={clientContactData?.rows}
            getColumns={(columns) =>
              getContactsColumns({
                ...columns,
                onViewContact: handleViewContact,
                onDeleteClientContact: handleDeleteContact,
                onEditContact: handleEditContact
              })
            }
          />
          {selectedContact && (
            <Modal
              isOpen={isContactModalOpen}
              onClose={() => setIsContactModalOpen(false)}
            >
              <ViewData data={selectedContact} view="Contact" isModalView={true} />
            </Modal>
          )}


      <br />
      <div className="flex justify-between">
        <Tooltip
          size="sm"
          content={
            clientContactData?.count === 3
              ? 'Maximum 3 contacts can be added to this client'
              : 'Click to add contact to this client'
          }
          placement="top"
          color="invert"
        >

          <Button
              variant="outline"
                onClick={() => {
                    setisOpenedModal(true)
                    setModaltype('contact')
                  }
                }
              className="mr-2 flex items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
            >
              <BsPlusCircleFill className="mr-2 h-5 w-5 text-gray-500" />
              Add Contact Person
            </Button>
        </Tooltip>
      </div>
        </>
      )} */}




      
      {subsidiaryById?.isLoading ? (
        <Spinner />
      ) : (
        // subsidiaryDetailData?.data_list?.map((subsidiary: any) => (
        <>
          <BasicTableWidget
            data={subsidiaryDetailData?.data_list}
            getColumns={(columns) =>
              getColumns({
                ...columns,
                onViewSubsidiary: handleViewSubsidiary,
                onDeleteClientSubsidiary: handleDeleteSubsidiary,
                onEditSubsidiary: handleEditSubsidiary,
                addContact: handleAddContact,
                viewContact: handleViewContact,
                editProject: handleEditProject,
              })
            }
            expandableBranch
          />
          {selectedSubsidiary && (
            <Modal
              isOpen={isSubsidiaryModalOpen}
              onClose={() => setISubsidiaryModalOpen(false)}
              customSize="720px"
            >
              <ViewData data={selectedSubsidiary} view="Subsidiary" isModalView={true} />
            </Modal>
          )}

      <br/>
      <div className="flex justify-between">
        {/* <h6>Subsidiaries</h6> */}
        <Tooltip
          size="sm"
          content={'Click to add subsidiary to this client'}
          placement="top"
          color="invert"
        >
          {/* <Button
            onClick={() => router?.push(`/clients/${record?.client_id}/add`)}
          >
            Add Subsidiary
          </Button> */}

          <Button
            variant="outline"
              // onClick={() => router?.push(`/clients/${record?.client_id}/add`)}
              onClick={() => {
                  setisOpenedModal(true)
                  setModaltype('subsidiary')
                }
              }
            className="mr-2 flex items-center justify-start px-2 py-2.5 hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-50"
          >
            <BsPlusCircleFill className="mr-2 h-5 w-5 text-gray-500" />
            Add Subsidiary
          </Button>
        </Tooltip>
      </div>
        </>
        // <>
        //   <article
        //     key={subsidiary?.branch_id}
        //     className="flex items-center justify-between py-6 first-of-type:pt-2.5 last-of-type:pb-2.5"
        //   >
        //     <div className="flex items-start">
        //       <header>
        //         <Title as="h4" className="mb-0.5 text-sm font-medium">
        //           {subsidiary?.branch_name}
        //         </Title>
        //         <Text className="mb-1 text-gray-500">
        //           {subsidiary?.email}
        //         </Text>
        //         <Text className="text-xs text-gray-500">
        //           Unique Name: {subsidiary?.branch_unique_name}
        //         </Text>
        //       </header>
        //     </div>
        //     <div className="flex w-full max-w-xs items-center justify-between gap-4">
        //       <div className="flex items-center">
        //         <PiHouseBold size={13} className="me-1 text-gray-500" />{' '}
        //         <Text
        //           as="span"
        //           className="font-medium text-gray-900 dark:text-gray-700"
        //         >
        //           {subsidiary?.address?.town}
        //         </Text>
        //       </div>
        //       {/* <Text className="font-medium text-gray-900 dark:text-gray-700">
        //     ${Number(product.quantity) * Number(product.price)}
        //   </Text> */}
        //     </div>
        //   </article>
        // </>
        // ))
      )}
    </div>
    }
    </>
  );
}
