import cn from '@/utils/class-names';
import { Button } from '@/components/ui/button';
import DeletePopover from '@/app/shared/delete-popover';

interface FormFooterProps {
  _id?: string,
  className?: string;
  altBtnText?: string;
  submitBtnText?: string;
  isLoading?: boolean;
  handleAltBtn?: () => void;
  handleOpenNewForm: () => void;
  onDeleteItem: (data: any) => void,
  isOpenFormDetail?: boolean
}

export const negMargin = '-mx-4 md:-mx-5 lg:-mx-6 3xl:-mx-8 4xl:-mx-10';

export default function FormFooter({
  _id,
  isLoading,
  altBtnText = 'Save as Draft',
  submitBtnText = 'Submit',
  className,
  handleAltBtn,
  handleOpenNewForm,
  onDeleteItem,
  isOpenFormDetail,
}: FormFooterProps) {

  
  return (
    <div
      className={cn(
        'sticky bottom-0 left-0 right-0 flex items-center justify-end gap-4 bg-white px-4 py-4 dark:bg-gray-50 md:px-5 lg:px-6 3xl:px-8 4xl:px-10',
        className,
        // negMargin
      )}
    >
      {isOpenFormDetail &&
        <>
          <DeletePopover
            title={`Delete`}
            description={`Are you sure you want to delete the entry?`}
            onDelete={() => onDeleteItem(_id)}
          />
          <Button
            variant="outline"
            className="w-full @xl:w-auto"
            onClick={handleOpenNewForm}
          >
            + Add New
          </Button>
        </>
      }
      <Button
        variant="outline"
        className="w-full @xl:w-auto"
        onClick={handleAltBtn}
      >
        {altBtnText}
      </Button>
      <Button type="submit" isLoading={isLoading} className="w-full @xl:w-auto">
        {submitBtnText}
      </Button>
    </div>
  );
}
