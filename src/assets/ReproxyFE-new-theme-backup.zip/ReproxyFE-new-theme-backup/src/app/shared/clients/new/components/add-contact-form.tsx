'use client';

import toast from 'react-hot-toast';
import { SubmitHandler, Controller } from 'react-hook-form';
import { PiCaretDownBold, PiEnvelopeSimple } from 'react-icons/pi';
import { Text, Title } from '@/components/ui/text';
import { Form } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import FormGroup from '@/app/shared/form-group';
import { PhoneNumber } from '@/components/ui/phone-input';
import { useRouter } from 'next/navigation';
import {
  clientContactInfoFormTypes,
  contactClientInfoFormSchema,
  defaultValues,
} from '@/utils/validators/contactClient-info.schema';
import { Modal } from '@/components/ui/modal';
import { Collapse } from '@/components/ui/collapse';
import { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { createClientContact } from '@/redux/slices/clientsSlice/createClientContact';
import Spinner from '@/components/ui/spinner';
import { getUserRoleName } from '@/utils/transforms';
import FormFooter from '@/components/form-footer';
import SearchListComponent from './search-list';
import { fetchClientContact } from '@/redux/slices/clientsSlice/getClientContact';
import { fetchClientContactByClientId } from '@/redux/slices/clientsSlice/getClientContactByClientId';
import BasicTableWidget from '@/components/controlled-table/basic-table-widget';
import { deleteClientContactByClientContactId } from '@/redux/slices/clientsSlice/deleteClientContactByClientContactId';
import ViewData from '../../list/components/view-data';
import { getContactsColumns } from '../../list/components/client-contacts-columns';
import { fetchClientContactByClientContactID } from '@/redux/slices/clientsSlice/getClientContactByClientContactId';
import cn from '@/utils/class-names';

interface AddClientContactFormProps {
  client_id?: string;
}
export default function ContactForm({ client_id }: AddClientContactFormProps) {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const role = getUserRoleName(null);

  const CreateClientContactData = useAppSelector(
    (state) => state?.createClientContactData
  );
  const getClientContactByClientId = useAppSelector(
    (state) => state?.getClientContactByClientId
  );
  const getClientContactByClientIdData =
    getClientContactByClientId?.clientContactByClientId?.rows;
  const getClientContact = useAppSelector((state) => state?.getClientContact);
  const getClientContactData = getClientContact?.clientContact?.rows;
  const getClientContactByClientContactIdData = useAppSelector(
    (state) => state?.getClientContactByClientContactIdData
  );
  const clientContactByClientContactID =
    getClientContactByClientContactIdData?.clientContactByClientContactID?.rows;

  const [reset, setResetForm] = useState<boolean>(false);
  const [isOpened, setIsOpened] = useState<boolean>(false);
  const [isOpenSearch, setIsOpenSearch] = useState<boolean>(false);
  const [isOpenFormDetail, setIsOpenFormDetail] = useState<boolean>(false);
  const [clientContactId, setClientContactId] = useState<any>('');
  const [contactName, setContactName] = useState<any>('');
  const [selectedContact, setSelectedContact] = useState<any>([]);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [clientid, setClientID] = useState<any>('');

  const onSubmit: SubmitHandler<clientContactInfoFormTypes> = async (data) => {
    console.log('data', data);
    if (
      getClientContactByClientId?.clientContactByClientId?.rows?.length === 3
    ) {
      toast.error(
        <Text as="b">Maximum 3 contacts can be added to the client!</Text>
      );
    } else {
      try {
        const newdata = { ...data, client_id: client_id };
        const resultAction = await dispatch(createClientContact(newdata));
        if (createClientContact.fulfilled.match(resultAction)) {
          const clientContactData = resultAction.payload;
          setClientContactId(clientContactData?.data?.contact_id);
          toast.success(<Text as="b">Successfully added!</Text>);
          setResetForm(true);
          setIsOpenFormDetail(true);
        } else {
          if (resultAction.payload) {
            toast.error(
              <Text as="b">
                {resultAction.payload?.response?.data?.message_key}
              </Text>
            );
            return;
          } else {
            toast.error('Authentication Failed');
            return;
          }
        }
      } catch (err) {
        console.error(err);
      }
    }
    // console.log('Profile settings data ->', {
    //   ...data,
    //   createClientData,
    // });
  };

  useEffect(() => {
    if (!!getClientContactData === true && getClientContactData.length > 0) {
      for (let i = 0; i < getClientContactData.length; i++) {
        let clientID = getClientContactData[i].client_contacts.client_id;
        setClientID(clientID);
      }
    }
  }, [getClientContactData]);

  useEffect(() => {
    if (!!client_id === true) {
      dispatch(fetchClientContactByClientId(client_id));
    }
  }, [clientContactId, clientid]);

  useEffect(() => {
    if (!!clientContactId === true) {
      dispatch(fetchClientContactByClientContactID(clientContactId));
    }
  }, [clientContactId]);

  const dropDownToggle = (arg: boolean) => {
    setIsOpenSearch(arg);
  };

  const addNewContact = (data: any) => {
    if (data == 'new') {
      setIsOpened(true);
      setIsOpenSearch(false);
      setContactName('');
    } else {
      setIsOpened(true);
      setIsOpenSearch(false);
      setContactName(data);
    }
  };

  useEffect(() => {
    if (
      !!clientContactByClientContactID === true &&
      Object.keys(clientContactByClientContactID).length > 0
    ) {
      setIsOpenFormDetail(true);
    }
  }, [clientContactByClientContactID]);

  const handleViewContact = (subsidiary: any) => {
    setSelectedContact(subsidiary);
    setIsContactModalOpen(true);
  };
  const handleDeleteContact = async (contact: any) => {
    console.log('rowwwww', contact);

    const response = await dispatch(
      deleteClientContactByClientContactId(contact)
    );
    console.log('deletcontact', response);
    if (response?.payload?.status === 'SUCCESS') {
      toast.success(<Text as="b">{response.payload?.message_key}</Text>);
      window.location.reload();
    } else {
      toast.error(
        <Text as="b">{response.payload?.response?.data?.message_key}</Text>
      );
    }
  };
  return (
    <>
      <div className={`rounded-lg border border-muted`}>
        <Collapse
          header={({ open, toggle }) => (
            <div
              onClick={toggle}
              className="flex cursor-pointer items-center justify-between gap-4 p-3 md:p-5"
            >
              <div className="flex gap-2 sm:items-center md:gap-4">
                <div className="sm:flex sm:flex-col">
                  <Title as="h5" className="font-semibold text-gray-900">
                    Add Contact
                  </Title>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    'flex h-6 w-6 items-center justify-center rounded-full bg-gray-100 text-gray-500',
                    open && 'bg-gray-900 text-gray-0'
                  )}
                >
                  <PiCaretDownBold
                    strokeWidth={3}
                    className={cn(
                      'h-3 w-3 rotate-0 transition-transform duration-200 rtl:-rotate-0',
                      open && 'rotate-180 rtl:rotate-180'
                    )}
                  />
                </div>
              </div>
            </div>
          )}
        >
          <section className="p-5">
            <SearchListComponent
              isOpen={isOpenSearch}
              data={getClientContactByClientIdData}
              dropDownToggle={dropDownToggle}
              contactAddition={addNewContact}
              setIsOpened={setIsOpened}
            />
          </section>
          {CreateClientContactData?.isLoading ||
          getClientContactByClientId?.isLoading ? (
            // deleteSubsidiaryData?.isLoading ?
            <Spinner />
          ) : (
            <>
              <BasicTableWidget
                data={getClientContactByClientIdData}
                getColumns={(columns) =>
                  getContactsColumns({
                    ...columns,
                    onViewContact: handleViewContact,
                    onDeleteClientContact: handleDeleteContact,
                  })
                }
              />
              {selectedContact && (
                <Modal
                  isOpen={isContactModalOpen}
                  onClose={() => setIsContactModalOpen(false)}
                >
                  <ViewData data={selectedContact} view="Subsidiary" isModalView={false} />
                </Modal>
              )}
            </>
          )}
          {isOpened && (
            <Form<clientContactInfoFormTypes>
              validationSchema={contactClientInfoFormSchema}
              resetValues={reset && defaultValues}
              onSubmit={onSubmit}
              className="gap-4 p-3 @container md:p-5"
              useFormProps={{
                mode: 'onChange',
                defaultValues,
              }}
            >
              {({
                register,
                control,
                setValue,
                getValues,
                formState: { errors },
              }) => {
                return (
                  <>
                    {CreateClientContactData?.isLoading ? (
                      <Spinner />
                    ) : (
                      <>
                        <FormGroup
                          title="Contact Info Section"
                          description="Enter client contact details here"
                          className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
                        />

                        <div className="mb-5 grid gap-7 @2xl:gap-9 @3xl:gap-11">
                          <FormGroup
                            title="Contact Name"
                            className="pt-5 @2xl:pt-7 @3xl:grid-cols-12 @3xl:pt-9"
                          >
                            <Input
                              placeholder="Contact Name"
                              {...register('name')}
                              value={contactName && contactName}
                              error={errors.name?.message}
                              className="flex-grow"
                            />
                          </FormGroup>

                          <FormGroup
                            title="User Name"
                            className="pt-5 @2xl:pt-7 @3xl:grid-cols-12 @3xl:pt-9"
                          >
                            <Input
                              placeholder="User Name"
                              {...register('user_name')}
                              error={errors.user_name?.message}
                              className="flex-grow"
                            />
                          </FormGroup>

                          <FormGroup
                            title="Email Address"
                            className="@3xl:grid-cols-12"
                          >
                            <Input
                              className="flex-grow"
                              prefix={
                                <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                              }
                              type="email"
                              placeholder="georgia.young@example.com"
                              {...register('email_address')}
                              error={errors.email_address?.message}
                            />
                          </FormGroup>
                          <FormGroup
                            title="Mobile Number"
                            className=" @3xl:grid-cols-12 "
                          >
                            <Controller
                              name="phone"
                              control={control}
                              render={({ field: { value, onChange } }) => (
                                <PhoneNumber
                                  // label="Phone Number"
                                  error={errors.phone?.message}
                                  country="us"
                                  value={value}
                                  onChange={onChange}
                                  className="rtl:[&>.selected-flag]:right-0"
                                  inputClassName="rtl:pr-12"
                                  buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                                />
                              )}
                            />{' '}
                          </FormGroup>
                        </div>
                        <br />
                        <FormFooter
                          // isLoading={isLoading}
                          handleAltBtn={() => router.push('/clients')}
                          altBtnText="Back"
                          submitBtnText="Save Contact"
                        />
                      </>
                    )}
                  </>
                );
              }}
            </Form>
          )}
        </Collapse>
      </div>
    </>
  );
}
