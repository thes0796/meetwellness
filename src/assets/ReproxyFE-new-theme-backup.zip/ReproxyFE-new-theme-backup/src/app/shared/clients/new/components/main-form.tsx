'use client';

import { Title } from '@/components/ui/text';
import { PiCaretDownBold } from 'react-icons/pi';
import cn from '@/utils/class-names';
import { Collapse } from '@/components/ui/collapse';
import ContactForm from './add-contact-form';
import AddClientForm from './add-client-form';
import AddSubsidiaryForm from './add-subsidiary-form';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { useParams } from 'next/navigation';
import { fetchAllClients } from '@/redux/slices/clientsSlice/getClients';
import { useEffect } from 'react';

export default function MainForm() {
  const dispatch = useAppDispatch();
  const params: any = useParams();
  const createClientData = useAppSelector((state) => state?.createClientData);
  const allClientsData = useAppSelector(
    (state) => state?.allClientsData?.clientsData?.data_list
  );
  // useEffect(() => {
  //   dispatch(fetchAllClients(1));
  // }, [params, dispatch]);
  // const toggle = allClientsData?.find(
  //   (item: any) => item?.client_id === params?.slug[0]
  // );
  // console.log('params', params, allClientsData, toggle);

  return (
    <>
      <br />
      <AddClientForm />
      {/* {(toggle || params?.slug[1] === 'add') && (
        <>
          <AddSubsidiaryForm clientId={params?.slug[0]} />
          <ContactForm client_id={params?.slug[0]} />
        </>
      )} */}
    </>
  );
}
