'use client';

import toast from 'react-hot-toast';
import { SubmitHandler, Controller } from 'react-hook-form';
import { PiEnvelopeSimple } from 'react-icons/pi';
import { Form } from '@/components/ui/form';
import { Text } from '@/components/ui/text';
import { Input } from '@/components/ui/input';
// import { Button } from '@/components/ui/button';
// import { Tooltip } from '@/components/ui/tooltip';
import FormGroup from '@/app/shared/form-group';
import FormFooter from '@/components/form-footer';
import { PhoneNumber } from '@/components/ui/phone-input';
import { useParams, useRouter } from 'next/navigation';
import {
  ClientInfoFormTypes,
  clientInfoFormSchema,
  defaultValues,
} from '@/utils/validators/client-info.schema';
// import { useState } from 'react';
// import AddContactForm from './add-contact-modal';
// import AddSubsidiaryForm from './add-subsidiary-modal';
// import OrderTable from '@/app/shared/ecommerce/order/order-list/table';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { createClient } from '@/redux/slices/clientsSlice/createClient';
import Spinner from '@/components/ui/spinner';
import { useEffect, useState } from 'react';
import { fetchClientByClientId } from '@/redux/slices/clientsSlice/getClientByClientId';
import { updateClient } from '@/redux/slices/clientsSlice/updateClient';

export default function EditClientForm() {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const params = useParams();
  const id = params?.slug[0];
  const updateClientData = useAppSelector((state) => state?.editClientData);
  const clientById = useAppSelector((state) => state?.clientById);
  const [formData, setFormData] = useState({
    client_name: clientById?.clientByClientId?.client_name || '',
    client_unique_name: clientById?.clientByClientId?.client_unique_name || '',
    trading_name: clientById?.clientByClientId?.trading_name || '',
    email: clientById?.clientByClientId?.email || '',
    phone_number: clientById?.clientByClientId?.phone_number || '',
    main_contact: clientById?.clientByClientId?.main_contact || '',
    street_address: clientById?.clientByClientId?.address?.street_address || '',
    town: clientById?.clientByClientId?.address?.town || '',
    postcode: clientById?.clientByClientId?.address?.postcode || '',
  });

  const handleChange = (name: any, value: any) => {
    // console.log('e', e);

    // const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  // const [subsidiary, setSubsidiary] = useState<boolean>(false);

  // const closeContactPopup = (toggle: boolean) => {
  //   setContact(toggle);
  // };
  // const closeSubsidiaryPopup = (toggle: boolean) => {
  //   setSubsidiary(toggle);
  // };
  useEffect(() => {
    dispatch(fetchClientByClientId(id));
  }, [dispatch]);

  const onSubmit: SubmitHandler<ClientInfoFormTypes> = async (data) => {
    try {
      const updatedData = { ...data, client_id: id };
      const clientResponse = await dispatch(updateClient(updatedData));
      if (clientResponse.payload.status === 'SUCCESS') {
        toast.success(
          <Text as="b">{clientResponse.payload?.message_key}</Text>
        );
        router.push('/clients');
      } else if (clientResponse.payload.status !== 'SUCCESS') {
        toast.error(
          <Text as="b">
            {clientResponse.payload?.response?.data?.message_key}
          </Text>
        );
        return;
      }
    } catch (err) {
      console.error(err);
    }
    console.log('Profile settings data ->', {
      ...data,
      updateClientData,
    });
  };
  console.log('data ->', clientById, formData);

  return (
    <Form<ClientInfoFormTypes>
      validationSchema={clientInfoFormSchema}
      // resetValues={reset}
      onSubmit={onSubmit}
      className="@container"
    >
      {({ register, control, formState: { errors }, setValue, getValues }) => {
        return (
          <>
            {!clientById?.isSuccess || updateClientData?.isLoading ? (
              <Spinner />
            ) : (
              <>
                <FormGroup
                  title="Company Info Section"
                  description="Update company details here"
                  className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
                />
                <div className="mb-5 grid gap-7 @2xl:gap-9 @3xl:gap-11">
                  <FormGroup
                    title="Company Name"
                    className="pt-5 @2xl:pt-7 @3xl:grid-cols-12 @3xl:pt-9"
                  >
                    <Input
                      placeholder="Company Name"
                      {...register('client_name')}
                      value={
                        formData?.client_name ||
                        clientById?.clientByClientId?.client_name
                      }
                      onChange={(e: any) =>
                        handleChange('client_name', e.target.value)
                      }
                      error={errors.client_name?.message}
                      className="flex-grow"
                    />
                  </FormGroup>
                  <FormGroup title="Unique Name" className=" @3xl:grid-cols-12">
                    <Input
                      placeholder="Unique Name"
                      {...register('client_unique_name')}
                      value={
                        formData?.client_unique_name ||
                        clientById?.clientByClientId?.client_unique_name
                      }
                      onChange={(e: any) =>
                        handleChange('client_unique_name', e.target.value)
                      }
                      error={errors.client_unique_name?.message}
                      className="flex-grow"
                    />
                  </FormGroup>
                  <FormGroup
                    title="Trading Name"
                    className=" @3xl:grid-cols-12"
                  >
                    <Input
                      placeholder="Trading Name"
                      {...register('trading_name')}
                      value={
                        formData?.trading_name ||
                        clientById?.clientByClientId?.trading_name
                      }
                      onChange={(e: any) =>
                        handleChange('trading_name', e.target.value)
                      }
                      error={errors.trading_name?.message}
                      className="flex-grow"
                    />
                  </FormGroup>
                  <FormGroup
                    title="Email Address"
                    className="@3xl:grid-cols-12"
                  >
                    <Input
                      className="flex-grow"
                      {...register('email')}
                      prefix={
                        <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                      }
                      type="email"
                      placeholder="georgia.young@example.com"
                      value={
                        formData?.email || clientById?.clientByClientId?.email
                      }
                      onChange={(e: any) =>
                        handleChange('email', e.target.value)
                      }
                      error={errors.email?.message}
                    />
                  </FormGroup>
                  <FormGroup
                    title="Mobile Number"
                    className=" @3xl:grid-cols-12 "
                  >
                    <Controller
                      name="phone_number"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <PhoneNumber
                          // label="Phone Number"
                          {...register('phone_number')}
                          placeholder="Phone Number"
                          error={errors.phone_number?.message}
                          country="us"
                          value={
                            formData?.phone_number ||
                            clientById?.clientByClientId?.phone_number
                          }
                          onChange={(e: any) =>
                            handleChange('phone_number', e.target)
                          }
                          className="rtl:[&>.selected-flag]:right-0"
                          inputClassName="rtl:pr-12"
                          buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                        />
                      )}
                    />
                  </FormGroup>
                  <FormGroup
                    title="Main Contact Number"
                    className=" @3xl:grid-cols-12 "
                  >
                    <Controller
                      name="main_contact"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <PhoneNumber
                          {...register('main_contact')}
                          placeholder="Main Contact Number"
                          country="us"
                          error={errors.main_contact?.message}
                          value={
                            formData?.main_contact ||
                            clientById?.clientByClientId?.main_contact
                          }
                          onChange={(e: any) =>
                            handleChange('main_contact', e.target)
                          }
                          className="rtl:[&>.selected-flag]:right-0"
                          inputClassName="rtl:pr-12"
                          buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                        />
                      )}
                    />
                  </FormGroup>
                  <FormGroup
                    title="Address:"
                    className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
                  />
                  <FormGroup title="Street" className="@3xl:grid-cols-12">
                    <Input
                      placeholder="Street"
                      {...register('street_address')}
                      value={
                        formData?.street_address ||
                        clientById?.clientByClientId?.address?.street_address
                      }
                      onChange={(e: any) =>
                        handleChange('street_address', e.target.value)
                      }
                      error={errors.street_address?.message}
                      className="col-span-full"
                    />{' '}
                  </FormGroup>

                  <FormGroup title="Town" className="@3xl:grid-cols-12">
                    <Input
                      placeholder="Town Name"
                      {...register('town')}
                      value={
                        formData?.town ||
                        clientById?.clientByClientId?.address?.town
                      }
                      onChange={(e: any) =>
                        handleChange('town', e.target.value)
                      }
                      error={errors.town?.message}
                      className="flex-grow"
                    />{' '}
                  </FormGroup>

                  <FormGroup title="Post Code" className="@3xl:grid-cols-12">
                    <Input
                      placeholder="Postcode"
                      {...register('postcode')}
                      value={
                        formData?.postcode ||
                        clientById?.clientByClientId?.address?.postcode
                      }
                      onChange={(e: any) =>
                        handleChange('postcode', e.target.value)
                      }
                      error={errors.postcode?.message}
                      className="flex-grow"
                    />
                  </FormGroup>
                </div>
                <br />
                <hr />
                {/* <FormGroup
              title="Contact Info Section"
              description="Update contact details here"
              className="py-2 @2xl:py-5 @3xl:grid-cols-12 @3xl:py-7"
            />
            <Tooltip
              placement="right"
              color="invert"
              content="maximum number of contacts allowed: 3"
            >
              <Button
                onClick={() => {
                  setContact(true);
                }}
              >
                Add Contacts
              </Button>
            </Tooltip>
            <br />
            {contact && (
              <AddContactForm
                toggle={contact}
                handleClose={closeContactPopup}
              />
            )}
            <br />
            <hr />
            <FormGroup
              title="Subsidiary Info Section"
              description="Update subsidiary details here"
              className="py-2 @2xl:py-5 @3xl:grid-cols-12 @3xl:py-7"
            />
            <OrderTable
              data={orderData}
              variant="elegant"
              className="[&_.table-filter]:hidden [&_.table-pagination]:hidden"
            />
            <br />
            <Tooltip
              color="invert"
              placement="right"
              content="Click to add a Subsidiary"
            >
              <Button
                onClick={() => {
                  setSubsidiary(true);
                }}
              >
                Add Subsidiaries
              </Button>
            </Tooltip>
            {subsidiary && (
              <AddSubsidiaryForm
                toggle={subsidiary}
                handleClose={closeSubsidiaryPopup}
              />
            )} */}
                <FormFooter
                  // isLoading={isLoading}
                  handleAltBtn={() => router.push('/clients')}
                  altBtnText="Back"
                  submitBtnText="Update Client"
                />
              </>
            )}
          </>
        );
      }}
    </Form>
  );
}
