'use client';

import { Fragment, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { Input } from '@/components/ui/input';
import { Title, Text } from '@/components/ui/text';
import { Button } from '@/components/ui/button';
import { ActionIcon } from '@/components/ui/action-icon';
import { Empty, SearchNotFoundIcon } from '@/components/ui/empty';
import {
  PiFileTextDuotone,
  PiMagnifyingGlassBold,
  PiXBold,
} from 'react-icons/pi';
import cn from '@/utils/class-names';
import AvatarCard from '@/components/ui/avatar-card';

export default function SearchListComponent({
  isOpen,
  data,
  contactAddition,
  dropDownToggle,
  setIsOpened
}: {
  isOpen: boolean;
  data: any[];
  contactAddition: (data: any) => void;
  dropDownToggle: (arg: boolean) => void;
  setIsOpened: (arg: boolean) => void;
}) {
  const inputRef: any = useRef(null);
  const [searchText, setSearchText] = useState('');
  const [selectedContact, setSelectedContact] = useState('');
  const [dropdownOpen, setDropdownOpen] = useState(false);

  let menuItemsFiltered = data;
  if (searchText.length > 0) {
    menuItemsFiltered = data?.filter((item: any) => {
      const label = item?.user_name;
      return (
        label?.match(searchText?.toLowerCase()) ||
        (label?.toLowerCase()?.match(searchText?.toLowerCase()) && label)
      );
    });
  }

  useEffect(() => {
    if (inputRef?.current) {
      inputRef.current.focus();
    }
    return () => {
      inputRef.current = null;
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (inputRef.current && !inputRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleContactSelection = (data: any) => {
    setSelectedContact(
      `${data?.user_name}`
    );
    contactAddition(data?.user_name);
    setSearchText('');
  };
  console.log('selectedContact', selectedContact);

  return (
    <>
      <div className="" style={{width: "auto"}}>
        <Input
          variant="flat"
          value={searchText || selectedContact}
          ref={inputRef}
          onChange={(e) => {
            setSearchText(e.target.value)
            searchText.length == 0 && setSelectedContact('')
          }}
          onClear={() => {
            setSearchText('');
            setSelectedContact('');
          }}
          onFocus={() => {
            setDropdownOpen(true);
            dropDownToggle(true);
            setIsOpened(false)
          }}
          placeholder="Search Contact..."
          className="flex-1/4"
          clearable
          prefix={
            <PiMagnifyingGlassBold className="h-[12px] w-[12px] text-gray-600" />
          }
        />
      </div>
      {isOpen && (
        <div className="custom-scrollbar flex-1/4 relative z-10 mt-2 h-[60vh] overflow-y-auto border bg-white px-2 py-4" style={{height: "auto", width: "auto", borderRadius:"5px"}}>
          {menuItemsFiltered?.length > 0 ? (
            menuItemsFiltered?.map((item, index) => (
              <Fragment key={index}>
                <div
                  onClick={() => handleContactSelection(item)}
                  className="relative my-0.5 flex items-center rounded-lg py-2 pl-3 pr-6 text-sm hover:bg-gray-100 focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg"
                >
                  <span className="ms-3 grid gap-0.5 hover:cursor-pointer">
                    <AvatarCard
                      src=""
                      name={`${item.user_name}`}
                    />
                  </span>
                </div>
              </Fragment>
            ))
          ) : (
            <div className="p-5 text-center">No Data</div>
          )}
          <Fragment>

            {searchText.length > 0 &&
              <div
                onClick={() => {
                  contactAddition(searchText)
                  dropDownToggle(false)
                }}
                className="relative my-0.5 flex items-center rounded-lg py-2 pl-3 pr-6 text-sm hover:bg-gray-100 focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg"
              >
                <span className="ms-3 grid gap-0.5 hover:cursor-pointer">
                <figure className={'flex items-center gap-3'}>
                  <figcaption className="grid gap-0.5">
                    <Text className="font-lexend text-sm font-medium text-gray-900 dark:text-gray-700">
                      + Add &apos;{searchText}&apos; as a new contact
                    </Text>
                  </figcaption>
                </figure>
                </span>
              </div>
            }

            <div
              onClick={() => contactAddition('new')}
              className="relative my-0.5 flex items-center rounded-lg py-2 pl-3 pr-6 text-sm hover:bg-gray-100 focus:outline-none focus-visible:bg-gray-100 dark:hover:bg-gray-50/50 dark:hover:backdrop-blur-lg"
            >
              <span className="ms-3 grid gap-0.5 hover:cursor-pointer">
              <figure className={'flex items-center gap-3'}>
                <figcaption className="grid gap-0.5">
                  <Text className="font-lexend text-sm font-medium text-gray-900 dark:text-gray-700">
                    + Add New Contact
                  </Text>
                </figcaption>
              </figure>
              </span>
            </div>
          </Fragment>
        </div>
      )}
    </>
  );
}
