'use client';

import toast from 'react-hot-toast';
import { SubmitHandler, Controller } from 'react-hook-form';
import { PiEnvelopeSimple } from 'react-icons/pi';
import { Form } from '@/components/ui/form';
import { Text } from '@/components/ui/text';
import { Input } from '@/components/ui/input';
import FormGroup from '@/app/shared/form-group';
import FormFooter from '@/components/form-footer';
import { PhoneNumber } from '@/components/ui/phone-input';
import { useParams, useRouter } from 'next/navigation';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import Spinner from '@/components/ui/spinner';
import { useEffect, useState } from 'react';
import { fetchClientContactByClientContactID } from '@/redux/slices/clientsSlice/getClientContactByClientContactId';
import {
  clientContactInfoFormTypes,
  contactClientInfoFormSchema,
} from '@/utils/validators/contactClient-info.schema';
import { updateClientContact } from '@/redux/slices/clientsSlice/updateClientContact';

export default function EditClientContactForm() {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const params = useParams();
  const id = params?.slug[2];
  const client_id = params?.slug[0];
  const updateClientContactData = useAppSelector(
    (state) => state?.updateClientContactData
  );
  const clientContactByContactId = useAppSelector(
    (state) => state?.getClientContactByClientContactIdData
  );

  useEffect(() => {
    const newData = { client_id: client_id, client_contact_id: id };
    dispatch(fetchClientContactByClientContactID(newData));
  }, [dispatch, id]);

  const contactData =
    clientContactByContactId?.clientContactByClientContactID?.rows?.length > 0
      ? clientContactByContactId?.clientContactByClientContactID?.rows[0]
      : {};

  const [formData, setFormData] = useState({
    name: contactData?.contacts?.name,
    user_name: contactData?.contacts?.user_name,
    email_address: contactData?.email_address,
    phone: contactData?.phone,
  });

  const handleChange = (name: any, value: any) => {
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const onSubmit: SubmitHandler<clientContactInfoFormTypes> = async (data) => {
    try {
      const updatedData = { ...data, client_contact_id: id };
      const response = await dispatch(updateClientContact(updatedData));
      if (response.payload.status === 'SUCCESS') {
        toast.success(<Text as="b">{response.payload?.message_key}</Text>);
        router.push('/clients');
      } else if (response.payload.status !== 'SUCCESS') {
        toast.error(
          <Text as="b">{response.payload?.response?.data?.message_key}</Text>
        );
        return;
      }
    } catch (err) {
      console.error(err);
    }
    console.log('Profile settings data ->', {
      ...data,
      updateClientContactData,
    });
  };
  console.log('data ->', contactData, clientContactByContactId);

  return (
    <Form<clientContactInfoFormTypes>
      validationSchema={contactClientInfoFormSchema}
      // resetValues={reset}
      onSubmit={onSubmit}
      className="@container"
    >
      {({ register, control, formState: { errors }, setValue, getValues }) => {
        return (
          <>
            {clientContactByContactId?.isLoading ||
            updateClientContactData?.isLoading ? (
              <Spinner />
            ) : (
              <>
                <FormGroup
                  title="Contact Info Section"
                  description="Enter client contact details here"
                  className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
                />

                <div className="mb-5 grid gap-7 @2xl:gap-9 @3xl:gap-11">
                  <FormGroup
                    title="Contact Name"
                    className="pt-5 @2xl:pt-7 @3xl:grid-cols-12 @3xl:pt-9"
                  >
                    <Input
                      placeholder="Contact Name"
                      {...register('name')}
                      value={formData?.name || contactData?.contacts?.name}
                      onChange={(e: any) =>
                        handleChange('name', e.target.value)
                      }
                      error={errors.name?.message}
                      className="flex-grow"
                    />
                  </FormGroup>

                  <FormGroup
                    title="User Name"
                    className="pt-5 @2xl:pt-7 @3xl:grid-cols-12 @3xl:pt-9"
                  >
                    <Input
                      placeholder="User Name"
                      {...register('user_name')}
                      value={formData?.user_name || contactData?.user_name}
                      onChange={(e: any) =>
                        handleChange('user_name', e.target.value)
                      }
                      error={errors.user_name?.message}
                      className="flex-grow"
                    />
                  </FormGroup>

                  <FormGroup
                    title="Email Address"
                    className="@3xl:grid-cols-12"
                  >
                    <Input
                      className="flex-grow"
                      prefix={
                        <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                      }
                      type="email"
                      placeholder="georgia.young@example.com"
                      {...register('email_address')}
                      value={
                        formData?.email_address || contactData?.email_address
                      }
                      onChange={(e: any) =>
                        handleChange('email_address', e.target.value)
                      }
                      error={errors.email_address?.message}
                    />
                  </FormGroup>
                  <FormGroup
                    title="Mobile Number"
                    className=" @3xl:grid-cols-12 "
                  >
                    <Controller
                      name="phone"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <PhoneNumber
                          // label="Phone Number"
                          error={errors.phone?.message}
                          country="us"
                          value={formData?.phone || contactData?.phone}
                          onChange={(e: any) => handleChange('phone', e.target)}
                          className="rtl:[&>.selected-flag]:right-0"
                          inputClassName="rtl:pr-12"
                          buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                        />
                      )}
                    />{' '}
                  </FormGroup>
                </div>
                <br />
                <FormFooter
                  // isLoading={isLoading}
                  handleAltBtn={() => router.push('/clients')}
                  altBtnText="Back"
                  submitBtnText="Update Contact"
                />
              </>
            )}
          </>
        );
      }}
    </Form>
  );
}
