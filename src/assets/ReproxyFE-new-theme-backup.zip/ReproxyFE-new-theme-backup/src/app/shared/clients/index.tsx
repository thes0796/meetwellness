'use client';

import ClientsListTable from './list/clients-list';

export default function ClientsComponent() {
  return (
    <>
      <ClientsListTable />
    </>
  );
}
