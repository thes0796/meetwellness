'use client';

import Link from 'next/link';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Tooltip } from '@/components/ui/tooltip';
import { ActionIcon } from '@/components/ui/action-icon';
import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
// import TableAvatar from '@/components/ui/avatar-card';
import DateCell from '@/components/ui/date-cell';
import DeletePopover from '@/app/shared/delete-popover';
import { Checkbox } from '@/components/ui/checkbox';
import {
  PiDeviceMobileCameraDuotone,
  PiEnvelopeDuotone,
  PiPhoneCallDuotone,
  PiUserLight, 
  PiPlusLight,
} from 'react-icons/pi';
import AvatarCard from '@/components/ui/avatar-card';
import DropdownWithEditModal from './DropDownWithEditModal';

type Columns = {
  sortConfig?: any;
  onDeleteClientSubsidiary?: (id: string) => void;
  onHeaderCellClick: (value: string) => void;
  onViewSubsidiary?: (row: any) => void;
  onEditSubsidiary?: (row: any) => void;
  addContact?: (row: any) => void;
  viewContact?: (row: any) => void;
  editProject: (_: any) => void;
};

export const getColumns = ({
  sortConfig,
  onDeleteClientSubsidiary,
  onHeaderCellClick,
  onViewSubsidiary,
  onEditSubsidiary,
  addContact,
  viewContact,
  editProject
}: Columns) => [
  {
    title: <HeaderCell title="" />,
    dataIndex: '',
    key: '',
    width: 43,
    hidden: 'name',
    // render: (value: any) => <Text>{value}</Text>,
    render: (_: any, row: any) => (
      <></>
    )
  },
  {
    title: (
      <HeaderCell 
        title="Subsidiary Name"
        sortable 
        ascending={
          sortConfig?.direction === 'asc' && sortConfig?.key === 'branch_name'
        }
      />
    ),
    onHeaderCell: () => onHeaderCellClick('branch_name'),
    dataIndex: 'branch_name',
    key: 'branch_name',
    width: 145,
    hidden: 'name',
    // render: (value: any) => <Text>{value}</Text>,
    render: (_: any, row: any) => (
      // <TableAvatar
      //   src={row?.profile_pic}
      //   name={row?.branch_name}
      // />
      <AvatarCard
        src={row?.company_logo}
        name={row?.branch_name.length > 13 ? row?.branch_name.substring(0, 13) + '...' : row?.branch_name}
        avatarProps={{
          name: row?.branch_name,
          size: 'lg',
          className: 'rounded-lg',
        }}
      />
    )
  },
  {
    title: (
      <HeaderCell 
        title="Nick Name"
        sortable 
        ascending={
          sortConfig?.direction === 'asc' && sortConfig?.key === 'branch_unique_name'
        }
      />
    ),
    onHeaderCell: () => onHeaderCellClick('branch_unique_name'),
    dataIndex: 'branch_unique_name',
    key: 'branch_unique_name',
    width: 150,
    render: (value: any) => <Text>{value.length > 13 ? value.substring(0, 13) + '...' : value}</Text>,
  },
  {
    title: <HeaderCell title="Location" />,
    dataIndex: 'address',
    key: 'address',
    width: 150,
    render: (value: any) => <Text>{value?.street_address && value?.street_address?.length > 13 ? value?.street_address.substring(0, 13) + '...' : value?.street_address}</Text>,
  },

  { title: <HeaderCell title="Projects" />,
    dataIndex: 'projects',
    key: 'projects',
    width: 100,
    render: (_: string, row: any) => {
      return (
        <>
          <DropdownWithEditModal data={row?.projects} editProject={editProject}/>
        </>
      )
    },
  },

  {
    title: <HeaderCell title="Managers" />,
    dataIndex: 'contacts',
    key: 'contacts',
    width: 150,
    render: (_: string, row: any) => {
      const updatedArray = row.contacts.length > 0 && row.contacts.map((item: any) => ({
        ...item,
        company_name: row.branch_name
      }));
      return (
      <>
      {row.contacts.length > 0 && updatedArray && updatedArray.map((v: any, index: any) => (
        <span className='pr-2' key={index}>
        <Tooltip
          size="sm"
          content={`${v?.user?.first_name} ${v?.user?.last_name ? v?.user?.last_name: ""}`}
          placement="top"
          color="invert"
        >
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            className="hover:cursor-pointer hover:text-gray-700"
            onClick={() => viewContact && viewContact(v)}
          >
            <PiUserLight className="h-4 w-4" />
          </ActionIcon>
        </Tooltip>
        </span>
        ))}

        {row.contacts.length < 3 &&
        <Tooltip
          size="sm"
          content={'Add Manager'}
          placement="top"
          color="invert"
          
        >
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            className="hover:cursor-pointer hover:text-gray-700"
            onClick={() => addContact && addContact(row)}
          >
            <PiPlusLight className="h-4 w-4" />
          </ActionIcon>
        </Tooltip>
        }
      </>
      )
    },
  },

  {
    title: <HeaderCell title="Contact" />,
    dataIndex: 'email',
    key: 'email',
    width: 100,
    hidden: 'name',
    render: (_: string, row: any) => (
      <>
      <a href={`mailto:${row?.email}`}>
      <Tooltip size="sm" content={row?.email} placement="top" color="invert">
        <ActionIcon
          as="span"
          size="sm"
          variant="outline"
          className="hover:cursor-pointer hover:text-gray-700"
        >
          <PiEnvelopeDuotone className="h-4 w-4" />
        </ActionIcon>
      </Tooltip>
      </a>
      <a href={`tel:${row?.phone_number}`} className='pl-2'>
      <Tooltip size="sm" content={row?.phone_number} placement="top" color="invert">
        <ActionIcon
          as="span"
          size="sm"
          variant="outline"
          className="hover:cursor-pointer hover:text-gray-700"
        >
          <PiPhoneCallDuotone className="h-4 w-4" />
        </ActionIcon>
      </Tooltip>
      </a>
      </>
    ),
  },
  // {
  //   title: <HeaderCell title="Phone" />,
  //   dataIndex: 'phone',
  //   key: 'phone',
  //   // width: 100,
  //   hidden: 'name',
  //   render: (_: string, row: any) => (
  //     <a href={`tel:${row?.phone}`}>
  //     <Tooltip size="sm" content={row?.phone} placement="top" color="invert">
  //       <ActionIcon
  //         as="span"
  //         size="sm"
  //         variant="outline"
  //         className="hover:cursor-pointer hover:text-gray-700"
  //       >
  //         <PiPhoneCallDuotone className="h-4 w-4" />
  //       </ActionIcon>
  //     </Tooltip>
  //     </a>
  //   ),
  // },

  

  {
    // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
    title: <HeaderCell title="Actions" className="" />,
    dataIndex: 'action',
    key: 'action',
    width: 50,
    render: (_: string, row: any) => (
      <div className="flex items-center gap-3 pe-0">
        <Tooltip
          size="sm"
          content={row.contacts.length < 1 ? 'Edit' : 'Restricted'}
          placement="top"
          color="invert"
        >
          {/* <Link
            href={`/clients/subsidiary/${row?.branch_id}/edit`}
            // target="_blank"
          > */}
            <ActionIcon
              as="span"
              size="sm"
              variant="outline"
              className="hover:text-gray-700 hover:cursor-pointer"
              onClick={() => row.contacts.length < 1 && onEditSubsidiary && onEditSubsidiary(row)}
              disabled={row.contacts.length > 0 ? true : false}
            >
              <PencilIcon className="h-4 w-4" />
            </ActionIcon>
          {/* </Link> */}
        </Tooltip>
        <Tooltip
          size="sm"
          content={'View'}
          placement="top"
          color="invert"
        >
          {/* <Link href="/clients/view" target="_blank"> */}
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            className="hover:cursor-pointer hover:text-gray-700"
            onClick={() => onViewSubsidiary && onViewSubsidiary(row)}
          >
            <EyeIcon className="h-4 w-4" />
          </ActionIcon>
          {/* </Link> */}
        </Tooltip>

        <DeletePopover
          title={`Delete the subsidiary`}
          description={`Are you sure you want to delete this #${row.branch_name} order?`}
          onDelete={() =>
            onDeleteClientSubsidiary && onDeleteClientSubsidiary(row.branch_id)
          }
        />
      </div>
    ),
  },
];
