'use client';

import Link from 'next/link';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Select } from '@/components/ui/select';
import { Tooltip } from '@/components/ui/tooltip';
import { ActionIcon } from '@/components/ui/action-icon';
import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
// import TableAvatar from '@/components/ui/avatar-card';
import DateCell from '@/components/ui/date-cell';
import DeletePopover from '@/app/shared/delete-popover';
import { Checkbox } from '@/components/ui/checkbox';
import AvatarCard from '@/components/ui/avatar-card';
import { PiPhoneCallDuotone, PiEnvelopeDuotone, PiUserBold, PiUserLight, PiPlusBold, PiPlusLight } from 'react-icons/pi';
import DropdownWithEditModal from './DropDownWithEditModal';

type Columns = {
  sortConfig?: any;
  onDeleteClient?: (id: string) => void;
  onHeaderCellClick: (value: string) => void;
  onViewClient?: (row: any) => void;
  onEditClient?: (row: any) => void;
  addContact?: (row: any) => void;
  viewContact?: (row: any) => void;
  editProject: (_: any) => void;
};

export const getColumns = ({
  sortConfig,
  onDeleteClient,
  onHeaderCellClick,
  onViewClient,
  onEditClient,
  addContact,
  viewContact,
  editProject,
}: Columns) => [
  // {
  //   title: (
  //     <div className="ps-2">
  //       <Checkbox
  //         title={'Select All'}
  //         onChange={handleSelectAll}
  //         checked={checkedItems.length === data.length}
  //         className="cursor-pointer"
  //       />
  //     </div>
  //   ),
  //   dataIndex: 'checked',
  //   key: 'checked',
  //   width: 30,
  //   render: (_: any, row: any) => (
  //     <div className="inline-flex ps-2">
  //       <Checkbox
  //         className="cursor-pointer"
  //         checked={checkedItems.includes(row?.user_id)}
  //         {...(onChecked && { onChange: () => onChecked(row?.user_id) })}
  //       />
  //     </div>
  //   ),
  // },
  // {
  //   title: <HeaderCell title="Company ID" />,
  //   dataIndex: 'client_id',
  //   key: 'client_id',
  //   width: 160,
  //   render: (value: any) => <Text>{value?.slice(0, 8)}</Text>,
  // },
  {
    title: (
      <HeaderCell 
        title="Company Name" 
        sortable 
        ascending={
          sortConfig?.direction === 'asc' && sortConfig?.key === 'client_name'
        }
      />
    ),
    onHeaderCell: () => onHeaderCellClick('client_name'),
    dataIndex: 'client_name',
    key: 'client_name',
    width: 150,
    hidden: 'client',
    render: (_: any, row: any) => (
      // <TableAvatar
      //   src={row?.profile_pic}
      //   name={row?.client_name}
      // />
      <AvatarCard
        src={row?.company_logo}
        name={row?.client_name.length > 13 ? row?.client_name.substring(0, 13) + '...' : row?.client_name}
        avatarProps={{
          name: row?.client_name,
          size: 'lg',
          className: 'rounded-lg',
        }}
      />
    ),
  },
  {
    title: (
      <HeaderCell 
        title="Nick Name"
        sortable 
        ascending={
          sortConfig?.direction === 'asc' && sortConfig?.key === 'client_unique_name'
        }
       />
    ),
    onHeaderCell: () => onHeaderCellClick('client_unique_name'),
    dataIndex: 'client_unique_name',
    key: 'client_unique_name',
    width: 150,
    hidden: 'name',
    render: (value: any) => <Text>{value.length > 13 ? value.substring(0, 13) + '...' : value}</Text>,
  },

  {
    title: (
      <HeaderCell 
        title="Location"
        // sortable 
        // ascending={
        //   sortConfig?.direction === 'asc' && sortConfig?.key === 'address'
        // }
      />
    ),
    // onHeaderCell: () => onHeaderCellClick('address'),
    dataIndex: 'address',
    key: 'address',
    width: 150,
    render: (value: any) => <Text>{value?.street_address.length > 13 ? value?.street_address.substring(0, 13) + '...' : value?.street_address}</Text>,
  },
  { title: <HeaderCell title="Projects" />,
    dataIndex: 'projects',
    key: 'projects',
    width: 100,
    render: (_: string, row: any) => {
      return (
        <>
          <DropdownWithEditModal data={row?.projects} editProject={editProject}/>
        </>
      )
    },
  },
  {
    title: <HeaderCell title="Managers" />,
    dataIndex: 'contacts',
    key: 'contacts',
    width: 150,
    render: (_: string, row: any) => {
      const updatedArray = row && row.contacts && row.contacts.length > 0 && row.contacts.map((item: any) => ({
        ...item,
        company_name: row.client_name
      }));
      return (
      <>
      {row && row.contacts && row.contacts.length > 0 && updatedArray && updatedArray.map((v: any, index: any) => (
        
        <span className='pr-2' key={index}>
        <Tooltip
          size="sm"
          content={`${v?.user?.first_name} ${v?.user?.last_name ? v?.user?.last_name: ""}`}
          placement="top"
          color="invert"
        >
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            className="hover:cursor-pointer hover:text-gray-700"
            onClick={() => viewContact && viewContact(v)}
          >
            <PiUserLight className="h-4 w-4" />
          </ActionIcon>
        </Tooltip>
        </span>
        ))}

        {row && row.contacts && row.contacts.length < 3 &&
        // <span className='pl-2'>
        
        <Tooltip
          size="sm"
          content={'Add Manager'}
          placement="top"
          color="invert"
          
        >
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            className="hover:cursor-pointer hover:text-gray-700"
            onClick={() => addContact && addContact(row)}
          >
            <PiPlusLight className="h-4 w-4" />
          </ActionIcon>
        </Tooltip>
        // </span>
        }
      </>
    )
  }
  },
  {
    title: <HeaderCell title="Contact" />,
    dataIndex: 'main_contact',
    key: 'main_contact',
    width: 100,
    render: (_: string, row: any) => (
      <>
      <a href={`mailto:${row?.email}`}>
        <Tooltip
          size="sm"
          content={row?.email}
          placement="top"
          color="invert"
        >
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            className="hover:cursor-pointer hover:text-gray-700"
          >
            <PiEnvelopeDuotone className="h-4 w-4" />
          </ActionIcon>
        </Tooltip>
      </a>

      <a href={`tel:${row?.main_contact}`} className='pl-2'>
        <Tooltip
          size="sm"
          content={row?.main_contact}
          placement="top"
          color="invert"
        >
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            className="hover:cursor-pointer hover:text-gray-700"
          >
            <PiPhoneCallDuotone className="h-4 w-4" />
          </ActionIcon>
        </Tooltip>
      </a>
      </>
    ),
  },
  // {
  //   title: <HeaderCell title="Subsidiaries" />,
  //   dataIndex: 'subsidiaries',
  //   key: 'subsidiaries',
  //   width: 160,
  //   render: (value: any) => <Text>{value}</Text>,
  // },
  // {
  //   title: (
  //     <HeaderCell
  //       title="Created"
  //       sortable
  //       ascending={
  //         sortConfig?.direction === 'asc' && sortConfig?.key === 'created_at'
  //       }
  //     />
  //   ),
  //   onHeaderCell: () => onHeaderCellClick('created_at'),
  //   dataIndex: 'created_at',
  //   key: 'created_at',
  //   width: 160,
  //   render: (value: Date) => <DateCell date={value} />,
  // },

  {
    // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
    title: <HeaderCell title="Actions" />,
    dataIndex: 'action',
    key: 'action',
    width: 50,
    render: (_: string, row: any) => (
      <div className="flex items-center gap-3 pe-4">
        <Tooltip
          size="sm"
          content={row && row.contacts && row.contacts.length < 1 ? 'Edit' : 'Restricted'}
          placement="top"
          color="invert"
        >
          {/* <Link href={`/clients/${row?.client_id}/edit`} target="_blank"> */}
            <ActionIcon
              as="span"
              size="sm"
              variant="outline"
              className="hover:text-gray-700 hover:cursor-pointer"
              onClick={() => row && row.contacts && row.contacts.length < 1 && onEditClient && onEditClient(row)}
              disabled={row && row.contacts && row.contacts.length > 0 ? true : false}
            >
              <PencilIcon className="h-4 w-4" />
            </ActionIcon>
          {/* </Link> */}
        </Tooltip>
        <Tooltip
          size="sm"
          content={'View'}
          placement="top"
          color="invert"
        >
          {/* <Link href="/clients/view" target="_blank"> */}
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            className="hover:cursor-pointer hover:text-gray-700"
            onClick={() => onViewClient && onViewClient(row)}
          >
            <EyeIcon className="h-4 w-4" />
          </ActionIcon>
          {/* </Link> */}
        </Tooltip>

        <DeletePopover
          title={`Delete the client`}
          description={`Are you sure you want to delete this #${row.client_name} order?`}
          onDelete={() => onDeleteClient && onDeleteClient(row.client_id)}
        />
      </div>
    ),
  },
];
