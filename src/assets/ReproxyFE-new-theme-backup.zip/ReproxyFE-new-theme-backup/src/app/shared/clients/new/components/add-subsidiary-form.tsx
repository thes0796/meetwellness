'use client';

import { Text, Title } from '@/components/ui/text';
import { Textarea } from '@/components/ui/textarea';
import { Modal } from '@/components/ui/modal';
import { PiCaretDownBold } from 'react-icons/pi';
import cn from '@/utils/class-names';
import { Collapse } from '@/components/ui/collapse';
import { Form } from '@/components/ui/form';
import {
  SubsidiaryBySPInfoFormTypes,
  subsidiaryBySPInfoFormSchema,
  defaultValues,
} from '@/utils/validators/subsidiary-info-SP.schema';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { createSubsidiary } from '@/redux/slices/subsidiarySlice/createSubsidiary';
import { fetchSubsidiaryById } from '@/redux/slices/subsidiarySlice/getSubsidiaryById';
import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import FormGroup from '@/app/shared/form-group';
import { PhoneNumber } from '@/components/ui/phone-input';
import { SubmitHandler, Controller } from 'react-hook-form';
import toast from 'react-hot-toast';
import { Input } from '@/components/ui/input';
import Spinner from '@/components/ui/spinner';
import { PiEnvelopeSimple } from 'react-icons/pi';
import SubsidiaryCard from './subsidiaryCard';
import FormFooter from '@/components/form-footer';
import BasicTableWidget from '@/components/controlled-table/basic-table-widget';
import { getColumns } from '../../list/components/client-subsidiaries-columns';
import ViewData from '../../list/components/view-data';
import { fetchSubsidiaryByClientId } from '@/redux/slices/subsidiarySlice/getSubsidiaryByClientId';

interface AddSubsidiaryFormProps {
  clientId?: string;
}
export default function AddSubsidiaryForm({
  clientId,
}: AddSubsidiaryFormProps) {
  const toggleRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const dispatch = useAppDispatch();
  const token = localStorage?.getItem('token');

  const createSubsidiaryData = useAppSelector(
    (state: any) => state?.createSubsidiaryData
  );
  const deleteSubsidiaryData = useAppSelector(
    (state: any) => state?.deleteSubsidiaryData
  );
  const subsidiaryById = useAppSelector(
    (state: any) => state?.getSubsidiaryDetailByClientId
  );
  const subsidiaryDetailData =
    subsidiaryById?.subsidiaryDataByClientId?.data_list;

  const [subsidiaryDataBranchId, setSubsidiaryBranchId] = useState<any>();
  const [reset, setResetForm] = useState<boolean>(false);
  const [isOpenFormDetail, setIsOpenFormDetail] = useState<boolean>(false);
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [isSubsidiaryModalOpen, setISubsidiaryModalOpen] = useState(false);
  const [selectedSubsidiary, setSelectedSubsidiary] = useState<any>([]);

  const handleViewSubsidiary = (subsidiary: any) => {
    setSelectedSubsidiary(subsidiary);
    setISubsidiaryModalOpen(true);
  };
  const handleDeleteSubsidiary = (subsidiary: any) => {
    console.log('delete')
  };

  const onSubmit: SubmitHandler<SubsidiaryBySPInfoFormTypes> = async (data: any) => {
    if (isEditMode) {
      return alert('Api is in progress');
    }
    try {
      const resultAction = await dispatch(
        createSubsidiary({ ...data, client_id: clientId })
      );
      if (createSubsidiary.fulfilled.match(resultAction)) {
        const subsidiaryData = resultAction.payload;
        setSubsidiaryBranchId(subsidiaryData?.data?.branch_id);
        toast.success(<Text as="b">Successfully added!</Text>);
        setResetForm(true);
        setIsOpenFormDetail(true);
      } else {
        if (resultAction.payload) {
          toast.error(
            <Text as="b">
              {resultAction.payload?.response?.data?.message_key}
            </Text>
          );
          return;
        } else {
          toast.error('Authentication Failed');
          return;
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (reset) {
      toggleRef?.current?.click();
    }
  }, [reset]);

  useEffect(() => {
    // if (!!subsidiaryDataBranchId === true) {
    // dispatch(fetchSubsidiaryById(subsidiaryDataBranchId));
    dispatch(fetchSubsidiaryByClientId(clientId));
    // }
  }, [subsidiaryDataBranchId]);

  const handleEditProject = () => {

  }

  // console.log('subsidiaryDetailData', clientId, subsidiaryDetailData);

  return (
    <>
      <div className="rounded-lg border border-muted">
        <Collapse
          header={({ open, toggle }) => (
            <div
              onClick={toggle}
              className="flex cursor-pointer items-center justify-between gap-4 p-3 md:p-5"
              ref={toggleRef}
            >
              <div className="flex gap-2 sm:items-center md:gap-4">
                <div className="sm:flex sm:flex-col">
                  <Title as="h5" className="font-semibold text-gray-900">
                    Add Subsidiary
                  </Title>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    'flex h-6 w-6 items-center justify-center rounded-full bg-gray-100 text-gray-500',
                    open && 'bg-gray-900 text-gray-0'
                  )}
                >
                  <PiCaretDownBold
                    strokeWidth={3}
                    className={cn(
                      'h-3 w-3 rotate-0 transition-transform duration-200 rtl:-rotate-0',
                      open && 'rotate-180 rtl:rotate-180'
                    )}
                  />
                </div>
              </div>
            </div>
          )}
        >
          {createSubsidiaryData?.isLoading ||
          subsidiaryById?.isLoading ||
          deleteSubsidiaryData?.isLoading ? (
            <Spinner />
          ) : (
            <>
              <BasicTableWidget
                data={subsidiaryDetailData}
                getColumns={(columns) =>
                  getColumns({
                    ...columns,
                    onViewSubsidiary: handleViewSubsidiary,
                    onDeleteClientSubsidiary: handleDeleteSubsidiary,
                    editProject: handleEditProject,
                  })
                }
              />
              {selectedSubsidiary && (
                <Modal
                  isOpen={isSubsidiaryModalOpen}
                  onClose={() => setISubsidiaryModalOpen(false)}
                >
                  <ViewData data={selectedSubsidiary} view="Subsidiary" isModalView={false} />
                </Modal>
              )}
            </>
          )}
          <Form<SubsidiaryBySPInfoFormTypes>
            validationSchema={subsidiaryBySPInfoFormSchema}
            resetValues={reset && defaultValues}
            onSubmit={onSubmit}
            className="gap-4 p-3 @container md:p-5"
            useFormProps={{
              mode: 'onChange',
              defaultValues,
            }}
          >
            {({
              register,
              control,
              setValue,
              getValues,
              formState: { errors },
            }) => {
              // useEffect(() => {
              //   if (
              //     isEditMode &&
              //     Object.keys(subsidiaryDetailData).length > 0
              //   ) {
              //     const fields = [
              //       'branch_name',
              //       'branch_unique_name',
              //       'email',
              //       'phone',
              //       'address',
              //     ];
              //     fields.forEach((field: any) => {
              //       if (field == 'address') {
              //         const address_fields: any = [
              //           'address_line_2',
              //           'borough',
              //           'postcode',
              //           'street_address',
              //           'town',
              //         ];
              //         address_fields.forEach((addressValue: any) => {
              //           const address = subsidiaryDetailData[field];
              //           setValue(addressValue, address[addressValue]);
              //         });
              //       } else {
              //         setValue(field, subsidiaryDetailData[field]);
              //       }
              //     });
              //   }
              // }, [isEditMode]);
              return (
                <>
                  {createSubsidiaryData?.isLoading ? (
                    <Spinner />
                  ) : (
                    <>
                      <FormGroup
                        title="Subsidiary Info Section"
                        description="Enter subsidiary details below"
                        className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
                      />

                      <div className="mb-5 grid gap-7 @2xl:gap-9 @3xl:gap-11">
                        <FormGroup
                          title="Subsidiary Name"
                          className="pt-5 @2xl:pt-7 @3xl:grid-cols-12 @3xl:pt-9"
                        >
                          <Input
                            placeholder="Subsidiary Name"
                            {...register('branch_name')}
                            error={errors.branch_name?.message}
                            className="flex-grow"
                          />
                        </FormGroup>

                        <FormGroup
                          title="Subsidiary Unique Name"
                          className=" @3xl:grid-cols-12"
                        >
                          <Input
                            placeholder="Subsidiary Unique Name"
                            {...register('branch_unique_name')}
                            error={errors.branch_unique_name?.message}
                            className="flex-grow"
                          />
                        </FormGroup>
                        <FormGroup
                          title="Email Address"
                          className="@3xl:grid-cols-12"
                        >
                          <Input
                            className="flex-grow"
                            prefix={
                              <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                            }
                            type="email"
                            placeholder="georgia.young@example.com"
                            {...register('email')}
                            error={errors.email?.message}
                          />
                        </FormGroup>
                        <FormGroup
                          title="Address:"
                          className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
                        />
                        <FormGroup title="Street" className="@3xl:grid-cols-12">
                          {/* <Input
                      placeholder="Street"
                      {...register('street_address')}
                      error={errors.street_address?.message}
                      className="col-span-full"
                    />{' '} */}
                          <Textarea
                            // label="Address"
                            placeholder="Enter your address"
                            {...register('street_address')}
                            error={errors.street_address?.message}
                            // textareaClassName="h-20"
                            className="flex-grow"
                            rows={5}
                          />
                        </FormGroup>

                        <FormGroup title="Town" className="@3xl:grid-cols-12">
                          <Input
                            placeholder="Town Name"
                            {...register('town')}
                            error={errors.town?.message}
                            className="flex-grow"
                          />{' '}
                        </FormGroup>

                        <FormGroup
                          title="Post Code"
                          className="@3xl:grid-cols-12"
                        >
                          <Input
                            placeholder="Postcode"
                            {...register('postcode')}
                            error={errors.postcode?.message}
                            className="flex-grow"
                          />
                        </FormGroup>
                      </div>
                      <br />

                      <FormFooter
                        // isLoading={isLoading}
                        handleAltBtn={() => router.push('/clients')}
                        altBtnText="Back"
                        submitBtnText={
                          isEditMode ? 'Update Subsidiary' : 'Save Subsidiary'
                        }
                      />
                    </>
                  )}
                </>
              );
            }}
          </Form>
        </Collapse>
      </div>
      <br />
    </>
  );
}
