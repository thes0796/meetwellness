'use client';

import { SubmitHandler, Controller } from 'react-hook-form';
import { PiCaretDownBold, PiEnvelopeSimple } from 'react-icons/pi';
import { Form } from '@/components/ui/form';
import { Text, Title } from '@/components/ui/text';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Collapse } from '@/components/ui/collapse';
import FormGroup from '@/app/shared/form-group';
import { PhoneNumber } from '@/components/ui/phone-input';
import { useParams, useRouter } from 'next/navigation';
import {
  ClientInfoFormTypes,
  clientInfoFormSchema,
  defaultValues,
} from '@/utils/validators/client-info.schema';
import { useEffect, useRef, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { createClient } from '@/redux/slices/clientsSlice/createClient';
import Spinner from '@/components/ui/spinner';
import { createClientContact } from '@/redux/slices/clientsSlice/createClientContact';
import cn from '@/utils/class-names';
import FormFooter from './form-footer';
import toast from 'react-hot-toast';
import ClientCard from './clientCard';
import { fetchClientByClientId } from '@/redux/slices/clientsSlice/getClientByClientId';
import { updateClient } from '@/redux/slices/clientsSlice/updateClient';
import {removeClient} from '@/redux/slices/clientsSlice/deleteClient'
import { useForm, UseFormReturn } from 'react-hook-form';

export default function AddClientForm(props: any) {
  const toggleRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const dispatch = useAppDispatch();

  const createClientData = useAppSelector(
    (state: any) => state?.createClientData
  );
  const createClientContactData = useAppSelector(
    (state) => state?.createClientContactData
  );
  // const clientData = useAppSelector((state) => state?.clientById);
  // const clientDetailData = clientData?.clientByClientId;

  const [reset, setResetForm] = useState<any>();
  const [isOpenFormDetail, setIsOpenFormDetail] = useState<boolean>(false);
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [clientId, setClientId] = useState<string>('');
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const [phoneDialCode, setPhoneDialCode] = useState<string>('')
  const [mainContactDialCode, setMainContactDialCode] = useState<string>('')
  const [mainContactNumber, setMainContactNumber] = useState<string>('')
  const [isEditCompleted, setIsEditCompleted] = useState<boolean>(false)
  const [clientDetailData, setClientDetailData] = useState<any>()

  const onSubmit: SubmitHandler<ClientInfoFormTypes> = async (data) => {
    // console.log('aa riha')
    if(isOpenFormDetail) {

      setIsOpenFormDetail(false)
      setIsEditMode(true)
      // setResetForm(false)

    } else if(isEditMode) {
      try {
        let newData = {
          client_id: clientId,
          client_name: data.client_name,
          client_unique_name: data.client_unique_name,
          email: data.email,
          main_contact: mainContactNumber,
          phone_number: phoneNumber,
          postcode: data.postcode,
          street_address: data.street_address,
          town: data.town,
          trading_name: data.trading_name,
          phone_number_dial_code: phoneDialCode,
          main_contact_dial_code: mainContactDialCode
        }
        const resultAction: any = await dispatch(updateClient(newData));

        if (updateClient.fulfilled.match(resultAction)) {
          const updatedClientData = resultAction.payload
          toast.success(<Text as="b">{resultAction.payload?.message_key}</Text>);
          setIsOpenFormDetail(true);
          // setResetForm(defaultValues);
          setIsEditMode(false)
          setIsEditCompleted(true)
        } else {
          if(resultAction.payload) {
            toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
            return
          } else {
            toast.error('Authentication Failed')
            return
          }
        }

      } catch (err) {
        console.error('err: ', err)
      }

    } else {

      try {
        // Dispatch the first action to create client
        let newData = {
          client_name: data.client_name,
          client_unique_name: data.client_unique_name,
          email: data.email,
          main_contact: mainContactNumber,
          phone_number: phoneNumber,
          postcode: data.postcode,
          street_address: data.street_address,
          town: data.town,
          trading_name: data.trading_name,
          phone_number_dial_code: phoneDialCode,
          main_contact_dial_code: mainContactDialCode
        }
        const resultAction: any = await dispatch(createClient(newData));
  
        if (createClient.fulfilled.match(resultAction)) {
          const clientData = resultAction.payload
          toast.success(<Text as="b">{resultAction.payload?.message_key}</Text>);
          setIsOpenFormDetail(true);
          // setResetForm(defaultValues);
          setClientId(clientData?.data?.client_id)
        } else {
          if(resultAction.payload) {
            toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
            return
          } else {
            toast.error('Authentication Failed')
            return
          }
        }
      } catch (err) {
        console.error(err);
      }
    }
  };
  // useEffect(() => {
  //   if (reset) {
  //     toggleRef?.current?.click();
  //   }
  // }, [reset]);


  // useEffect(() => {
  //   if(!!clientDetailData === true && Object.keys(clientDetailData).length > 0) {
  //     setIsOpenFormDetail(true)
  //   }
  // }, [clientDetailData])

  useEffect(() => {
    if(!!clientId === true || isEditCompleted === true) {
      const fetchClient = async () => {
        const resultAction = await dispatch(fetchClientByClientId(clientId))
        if (fetchClientByClientId.fulfilled.match(resultAction)) {
          const clientData = resultAction.payload
          setIsOpenFormDetail(true);
          setClientDetailData(clientData?.data)
        } else {
          if(resultAction.payload) {
            toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
            return
          } else {
            toast.error('Authentication Failed')
            return
          }
        }
      }
      fetchClient()
    }
    if(isEditCompleted === true) {
      setIsEditCompleted(false)
      // dispatch(fetchClientByClientId(clientId))
    }
  }, [clientId, isEditCompleted])

  const handleChange = (value: any, countryCode: any, e: any) => {
    // Update the phoneNumber state when the input value changes
    const splittedVal = e.target.value.split(' ')
    const concatenatedArray = [].concat(...splittedVal.slice(1))
    const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
    setPhoneNumber(concatenatedString);
    setPhoneDialCode(countryCode.dialCode)
  };

  const handleChangeMainContact = (value: any, countryCode: any, e: any) => {
    // Update the Main Contact Number state when the input value changes
    const splittedVal = e.target.value.split(' ')
    const concatenatedArray = [].concat(...splittedVal.slice(1))
    const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
    setMainContactNumber(concatenatedString);
    setMainContactDialCode(countryCode.dialCode)
  };

  const onDeleteItem = async (id: any) => {
    try {
      const resultAction = await dispatch(removeClient(id))

      if (removeClient.fulfilled.match(resultAction)) {
        // const clientData = resultAction.payload
        toast.success(<Text as="b">{resultAction.payload?.message_key}</Text>);
        resetForm()
      } else {
        if(resultAction.payload) {
          toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>);
          return
        } else {
          toast.error('Authentication Failed')
          return
        }
      }

    } catch (err) {
      console.error('err: ', err)
    }
  }

  const resetForm = () => {
    setResetForm(defaultValues)
    setIsEditMode(false)
    setIsOpenFormDetail(false)
    setClientId('')
    setIsEditCompleted(false)
  }

  const { control, register, setValue, getValues, formState: { errors } } = useForm<ClientInfoFormTypes>({
    defaultValues: defaultValues,
    mode: 'onChange'
  });

  useEffect(() => {
    if((isEditMode && !!clientDetailData === true && Object.keys(clientDetailData).length > 0) || (isOpenFormDetail && !!clientDetailData === true && Object.keys(clientDetailData).length > 0)) {
        const fields = ['main_contact_dial_code', 'phone_number_dial_code', 'client_name', 'client_unique_name', 'email', 'main_contact', 'phone_number', 'trading_name', 'address'];
        let contact_dial_code = ''
        let phone_dial_code = ''
        fields.forEach((field: any) => {
          if (field == 'address') {
            const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town'];
            address_fields.forEach((addressValue: any) => {
                const address = clientDetailData[field];
                setValue(addressValue, address[addressValue]);
            });
          } else {
            setValue(field, clientDetailData[field]);

            if(field === 'main_contact_dial_code') {
              contact_dial_code = clientDetailData[field]
              setMainContactDialCode(clientDetailData[field])
            }
            if(field === 'main_contact') {
              const contact_detail = `${contact_dial_code}${clientDetailData[field]}`
              setValue(field, contact_detail)
              setMainContactNumber(clientDetailData[field])
            }
            if(field === 'phone_number_dial_code') {
              phone_dial_code = clientDetailData[field]
              setPhoneDialCode(clientDetailData[field])
            }
            if(field === 'phone_number') {
              const phone_detail = `${phone_dial_code}${clientDetailData[field]}`
              setValue(field, phone_detail)
              setPhoneNumber(clientDetailData[field])
            }
          }
        })
    }
  }, [isEditMode, isOpenFormDetail])

  return (
    <>
      <div className="rounded-lg border border-muted">
        <Collapse
          defaultOpen={true}
          header={({ open, toggle }) => (
            <div
              onClick={toggle}
              className="flex cursor-pointer items-center justify-between gap-4 p-3 md:p-5"
              ref={toggleRef}
            >
              <div className="flex gap-2 sm:items-center md:gap-4">
                <div className="sm:flex sm:flex-col">
                  <Title as="h5" className="font-semibold text-gray-900">
                    Add Client
                  </Title>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    'flex h-6 w-6 items-center justify-center rounded-full bg-gray-100 text-gray-500',
                    open && 'bg-gray-900 text-gray-0'
                  )}
                >
                  <PiCaretDownBold
                    strokeWidth={3}
                    className={cn(
                      'h-3 w-3 rotate-0 transition-transform duration-200 rtl:-rotate-0',
                      open && 'rotate-180 rtl:rotate-180'
                    )}
                  />
                </div>
              </div>
            </div>
          )}
        >
            <Form<ClientInfoFormTypes>
              validationSchema={clientInfoFormSchema}
              resetValues={reset}
              onSubmit={onSubmit}
              className="@container gap-4 p-3 md:p-5"
              useFormProps={{
                mode: 'onChange',
                defaultValues,
              }}
            >
              {() => {
                
                return (
                  <>
                    {createClientData?.isLoading ? (
                      <Spinner />
                    ) : (
                      <>
                        <div className="mb-5 grid gap-7 @2xl:gap-9 @3xl:gap-11">
                          <FormGroup
                            title="Company Name"
                            className="pt-5 @2xl:pt-7 @3xl:grid-cols-12 @3xl:pt-9"
                          >
                            {isOpenFormDetail ? 
                              <span className='flex-grow'>
                                {clientDetailData?.client_name}
                              </span>
                            :
                            <Input
                              placeholder="Company Name"
                              {...register('client_name')}
                              error={errors.client_name?.message}
                              className="flex-grow"
                            />
                            }
                          </FormGroup>
                          <FormGroup
                            title="Unique Name"
                            className="@3xl:grid-cols-12"
                          >
                            {isOpenFormDetail ? 
                              <span className='flex-grow'>
                                {clientDetailData?.client_unique_name}
                              </span>
                            :
                            <Input
                              placeholder="Unique Name"
                              {...register('client_unique_name')}
                              error={errors.client_unique_name?.message}
                              className="flex-grow"
                            />
                            }
                          </FormGroup>
                          <FormGroup
                            title="Trading Name"
                            className=" @3xl:grid-cols-12"
                          >
                            {isOpenFormDetail ? 
                              <span className='flex-grow'>
                                {clientDetailData?.trading_name}
                              </span>
                            :
                            <Input
                              placeholder="Trading Name"
                              {...register('trading_name')}
                              error={errors.trading_name?.message}
                              className="flex-grow"
                            />
                            }
                          </FormGroup>
                          <FormGroup
                            title="Email Address"
                            className="@3xl:grid-cols-12"
                          >
                            {isOpenFormDetail ? 
                              <span className='flex-grow'>
                                {clientDetailData?.email}
                              </span>
                            :
                            <Input
                              className="flex-grow"
                              prefix={
                                <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                              }
                              type="email"
                              placeholder="georgia.young@example.com"
                              {...register('email')}
                              error={errors.email?.message}
                            />
                            }
                          </FormGroup>
                          <FormGroup
                            title="Mobile Number"
                            className=" @3xl:grid-cols-12 "
                          >
                            {isOpenFormDetail ? 
                              <span className='flex-grow'>
                                {`+${clientDetailData?.phone_number_dial_code} ${clientDetailData?.phone_number}`}
                              </span>
                            :
                            <Controller
                              name="phone_number"
                              control={control}
                              render={({ field: { value, onChange } }) => (
                                <PhoneNumber
                                  // label="Phone Number"
                                  error={errors.phone_number?.message}
                                  country="gb"
                                  value={value}
                                  onChange={handleChange}
                                  className="rtl:[&>.selected-flag]:right-0"
                                  inputClassName="rtl:pr-12"
                                  buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                                />
                              )}
                            />
                            }
                          </FormGroup>
                          <FormGroup
                            title="Main Contact Number"
                            className=" @3xl:grid-cols-12 "
                          >
                            {isOpenFormDetail ? 
                              <span className='flex-grow'>
                                {`+${clientDetailData?.main_contact_dial_code} ${clientDetailData?.main_contact}`}
                              </span>
                            :
                            <Controller
                              name="main_contact"
                              control={control}
                              render={({ field: { value, onChange } }) => (
                                <PhoneNumber
                                  // label="Phone Number"
                                  country="gb"
                                  error={errors.main_contact?.message}
                                  value={value}
                                  onChange={handleChangeMainContact}
                                  className="rtl:[&>.selected-flag]:right-0"
                                  inputClassName="rtl:pr-12"
                                  buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                                />
                              )}
                            />
                            }
                          </FormGroup>
                          {/* <FormGroup
                            title="Address:"
                            className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
                          /> */}
                          <FormGroup
                            title="Address"
                            className="@3xl:grid-cols-12"
                          >
                            {isOpenFormDetail ? 
                              <span className='flex-grow'>
                                {clientDetailData?.address?.street_address}
                              </span>
                            :
                            <Textarea
                              // label="Address"
                              placeholder="Enter your address"
                              {...register('street_address')}
                              error={errors.street_address?.message}
                              // textareaClassName="h-20"
                              className="flex-grow"
                              rows={5}
                            />
                            }
                          </FormGroup>

                          <FormGroup title="Town" className="@3xl:grid-cols-12">
                            {isOpenFormDetail ? 
                              <span className='flex-grow'>
                                {clientDetailData?.address?.town}
                              </span>
                            :
                            <Input
                              placeholder="Town Name"
                              {...register('town')}
                              error={errors.town?.message}
                              className="flex-grow"
                            />
                            }
                          </FormGroup>

                          <FormGroup
                            title="Post Code"
                            className="@3xl:grid-cols-12"
                          >
                            {isOpenFormDetail ? 
                              <span className='flex-grow'>
                                {clientDetailData?.address?.postcode}
                              </span>
                            :
                            <Input
                              placeholder="Postcode"
                              {...register('postcode')}
                              error={errors.postcode?.message}
                              className="flex-grow"
                            />
                            }
                          </FormGroup>
                        </div>
                        <FormFooter
                          // isLoading={isLoading}
                          _id={clientId}
                          isOpenFormDetail={isOpenFormDetail}
                          handleAltBtn={() => router.push('/clients')}
                          handleOpenNewForm={() => resetForm()}
                          altBtnText="Back"
                          submitBtnText={isOpenFormDetail ? 'Edit' : 'Save'}
                          onDeleteItem={onDeleteItem}
                        />
                      </>
                    )}
                  </>
                );
              }}
            </Form>
          {/* )} */}
        </Collapse>
      </div>
      <br />
      {/* <hr /> */}
    </>
  );
}
