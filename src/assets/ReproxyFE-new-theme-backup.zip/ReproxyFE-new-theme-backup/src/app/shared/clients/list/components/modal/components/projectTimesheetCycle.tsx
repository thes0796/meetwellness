'use client';

import { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import { Controller, useFieldArray, useFormContext } from 'react-hook-form';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import FormGroup from '@/app/shared/form-group';
import cn from '@/utils/class-names';
import { useCallback } from 'react';
import {
  variantOption,
  productVariants,
} from '@/app/shared/ecommerce/product/create-edit/form-utils';
import {
  workTime,
} from '@/utils/validators/create-project-info.schema';
import { Button } from '@/components/ui/button';
import { ActionIcon } from '@/components/ui/action-icon';
import TrashIcon from '@/components/icons/trash';
import SelectLoader from '@/components/loader/select-loader';
import { PiPlusBold } from 'react-icons/pi';
import { DatePicker } from '@/components/ui/datepicker';
import {getFullDateWithTime, convert12HourToDateTime} from './projectWorkSchedule'
const Select = dynamic(
  () => import('@/components/ui/select').then((mod) => mod.Select),
  {
    ssr: false,
    loading: () => <SelectLoader />,
  }
);

const checkboxesValues = [
  {
    label: 'Daily',
    name: 'Daily'
  },
  {
    label: 'Weekly',
    name: 'Weekly'
  },
  {
    label: 'Fortnightly',
    name: 'Fortnightly'
  },
  {
    label: 'Monthly',
    name: 'Monthly'
  },
]


const getDateWithZeroTime = (days: any) => {
  // Get the current date
  const currentDate = new Date();

  // Create a new Date object for the next date
  const nextDate = new Date(currentDate);
  
  // Set the time to 00:00:00
  nextDate.setHours(0, 0, 0, 0);

  // Add one day to the current date
  nextDate.setDate(nextDate.getDate() + days);

  return nextDate;
}

const getUpcomingFriday = () => {
  const today = new Date();
  const dayOfWeek = today.getDay(); // 0 for Sunday, 1 for Monday, etc.
  let daysUntilFriday = 5 - dayOfWeek; // 5 represents Friday

  if (daysUntilFriday < 0) {
    // If it's already past Friday, add 7 days to get next Friday
    daysUntilFriday += 7;
  }

  const nextFriday = new Date(today);
  nextFriday.setHours(0, 0, 0, 0);
  nextFriday.setDate(today.getDate() + daysUntilFriday);

  return nextFriday;
}

const getLastDateOftheMonth = () => {
  var date = new Date(), y = date.getFullYear(), m = date.getMonth();
  var firstDay = new Date(y, m, 1);
  var lastDay = new Date(y, m + 1, 0);
  return lastDay
}

const getNextFortnightlyFriday = (year: any, month: any) => {
  // Function to get all Fridays in a given month
  function getFridaysInMonth(year: any, month: any) {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const fridays = [];
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      if (date.getDay() === 5) { // 5 corresponds to Friday
        fridays.push(day);
      }
    }
    return fridays;
  }

  // Get all Fridays in the current month
  const fridaysInMonth = getFridaysInMonth(year, month);
  const today = new Date();

  // Find the next fortnightly Friday starting from today
  for (let i = 0; i < fridaysInMonth.length - 1; i++) {
    const currentFriday = fridaysInMonth[i];
    const nextFortnightlyFriday = currentFriday + 14;

    if (nextFortnightlyFriday <= fridaysInMonth[fridaysInMonth.length - 1]) {
      const fortnightlyFriday = new Date(year, month, nextFortnightlyFriday);
      if (fortnightlyFriday >= today) {
        return fortnightlyFriday;
      }
    } else {
      // If next fortnightly Friday exceeds the current month, calculate for the next month
      const nextMonth = month === 11 ? 0 : month + 1;
      const nextYear = month === 11 ? year + 1 : year;
      const fridaysInNextMonth = getFridaysInMonth(nextYear, nextMonth);

      if (fridaysInNextMonth.length > 0) {
        const firstFridayNextMonth = fridaysInNextMonth[0];
        const fortnightlyFridayNextMonth = new Date(nextYear, nextMonth, firstFridayNextMonth + 14);
        return fortnightlyFridayNextMonth;
      }
    }
  }

  // If no valid Friday is found, return null
  return getUpcomingFriday();
}



export default function ProjectTimesheetCycle({ className, data, clockValue, isViewMode, handleBillableChange, billable, setSelectedTimesheet, selectedTimesheet }: { className?: string; data?: any; clockValue?: string; isViewMode?: boolean; handleBillableChange?: any; billable?: boolean; setSelectedTimesheet?: any; selectedTimesheet?: any; }) {

  const [totalHours, setTotalHours] = useState<any>()

  const {
    control,
    register,
    getValues,
    setValue,
    formState: { errors },
  } = useFormContext();

  // const { fields, append, remove } = useFieldArray({
  //   control,
  //   name: 'break_time',
  // });

  // const addBreak = useCallback(() => append([...workTime]), [append]);

  const _handleSelectedOption = (item: any) => {
    setSelectedTimesheet(item)
    if(item == 'Daily') {
      setValue('next_due_date', getDateWithZeroTime(0))
    } else if(item == 'Weekly') {
      setValue('next_due_date', getUpcomingFriday())
    } else if(item == 'Fortnightly') {
      const today = new Date();
      const year = today.getFullYear();
      const month = today.getMonth(); // July (0-based index, 0 for January, 11 for December)
      const nextFortnightlyFriday = getNextFortnightlyFriday(year, month);
      setValue('next_due_date', nextFortnightlyFriday)
    } else if(item == 'Monthly') {
      setValue('next_due_date', getLastDateOftheMonth())
    }
  }

  // useEffect(() => {
    if(!!data && Object.keys(data).length > 0) {
      if(!!data && data?.schedules.length > 0) {
        if(!!data?.schedules[0].next_due_date) {
          // let next_date = clockValue == '12hr' ? 
          const new_dte = new Date(data?.schedules[0].next_due_date)
          setValue('next_due_date', new_dte)
        }
      }
    }
  // }, [data])

  // useEffect(() => {
    if(!!selectedTimesheet && selectedTimesheet == 'Daily') {
      _handleSelectedOption(selectedTimesheet)
    }
  // }, [selectedTimesheet])


  return (
    <>
    <FormGroup
      title="Time sheet Cycle"
      description={isViewMode ? 'View timsheet' : "Add timesheet"}
      className={cn(className)}
    >
    {isViewMode && !!data && Object.keys(data).length > 0 ? 
        
        !!data?.schedules[0] === true && data?.schedules[0].next_due_date && 
          // let start_time = val.split('-')[0]
          // let end_time = val.split('-')[1]
          // return (
            <label className='col-span-full flex justify-start'>
      
              <text className='font-bold mr-4'>Next due: </text>
              <p>{data?.schedules[0].next_due_date}</p>  
              
            </label>
          // )
        
      :
      <>
        <div className='grid gap-3'>
          {checkboxesValues.map((item, index) => (
            <div className="flex justify-start" key={index}>
              <label 
                htmlFor={item?.name}
                className='w-[95px] text-sm mb-1.5 font-medium cursor-pointer mr-4 text-gray-900'>
                {item?.label}
              </label>
              <input 
                type='checkbox' 
                className='mr-2 focus:ring-0 appearance-auto cursor-pointer mb-1.5'
                id={item?.name}
                checked={item?.name === selectedTimesheet}
                onChange={() => _handleSelectedOption(item?.name)}
              />
            </div>
          ))}


          <Controller
            name={`next_due_date`}
            control={control}
            render={({ field: { onChange, value, onBlur } }) => (
              <DatePicker
                inputProps={{ label: 'Next due: ' }}
                placeholderText="Select next due"
                timeCaption="Time"
                onChange={onChange}
                // onBlur={onBlur}
                selected={value}
                // showTimeSelectOnly
                timeFormat={clockValue === "12hr" ? "h:mm aa" : "HH:mm"}
                showTimeSelect
                timeIntervals={1}
                dateFormat={clockValue === "12hr" ? "MMMM d, yyyy h:mm aa" : "MMMM d, yyyy HH:mm"}
                minDate={new Date()}
              />
            )}
          />
        </div>
      </>
    }
    </FormGroup>

    {/* {isViewMode && 
      <FormGroup
        title=""
        description={'Total'}
        className={cn(className)}
      >
        <div className='flex justify-between'>
          <label className='block'>
            <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
              <text className='font-bold'>WT: </text>
              <span>{!!data && data.schedules.length > 0 && data.schedules[0].work_hours.toFixed(2)}</span>
            </span>
          </label>

          <label className='block'>
            <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
              <text className='font-bold'>BT: </text>
              <span>{!!data && data.schedules.length > 0 && data.schedules[0].break_hours.toFixed(2)}</span>
            </span>
          </label>

          <label className='block'>
            <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
              <text className='font-bold'>Total: </text>
              <span>{totalHours && totalHours.toFixed(2)}</span>
            </span>
          </label>
        </div>
        
      </FormGroup>
    } */}
    </>
  );
}
