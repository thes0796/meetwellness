"use client";

import { Text } from '@/components/ui/text';
import { Modal } from '@/components/ui/modal';
import BasicTableWidget from '@/components/controlled-table/basic-table-widget';
import { metaObject } from '@/config/site.config';
import TableLayout from './components/table-layout';
import { getColumns } from './components/client-columns';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { fetchAllClients } from '@/redux/slices/clientsSlice/getClients';
import ViewData from './components/view-data';
import Spinner from '@/components/ui/spinner';
import { orderData } from '@/data/order-data';
import { removeClient } from '@/redux/slices/clientsSlice/deleteClient';
import toast from 'react-hot-toast';
import EditClientsModalView from './components/modal/editClients';
import AddContactModalView from './components/modal/addContact'
import ViewContactCard from './components/modal/viewContactCard';

export const metadata = {
  ...metaObject('Clients List'),
};

const pageHeader = {
  title: 'Clients',
  breadcrumb: [
    {
      name: '',
    },
  ],
};

export default function ClientsListTable() {
  const dispatch = useAppDispatch();
  const clients = useAppSelector((state) => state?.allClientsData);
  const clientsData = clients?.clientsData?.data_list;
  const totalDataItems = clients?.clientsData?.total_items;
  const currentPageNumber = clients?.clientsData?.current_page;
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [selectedClient, setSelectedClient] = useState<any>([]);
  const [viewClient, setViewClient] = useState<boolean>(false)
  const [editClient, setEditClient] = useState<boolean>(false)
  const [isEditCompleted, setIsEditCompleted] = useState<boolean>(false)
  const [isOpenAddContact, setIsOpenAddContact] = useState<boolean>(false)
  const [clientData, setClientData] = useState<any>()
  const [viewContact, setViewContact] = useState<boolean>(false)
  const [viewContactData, setViewContactData] = useState<any>()

  // Function to handle opening the modal and setting the selected client
  const handleViewClient = (client: any) => {
    setSelectedClient(client);
    setIsModalOpen(true);
    setViewClient(true)
  };
  const handleDeleteClient = async (client: any) => {
    const response = await dispatch(removeClient(client));
    if (response?.payload?.status === 'SUCCESS') {
      toast.success(<Text as="b">{response.payload?.message_key}</Text>);
      dispatch(fetchAllClients(pageNumber));
    } else {
      toast.error(
        <Text as="b">{response.payload?.response?.data?.message_key}</Text>
      );
    }
  };

  const handlePagination = (page: any) => {
    setPageNumber(page);
  };

  useEffect(() => {
    dispatch(fetchAllClients(pageNumber));
  }, [pageNumber]);

  const newData = clientsData?.map((item: any, index: any) => ({
    ...item,
    id: String(index),
  }));
  
  const handleEditClient = (client: any) => {
    setSelectedClient(client);
    setIsModalOpen(true);
    setEditClient(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
    setEditClient(false)
    setViewClient(false)
    setIsOpenAddContact(false)
    setViewContact(false)
  }

  const handleAddContact = (data: any) => {
    setClientData(data)
    setIsModalOpen(true);
    setIsOpenAddContact(true)
  }

  const handleViewContact = (contactData: any) => {
    setIsModalOpen(true);
    setViewContact(true)
    setViewContactData(contactData)
  }

  const handleProjectEditted = () => {
    setIsEditCompleted(true)
  }

  useEffect(() => {
    if(isEditCompleted) {
      setIsEditCompleted(false)
      dispatch(fetchAllClients(pageNumber));
    }
  }, [isEditCompleted])

  return (
    <TableLayout
      title={pageHeader.title}
      breadcrumb={pageHeader.breadcrumb}
      // data={clientsData?.clientsData?.data_list}
      data={newData}
      fileName="client_data"
      header="Client ID,Name,Email,Avatar,Status,Created At,Updated At"
    >
      {clients?.isLoading ? (
        <Spinner />
      ) : (
        <React.Fragment>
          <BasicTableWidget
            title=""
            variant="modern"
            data={newData}
            pageSize={10}
            totalDataItems={totalDataItems}
            currentPageNumber={currentPageNumber}
            getColumns={(columns) =>
              getColumns({
                ...columns,
                onViewClient: handleViewClient,
                onDeleteClient: handleDeleteClient,
                onEditClient: handleEditClient,
                addContact: handleAddContact,
                viewContact: handleViewContact,
                editProject: handleProjectEditted,
              })
            }
            handlePagination={handlePagination}
            expandable
            enableSearch
            enablePagination
            searchPlaceholder="Search client..."
            className="min-h-[480px] [&_.widget-card-header]:items-center [&_.widget-card-header_h5]:font-medium"
          />
          {selectedClient && (
            <Modal 
              isOpen={isModalOpen} 
              onClose={() => closeModal()}
              customSize={viewClient || isOpenAddContact ? '720px' : viewContact ? "320px": "1080px"}
              className="z-[9990]"
            >
              {viewClient && <ViewData data={selectedClient} view="Client" isModalView={true} />}
              {editClient && <EditClientsModalView isModalView={true} isOpened={closeModal} editClient={setEditClient} data={selectedClient} isEdited={setIsEditCompleted} />}
              {isOpenAddContact && <AddContactModalView isModalView={false} isOpened={closeModal} clientId={clientData?.client_id} data={clientData} contactType={'client'} />}
              {viewContact && <ViewContactCard data={viewContactData} />}
            </Modal>
          )}
        </React.Fragment>
      )}
    </TableLayout>
  );
}
