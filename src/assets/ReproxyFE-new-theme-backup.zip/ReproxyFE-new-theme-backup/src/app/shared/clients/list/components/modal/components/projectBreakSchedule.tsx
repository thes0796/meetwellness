'use client';

import { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import { Controller, useFieldArray, useFormContext } from 'react-hook-form';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import FormGroup from '@/app/shared/form-group';
import cn from '@/utils/class-names';
import { useCallback } from 'react';
import {
  variantOption,
  productVariants,
} from '@/app/shared/ecommerce/product/create-edit/form-utils';
import {
  workTime,
} from '@/utils/validators/create-project-info.schema';
import { Button } from '@/components/ui/button';
import { ActionIcon } from '@/components/ui/action-icon';
import TrashIcon from '@/components/icons/trash';
import SelectLoader from '@/components/loader/select-loader';
import { PiPlusBold } from 'react-icons/pi';
import { DatePicker } from '@/components/ui/datepicker';
import {getFullDateWithTime, convert12HourToDateTime} from './projectWorkSchedule'
const Select = dynamic(
  () => import('@/components/ui/select').then((mod) => mod.Select),
  {
    ssr: false,
    loading: () => <SelectLoader />,
  }
);

export default function ProjectBreakSchedule({ className, data, clockValue, isViewMode, handleBillableChange, billable }: { className?: string; data?: any; clockValue?: string; isViewMode?: boolean; handleBillableChange?: any; billable?: boolean }) {

  const [totalHours, setTotalHours] = useState<any>()

  const {
    control,
    register,
    getValues,
    setValue,
    formState: { errors },
  } = useFormContext();

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'break_time',
  });

  const addBreak = useCallback(() => append([...workTime]), [append]);

  // useEffect(() => {
    if(!!data && Object.keys(data).length > 0) {
      !!data === true && data.schedules[0].breaks && data.schedules[0].breaks.length > 0 && data.schedules[0].breaks.forEach((v: any, k: any) => {
        if(k != 0) {
          addBreak()
        }
      })
      !!data === true && data.schedules[0].breaks && data.schedules[0].breaks.length > 0 && data.schedules[0].breaks.forEach((val: any, key: any) => {
        const start_time = val.split('-')[0]
        const end_time = val.split('-')[1]
        const startDate = clockValue === "12hr" ? convert12HourToDateTime(start_time) : getFullDateWithTime(String(start_time + ':00'))
        const endDate = clockValue === "12hr" ? convert12HourToDateTime(end_time) : getFullDateWithTime(String(end_time + ':00'))
        setValue(`break_time.${key}.break_start_time`, startDate)
        setValue(`break_time.${key}.break_end_time`, endDate)
        
      })
    }
    let total_hours = !!data && !!data.schedules && data.schedules.length > 0 && data.schedules[0].work_hours + data.schedules[0].break_hours
    setTotalHours(total_hours)
  // }, [data])

  return (
    <>
    <FormGroup
      title=""
      description={isViewMode ? 'View break' : "Add break"}
      className={cn(className)}
    >
    {isViewMode && !!data && Object.keys(data).length > 0 ? 
        
        !!data?.schedules[0].breaks === true && data?.schedules[0].breaks.length > 0 && data?.schedules[0].breaks.map((val: any, k:any) => {
          let start_time = val.split('-')[0]
          let end_time = val.split('-')[1]
          return (
            <label className='col-span-full flex justify-between' key={k}>
              <text className='font-bold'>Start Time: </text><p>{start_time}</p>  
              <text className='font-bold'>End Time: </text><p>{end_time}</p>
            </label>
          )
        })
      :
      <>

      {/* <HorizontalFormBlockWrapper
        title="Comments"
        description="These are notifications for comments on your posts and replies to your comments."
        descriptionClassName="max-w-[344px]"
      > */}
        <div className="col-span-2">
          <Switch
            label="Billable"
            labelPlacement="left"
            variant="flat"
            labelClassName="font-medium text-sm text-gray-900"
            checked={billable}
            onChange={handleBillableChange}
          />
        </div>
      {/* </HorizontalFormBlockWrapper> */}

      {fields.map((item, index) => (
        <div key={item.id} className="col-span-full flex gap-4 xl:gap-7">
          <Controller
            name={`break_time.${index}.break_start_time`}
            control={control}
            render={({ field: { onChange, value, onBlur } }) => (
              <DatePicker
                inputProps={{ label: 'Start Time' }}
                placeholderText="Select Time"
                // dateFormat="dd/MM/yyyy"
                timeCaption="Start Time"
                onChange={onChange}
                // onBlur={onBlur}
                selected={value}
                showTimeSelectOnly
                timeFormat={clockValue === "12hr" ? "h:mm aa" : "HH:mm"}
                // timeFormat={"HH:mm"}
                showTimeSelect
                timeIntervals={1}
                dateFormat={clockValue === "12hr" ? "h:mm aa" : "HH:mm"}
              />
            )}
          />
          <Controller
            name={`break_time.${index}.break_end_time`}
            control={control}
            render={({ field: { onChange, value, onBlur } }) => (
              <DatePicker
                inputProps={{ label: 'End Time' }}
                placeholderText="Select Time"
                // dateFormat="dd/MM/yyyy"
                timeCaption="End Time"
                onChange={onChange}
                // onBlur={onBlur}
                selected={value}
                showTimeSelectOnly
                timeFormat={clockValue === "12hr" ? "h:mm aa" : "HH:mm"}
                // timeFormat={"HH:mm"}
                showTimeSelect
                timeIntervals={1}
                dateFormat={clockValue === "12hr" ? "h:mm aa" : "HH:mm"}
              />
            )}
          />
          {fields.length > 1 && (
            <ActionIcon
              onClick={() => remove(index)}
              variant="flat"
              className="mt-7 shrink-0"
            >
              <TrashIcon className="h-4 w-4" />
            </ActionIcon>
          )}
        </div>
      ))}
      <Button
        onClick={addBreak}
        variant="outline"
        className="col-span-full ml-auto w-auto"
      >
        <PiPlusBold className="me-2 h-4 w-4" /> Add Break
      </Button>
      </>
    }
    </FormGroup>

    {isViewMode && 
      <FormGroup
        title=""
        description={'Total'}
        className={cn(className)}
      >
        <div className='flex justify-between'>
          <label className='block'>
            <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
              <text className='font-bold'>WT: </text>
              <span>{!!data && data.schedules.length > 0 && data.schedules[0].work_hours.toFixed(2)}</span>
            </span>
          </label>

          <label className='block'>
            <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
              <text className='font-bold'>BT: </text>
              <span>{!!data && data.schedules.length > 0 && data.schedules[0].break_hours.toFixed(2)}</span>
            </span>
          </label>

          <label className='block'>
            <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
              <text className='font-bold'>Total: </text>
              <span>{totalHours && totalHours.toFixed(2)}</span>
            </span>
          </label>
        </div>
        
      </FormGroup>
    }
    </>
  );
}
