import { useState } from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import FormGroup from '@/app/shared/form-group';
import cn from '@/utils/class-names';
import {
  categoryOption,
  typeOption,
} from '@/app/shared/ecommerce/product/create-edit/form-utils';
import dynamic from 'next/dynamic';
import SelectLoader from '@/components/loader/select-loader';
import QuillLoader from '@/components/loader/quill-loader';
import { Textarea } from '@/components/ui/textarea';
import { PiPlusBold, PiXBold, PiClock, PiEnvelopeSimple } from 'react-icons/pi';
import { countries, roles, timezones, clock } from '@/data/forms/my-details';

const Select = dynamic(
  () => import('@/components/ui/select').then((mod) => mod.Select),
  {
    ssr: false,
    loading: () => <SelectLoader />,
  }
);
// const QuillEditor = dynamic(() => import('@/components/ui/quill-editor'), {
//   ssr: false,
//   loading: () => <QuillLoader className="col-span-full h-[143px]" />,
// });

export default function ProjectInformation({ className, data, handleClockChange, clockValue, isViewMode }: 
  { className?: string; data?: any; handleClockChange: any; clockValue?: string; isViewMode?: boolean; }) {
  
  const {
    register,
    control,
    setValue,
    formState: { errors },
  } = useFormContext();
  
  return (
    <FormGroup
      title={isViewMode ? 'Project details' : "Enter Project Details"}
      description=""
      className={cn(className)}
    >
      {isViewMode && !!data && Object.keys(data).length > 0 ?
        <label className='block col-span-full'>
          <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
            <text className='font-bold'>Title: </text><span>{data?.project_name}</span>
          </span>
        </label>
        
      :
        <Input
          label="Title"
          placeholder="Enter title"
          {...register('project_name')}
          error={errors.project_name?.message as string}
          className='col-span-full'
        />
      }

      {isViewMode && !!data && Object.keys(data).length > 0 ?
        <label className='block col-span-full'>
          <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
            <text className='font-bold'>Description: </text><span>{data?.description}</span>
          </span>
        </label>
        
      :

      <Textarea
        label="Description"
        placeholder="Enter description"
        {...register('description')}
        // error={errors?.description?.message}
        // textareaClassName="h-20"
        className="[&>.ql-container_.ql-editor]:min-h-[100px] col-span-full"
        rows={4}
        textareaClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
      />
      }
      
      {isViewMode && !!data && Object.keys(data).length > 0 ?
        <label className='block'>
          <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
            <text className='font-bold'>Timezone: </text><span>{data?.schedules[0].timezone}</span>
          </span>
        </label>
        
      :
      <Controller
        control={control}
        name={`schedules.0.timezone`}
        render={({ field: { onChange, value } }) => (
          <Select
            prefix={<PiClock className="h-6 w-6 text-gray-500" />}
            placeholder="Select Timezone"
            options={timezones}
            onChange={onChange}
            label="Time zone"
            value={value}
            // className="col-span-full"
            getOptionValue={(option: any) => option.value}
            displayValue={(selected: any) =>
              timezones?.find((tmz) => tmz.value === selected)
                ?.label ?? ''
            }
            error={errors?.timezone?.message as string}
            dropdownClassName="z-[9991]"
          />
        )}
      />
      }

      {isViewMode && !!data && Object.keys(data).length > 0 ?
        <label className='block'>
          <span className='rizzui-input-label block text-sm mb-1.5 font-medium'>
            <text className='font-bold'>Timezone: </text><span>{data?.schedules[0].clock}</span>
          </span>
        </label>
        
      :
      <Controller
        control={control}
        name={`schedules.0.clock`}
        render={({ field: { onChange, value } }) => (
          <Select
            // prefix={<PiClock className="h-6 w-6 text-gray-500" />}
            placeholder="Select clock"
            options={clock}
            onChange={handleClockChange}
            label="Clock"
            value={!!clockValue ? clockValue : value}
            // className="col-span-full"
            getOptionValue={(option: any) => option.value}
            displayValue={(selected: any) =>
              clock?.find((tmz) => tmz.value === selected)
                ?.label ?? ''
            }
            error={errors?.clock?.message as string}
            dropdownClassName="z-[9991]"
          />
        )}
      />
      }
      
    </FormGroup>
  );
}
