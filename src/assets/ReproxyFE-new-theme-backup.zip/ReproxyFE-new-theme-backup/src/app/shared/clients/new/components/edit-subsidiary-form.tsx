'use branch';

import toast from 'react-hot-toast';
import { SubmitHandler, Controller } from 'react-hook-form';
import { PiEnvelopeSimple } from 'react-icons/pi';
import { Form } from '@/components/ui/form';
import { Text } from '@/components/ui/text';
import { Input } from '@/components/ui/input';
// import { Button } from '@/components/ui/button';
// import { Tooltip } from '@/components/ui/tooltip';
import FormGroup from '@/app/shared/form-group';
import FormFooter from '@/components/form-footer';
import { PhoneNumber } from '@/components/ui/phone-input';
import { useParams, useRouter } from 'next/navigation';
// import { useState } from 'react';
// import AddContactForm from './add-contact-modal';
// import AddSubsidiaryForm from './add-subsidiary-modal';
// import OrderTable from '@/app/shared/ecommerce/order/order-list/table';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import { createClient } from '@/redux/slices/clientsSlice/createClient';
import Spinner from '@/components/ui/spinner';
import { useEffect, useState } from 'react';
import { fetchClientByClientId } from '@/redux/slices/clientsSlice/getClientByClientId';
import { updateClient } from '@/redux/slices/clientsSlice/updateClient';
import { fetchSubsidiaryById } from '@/redux/slices/subsidiarySlice/getSubsidiaryById';
import {
  SubsidiaryInfoFormTypes,
  subsidiaryInfoFormSchema,
} from '@/utils/validators/subsidiary-info.schema';
import { editSubsidiary } from '@/redux/slices/subsidiarySlice/editSubsidiary';

export default function EditSubsidiaryForm() {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const params = useParams();
  const id = params?.slug[1];
  const updateSubsidiaryData = useAppSelector(
    (state) => state?.editSubsidiaryData
  );
  const subsidiaryById = useAppSelector(
    (state) => state?.getSubsidiaryDetailById
  );
  const [formData, setFormData] = useState({
    branch_name: subsidiaryById?.subsidiaryDetailData?.branch_name || '',
    branch_unique_name:
      subsidiaryById?.subsidiaryDetailData?.branch_unique_name || '',
    trading_name: subsidiaryById?.subsidiaryDetailData?.trading_name || '',
    email: subsidiaryById?.subsidiaryDetailData?.email || '',
    phone_number: subsidiaryById?.subsidiaryDetailData?.phone_number || '',
    main_contact: subsidiaryById?.subsidiaryDetailData?.main_contact || '',
    street_address:
      subsidiaryById?.subsidiaryDetailData?.address?.street_address || '',
    town: subsidiaryById?.subsidiaryDetailData?.address?.town || '',
    postcode: subsidiaryById?.subsidiaryDetailData?.address?.postcode || '',
  });

  const handleChange = (name: any, value: any) => {
    // console.log('e', e);

    // const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  // const [subsidiary, setSubsidiary] = useState<boolean>(false);

  // const closeContactPopup = (toggle: boolean) => {
  //   setContact(toggle);
  // };
  // const closeSubsidiaryPopup = (toggle: boolean) => {
  //   setSubsidiary(toggle);
  // };
  useEffect(() => {
    dispatch(fetchSubsidiaryById(id));
  }, [dispatch]);

  const onSubmit: SubmitHandler<SubsidiaryInfoFormTypes> = async (data) => {
    try {
      const updatedData = { ...data, branch_id: id };
      const clientResponse = await dispatch(editSubsidiary(updatedData));
      if (clientResponse.payload.status === 'SUCCESS') {
        toast.success(
          <Text as="b">{clientResponse.payload?.message_key}</Text>
        );
        router.push('/clients');
      } else if (clientResponse.payload.status !== 'SUCCESS') {
        toast.error(
          <Text as="b">
            {clientResponse.payload?.response?.data?.message_key}
          </Text>
        );
        return;
      }
    } catch (err) {
      console.error(err);
    }
    console.log('Profile settings data ->', {
      ...data,
      updateSubsidiaryData,
    });
  };
  console.log('data ->', subsidiaryById, formData);

  return (
    <Form<SubsidiaryInfoFormTypes>
      validationSchema={subsidiaryInfoFormSchema}
      // resetValues={reset}
      onSubmit={onSubmit}
      className="@container"
    >
      {({ register, control, formState: { errors }, setValue, getValues }) => {
        return (
          <>
            {!subsidiaryById?.isSuccess || updateSubsidiaryData?.isLoading ? (
              <Spinner />
            ) : (
              <>
                <FormGroup
                  title="Subsidiary Info Section"
                  description="Update subsidiary details here"
                  className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
                />
                <div className="mb-5 grid gap-7 @2xl:gap-9 @3xl:gap-11">
                  <FormGroup
                    title="Branch Name"
                    className="pt-5 @2xl:pt-7 @3xl:grid-cols-12 @3xl:pt-9"
                  >
                    <Input
                      placeholder="Branch Name"
                      {...register('branch_name')}
                      value={
                        formData?.branch_name ||
                        subsidiaryById?.subsidiaryDetailData?.branch_name
                      }
                      onChange={(e: any) =>
                        handleChange('branch_name', e.target.value)
                      }
                      error={errors.branch_name?.message}
                      className="flex-grow"
                    />
                  </FormGroup>
                  <FormGroup title="Unique Name" className=" @3xl:grid-cols-12">
                    <Input
                      placeholder="Unique Name"
                      {...register('branch_unique_name')}
                      value={
                        formData?.branch_unique_name ||
                        subsidiaryById?.subsidiaryDetailData?.branch_unique_name
                      }
                      onChange={(e: any) =>
                        handleChange('branch_unique_name', e.target.value)
                      }
                      error={errors.branch_unique_name?.message}
                      className="flex-grow"
                    />
                  </FormGroup>

                  <FormGroup
                    title="Email Address"
                    className="@3xl:grid-cols-12"
                  >
                    <Input
                      className="flex-grow"
                      {...register('email')}
                      prefix={
                        <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                      }
                      type="email"
                      placeholder="georgia.young@example.com"
                      value={
                        formData?.email ||
                        subsidiaryById?.subsidiaryDetailData?.email
                      }
                      onChange={(e: any) =>
                        handleChange('email', e.target.value)
                      }
                      error={errors.email?.message}
                    />
                  </FormGroup>
                  <FormGroup
                    title="Mobile Number"
                    className=" @3xl:grid-cols-12 "
                  >
                    <Controller
                      name="phone"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <PhoneNumber
                          // label="Phone Number"
                          {...register('phone')}
                          placeholder="Phone Number"
                          error={errors.phone?.message}
                          country="us"
                          value={
                            formData?.phone_number ||
                            subsidiaryById?.subsidiaryDetailData?.phone
                          }
                          onChange={(e: any) =>
                            handleChange('phone_number', e.target)
                          }
                          className="rtl:[&>.selected-flag]:right-0"
                          inputClassName="rtl:pr-12"
                          buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                        />
                      )}
                    />
                  </FormGroup>

                  <FormGroup
                    title="Address:"
                    className="pt-2 @2xl:pt-5 @3xl:grid-cols-12 @3xl:pt-7"
                  />
                  <FormGroup title="Street" className="@3xl:grid-cols-12">
                    <Input
                      placeholder="Street"
                      {...register('street_address')}
                      value={
                        formData?.street_address ||
                        subsidiaryById?.subsidiaryDetailData?.address
                          ?.street_address
                      }
                      onChange={(e: any) =>
                        handleChange('street_address', e.target.value)
                      }
                      error={errors.street_address?.message}
                      className="col-span-full"
                    />{' '}
                  </FormGroup>

                  <FormGroup title="Town" className="@3xl:grid-cols-12">
                    <Input
                      placeholder="Town Name"
                      {...register('town')}
                      value={
                        formData?.town ||
                        subsidiaryById?.subsidiaryDetailData?.address?.town
                      }
                      onChange={(e: any) =>
                        handleChange('town', e.target.value)
                      }
                      error={errors.town?.message}
                      className="flex-grow"
                    />{' '}
                  </FormGroup>

                  <FormGroup title="Post Code" className="@3xl:grid-cols-12">
                    <Input
                      placeholder="Postcode"
                      {...register('postcode')}
                      value={
                        formData?.postcode ||
                        subsidiaryById?.subsidiaryDetailData?.address?.postcode
                      }
                      onChange={(e: any) =>
                        handleChange('postcode', e.target.value)
                      }
                      error={errors.postcode?.message}
                      className="flex-grow"
                    />
                  </FormGroup>
                </div>
                <br />
                <hr />
                {/* <FormGroup
              title="Contact Info Section"
              description="Update contact details here"
              className="py-2 @2xl:py-5 @3xl:grid-cols-12 @3xl:py-7"
            />
            <Tooltip
              placement="right"
              color="invert"
              content="maximum number of contacts allowed: 3"
            >
              <Button
                onClick={() => {
                  setContact(true);
                }}
              >
                Add Contacts
              </Button>
            </Tooltip>
            <br />
            {contact && (
              <AddContactForm
                toggle={contact}
                handleClose={closeContactPopup}
              />
            )}
            <br />
            <hr />
            <FormGroup
              title="Subsidiary Info Section"
              description="Update subsidiary details here"
              className="py-2 @2xl:py-5 @3xl:grid-cols-12 @3xl:py-7"
            />
            <OrderTable
              data={orderData}
              variant="elegant"
              className="[&_.table-filter]:hidden [&_.table-pagination]:hidden"
            />
            <br />
            <Tooltip
              color="invert"
              placement="right"
              content="Click to add a Subsidiary"
            >
              <Button
                onClick={() => {
                  setSubsidiary(true);
                }}
              >
                Add Subsidiaries
              </Button>
            </Tooltip>
            {subsidiary && (
              <AddSubsidiaryForm
                toggle={subsidiary}
                handleClose={closeSubsidiaryPopup}
              />
            )} */}
                <FormFooter
                  // isLoading={isLoading}
                  handleAltBtn={() => router.push('/clients')}
                  altBtnText="Back"
                  submitBtnText="Update Subisidiary"
                />
              </>
            )}
          </>
        );
      }}
    </Form>
  );
}
