'use client';

import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { SubmitHandler, Controller } from 'react-hook-form';
import SelectLoader from '@/components/loader/select-loader';
import QuillLoader from '@/components/loader/quill-loader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Text, Title } from '@/components/ui/text';
import { Form } from '@/components/ui/form';
import cn from '@/utils/class-names';
import { Textarea } from '@/components/ui/textarea';
import {
  CategoryFormInput,
  categoryFormSchema,
} from '@/utils/validators/create-category.schema';
import UploadZone from '@/components/ui/file-upload/upload-zone';
import { ActionIcon } from '@/components/ui/action-icon';
import { PiPlusBold, PiXBold } from 'react-icons/pi';
import { PhoneNumber } from '@/components/ui/phone-input';
import { PiEnvelopeSimple } from 'react-icons/pi';
// import {
//   SubsidiaryBySPInfoFormTypes,
//   subsidiaryBySPInfoFormSchema,
//   defaultValues,
// } from '@/utils/validators/subsidiary-info-SP.schema';
import { editSubsidiary } from '@/redux/slices/subsidiarySlice/editSubsidiary';
import { deleteSubsidiary } from '@/redux/slices/subsidiarySlice/deleteSubsidiary';
import {
  SubsidiaryInfoFormTypes,
  subsidiaryInfoFormSchema,
  defaultValues,
} from '@/utils/validators/subsidiary-info.schema';
import { createSubsidiary } from '@/redux/slices/subsidiarySlice/createSubsidiary';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import toast from 'react-hot-toast';
import { fetchSubsidiaryById } from '@/redux/slices/subsidiarySlice/getSubsidiaryById'
import DeletePopover from '@/app/shared/delete-popover';
import { useForm, UseFormReturn } from 'react-hook-form';


// a reusable form wrapper component
function HorizontalFormBlockWrapper({
  title,
  description,
  children,
  className,
  isModalView = true,
}: React.PropsWithChildren<{
  title: string;
  description?: string;
  className?: string;
  isModalView?: boolean;
}>) {
  return (
    <div
      className={cn(
        className,
        isModalView ? '@5xl:grid @5xl:grid-cols-6' : ' '
      )}
    >
      {isModalView && (
        <div className="col-span-2 mb-6 pe-4 @5xl:mb-0">
          <Title as="h6" className="font-semibold">
            {title}
          </Title>
          <Text className="mt-1 text-sm text-gray-500">{description}</Text>
        </div>
      )}

      <div
        className={cn(
          'grid grid-cols-2 gap-3 @lg:gap-4 @2xl:gap-5',
          isModalView ? 'col-span-4' : ' '
        )}
      >
        {children}
      </div>
    </div>
  );
}

const toastOptions = {
  style: {
    zIndex: 9999, // Set the desired z-index value
  },
};

// main category form component for create and update category
export default function EditSubsidiaryModalView({...props}: any) {
  const data = props.data
  const clientId = data?.client?.client_id
  
  const dispatch = useAppDispatch();
  const [reset, setReset] = useState({});
  const [isLoading, setLoading] = useState<boolean>(false);
  const [isOpenFormDetail, setIsOpenFormDetail] = useState<boolean>(false)
  const [subsidiaryBranchId, setSubsidiaryBranchId] = useState<any>('')
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [detailSubsidiaryData, setDetailSubsidiaryData] = useState<any>();
  const [mainContactDialCode, setMainContactDialCode] = useState<string>('')
  const [mainContactNumber, setMainContactNumber] = useState<string>('')

  const [phoneDialCode, setPhoneDialCode] = useState<string>('')


  const onSubmit: SubmitHandler<SubsidiaryInfoFormTypes> = async (formData) => {
    
      setLoading(true);

      try {
        const new_data = { 
          branch_id: data?.branch_id,
          branch_name: formData.branch_name,
          postcode: formData.postcode,
          street_address: formData.street_address,
          town: formData.town,
          phone_number: phoneNumber,
          trading_name: formData.trading_name,
          branch_unique_name: formData.branch_unique_name,
          email: formData.email,
          phone_number_dial_code: phoneDialCode,
          main_contact_dial_code: mainContactDialCode,
          main_contact: mainContactNumber,
        }
        const resultAction = await dispatch(editSubsidiary(new_data))
        if(editSubsidiary.fulfilled.match(resultAction)) {
          const editedData = resultAction?.payload
          toast.success(<Text as="b">{editedData?.message_key}</Text>,  {
            duration: 5000,
          });
          // setReset(true)
          setLoading(false)
          props.isOpened(false)
        } else {
          if(resultAction.payload) {
            toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>, {
              duration: 5000,
            });
            setLoading(false)
            return
          } else {
            toast.error('Authentication Failed', {
              duration: 5000,
            })
            setLoading(false)
            return
          }
        }
      } catch (err) {
        console.error(err);
        toast.error(<Text as="b">Something went wrong!</Text>);
        setLoading(false)
      }
  };
  

  const handleChange = (value: any, countryCode: any, e: any) => {
    // Update the phoneNumber state when the input value changes
    const splittedVal = e.target.value.split(' ')
    const concatenatedArray = [].concat(...splittedVal.slice(1))
    const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
    setPhoneNumber(concatenatedString);
    setPhoneDialCode(countryCode.dialCode)
  };

  const handleChangeMainContact = (value: any, countryCode: any, e: any) => {
    // Update the Main Contact Number state when the input value changes
    const splittedVal = e.target.value.split(' ')
    const concatenatedArray = [].concat(...splittedVal.slice(1))
    const concatenatedString = concatenatedArray.join('').replace(/[^\w\s]/gi, '');
    setMainContactNumber(concatenatedString);
    setMainContactDialCode(countryCode.dialCode)
  };

  const { control, register, setValue, getValues, formState: { errors } } = useForm<SubsidiaryInfoFormTypes>({
    defaultValues: defaultValues,
    mode: 'onChange'
  });

  useEffect(() => {
    if(!!data === true && Object.keys(data).length > 0) {
      const fields = ['phone_number_dial_code', 'main_contact_dial_code', 'branch_name', 'branch_unique_name', 'email', 'phone_number', 'main_contact', 'address', 'trading_name'];
      let phone_dial_code = ''
      let contact_dial_code = ''
      fields.forEach((field: any) =>  {
        if(field == 'address') {
          const address_fields: any = ['address_line_2', 'borough', 'postcode', 'street_address', 'town'];
          address_fields.forEach((addressValue: any) => {
            const address = data[field]
            setValue(addressValue, address[addressValue])
          })
        } else {
          setValue(field, data[field])

          if(field === 'main_contact_dial_code') {
            contact_dial_code = data[field]
            setMainContactDialCode(data[field])
          }
          if(field === 'main_contact') {
            const contact_detail = `${contact_dial_code}${data[field]}`
            setValue(field, contact_detail)
            setMainContactNumber(data[field])
          }
          if(field === 'phone_number_dial_code') {
            phone_dial_code = data[field]
            setPhoneDialCode(data[field])
          }
          if(field === 'phone_number') {
            const phone_detail = `${phone_dial_code}${data[field]}`
            setValue(field, phone_detail)
            setPhoneNumber(data[field])
          }
        }
      })
    }
  }, [data])

  return (
    <div className="m-auto px-5 pb-8 pt-5 @lg:pt-6 @2xl:px-7">
        <div className="mb-7 flex items-center justify-between">
        <Title as="h4" className="font-semibold">
          Edit Subsidiary
        </Title>
        <ActionIcon size="sm" variant="text" onClick={() => props.isOpened(false)}>
          <PiXBold className="h-auto w-5" />
        </ActionIcon>
      </div>
    <Form<SubsidiaryInfoFormTypes>
      validationSchema={subsidiaryInfoFormSchema}
      resetValues={reset}
      onSubmit={onSubmit}
      useFormProps={{
        mode: 'onChange',
        defaultValues: defaultValues,
      }}
      className="isomorphic-form flex flex-grow flex-col @container"
    >
      {({ register, control, getValues, setValue, formState: { errors } }) => {
        
        return (
        <>
          <div className="flex-grow pb-10">
            <div
              className={cn(
                'grid grid-cols-1 ',
                props?.isModalView
                  ? 'grid grid-cols-1 gap-8 divide-y divide-dashed  divide-gray-200 @2xl:gap-10 @3xl:gap-12 [&>div]:pt-7 first:[&>div]:pt-0 @2xl:[&>div]:pt-9 @3xl:[&>div]:pt-11'
                  : 'gap-5'
              )}
            >
              <HorizontalFormBlockWrapper
                title={'Edit details:'}
                description={'Edit your information from here'}
                isModalView={props?.isModalView}
              >
                
                  <Input
                    label="Subsidiary Name"
                    placeholder="Enter Subsidiary Name"
                    {...register('branch_name')}
                    error={errors.branch_name?.message}
                  />
              
                
                  <Input
                    label="Unique Name"
                    placeholder="Enter Subsidiary Unique Name"
                    {...register('branch_unique_name')}
                    error={errors.branch_unique_name?.message}
                  />
                  
                    <Input
                      label="Email"
                      {...register('email')}
                      prefix={
                        <PiEnvelopeSimple className="h-6 w-6 text-gray-500" />
                      }
                      type="email"
                      placeholder="georgia.young@example.com"
                      error={errors.email?.message}
                    />

                  <Input
                    label="Trading Name"
                    placeholder="Enter Trading Name"
                    {...register('trading_name')}
                    error={errors.trading_name?.message}
                  />
                  
                  
                    <Controller
                      name="phone_number"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <PhoneNumber
                          label="Phone"
                          error={errors.phone_number?.message}
                          country={'gb'}
                          value={value}
                          onChange={handleChange}
                          placeholder="Enter Phone Number"
                          // countryCodeEditable={false}
                          // className="rtl:[&>.selected-flag]:right-0"
                          inputClassName="rtl:pr-12"
                          buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                          // disabled={isOpenFormDetail || isEditMode}
                        />
                      )}
                    />

                    <Controller
                      name="main_contact"
                      control={control}
                      render={({ field: { value, onChange } }) => (
                        <PhoneNumber
                          label="Main contact number"
                          error={errors.main_contact?.message}
                          country={'gb'}
                          value={value}
                          onChange={handleChangeMainContact}
                          placeholder="Enter main contact number"
                          // countryCodeEditable={false}
                          // className="rtl:[&>.selected-flag]:right-0"
                          inputClassName="rtl:pr-12"
                          buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                          // disabled={isOpenFormDetail || isEditMode}
                        />
                      )}
                    />

                  

              </HorizontalFormBlockWrapper>
              <HorizontalFormBlockWrapper
                title="Address"
                description="Enter address details"
                isModalView={props?.isModalView}
              >
                  
                  <div className="col-span-2">
                   

                    <Textarea
                      label="Address"
                      placeholder="Enter your address"
                      {...register('street_address')}
                      error={errors.street_address?.message}
                      // textareaClassName="h-20"
                      className="[&>.ql-container_.ql-editor]:min-h-[100px] "
                      rows={4}
                      textareaClassName="font-medium text-gray-700 dark:text-gray-600 mb-1.5"
                    />
                    
                  </div>


                      <Input
                        label="Town"
                        {...register('town')}
                        placeholder="Enter town"
                        error={errors.town?.message}
                      />
                    

                      <Input
                        label="Post Code"
                        {...register('postcode')}
                        placeholder="Enter post code"
                        error={errors.postcode?.message}
                      />
                    
              </HorizontalFormBlockWrapper>
            </div>
          </div>

          <div className="mt-8 flex justify-end gap-3">
            {/* {
              isOpenFormDetail ? 
              <DeletePopover
                title={`Delete`}
                description={`Are you sure you want to delete the entry?`}
                onDelete={() => onDeleteItem(detailSubsidiaryData?.branch_id)}
              />
              : ""
            } */}
            <Button
                className="w-auto"
                variant="outline"
                onClick={() => props.isOpened(false)}
            >
                Cancel
            </Button>
            <Button type="submit" isLoading={isLoading} className="w-auto">
                {isOpenFormDetail ? 'Edit' : 'Save'}
            </Button>
        </div>
        </>
      )}}
    </Form>
    </div>
  );
}
