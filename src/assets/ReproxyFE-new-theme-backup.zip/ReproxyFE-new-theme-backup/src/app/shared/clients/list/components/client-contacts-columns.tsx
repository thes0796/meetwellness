'use client';

import Link from 'next/link';
import { HeaderCell } from '@/components/ui/table';
import { Text } from '@/components/ui/text';
import { Tooltip } from '@/components/ui/tooltip';
import { ActionIcon } from '@/components/ui/action-icon';
import EyeIcon from '@/components/icons/eye';
import PencilIcon from '@/components/icons/pencil';
import TableAvatar from '@/components/ui/avatar-card';
import DateCell from '@/components/ui/date-cell';
import DeletePopover from '@/app/shared/delete-popover';
import { Checkbox } from '@/components/ui/checkbox';
import {
  PiDeviceMobileCameraDuotone,
  PiEnvelopeDuotone,
  PiPhoneCallDuotone,
} from 'react-icons/pi';

type Columns = {
  sortConfig?: any;
  onDeleteClientContact?: (id: string) => void;
  onHeaderCellClick: (value: string) => void;
  onViewContact?: (row: string) => void;
  onEditContact?: (row: string) => void;
};

export const getContactsColumns = ({
  sortConfig,
  onDeleteClientContact,
  onHeaderCellClick,
  onViewContact,
  onEditContact,
}: Columns) => [
  {
    title: <HeaderCell title="Contact Manager" />,
    dataIndex: 'contacts',
    key: 'contacts',
    width: 100,
    // render: (value: any) => <Text>{value?.name}</Text>,
    render: (_: any, row: any) => (
      <TableAvatar
        src={row?.profile_pic}
        name={row?.contacts?.first_name || row?.user_name}
      />
    )
  },
  {
    title: <HeaderCell title="User Name" />,
    dataIndex: 'user_name',
    key: 'user_name',
    width: 100,
    hidden: 'name',
    render: (_: any, row: any) => ( <Text>{row?.user_name}</Text>),
  },

  {
    title: <HeaderCell title="Contact" />,
    dataIndex: 'email_address',
    key: 'email_address',
    width: 100,
    hidden: 'name',
    render: (_: string, row: any) => (
      <>
      <a href={`mailto:${row?.email_address}`}>
      <Tooltip
        size="sm"
        content={row?.email_address}
        placement="top"
        color="invert"
      >
        <ActionIcon
          as="span"
          size="sm"
          variant="outline"
          className="hover:cursor-pointer hover:text-gray-700"
        >
          <PiEnvelopeDuotone className="h-4 w-4" />
        </ActionIcon>
      </Tooltip>
      </a>

      <a href={`tel:${row?.phone}`} className='pl-2'>
      <Tooltip size="sm" content={row?.phone} placement="top" color="invert">
        <ActionIcon
          as="span"
          size="sm"
          variant="outline"
          className="hover:cursor-pointer hover:text-gray-700"
        >
          <PiPhoneCallDuotone className="h-4 w-4" />
        </ActionIcon>
      </Tooltip>
      </a>
      </>
    ),
  },
  // {
  //   title: <HeaderCell title="Phone" />,
  //   dataIndex: 'phone',
  //   key: 'phone',
  //   width: 100,
  //   hidden: 'name',
  //   render: (_: string, row: any) => (
  //     <a href={`tel:${row?.phone}`}>
  //     <Tooltip size="sm" content={row?.phone} placement="top" color="invert">
  //       <ActionIcon
  //         as="span"
  //         size="sm"
  //         variant="outline"
  //         className="hover:cursor-pointer hover:text-gray-700"
  //       >
  //         <PiPhoneCallDuotone className="h-4 w-4" />
  //       </ActionIcon>
  //     </Tooltip>
  //     </a>
  //   ),
  // },

  {
    // Need to avoid this issue -> <td> elements in a large <table> do not have table headers.
    title: <HeaderCell title="Actions" className="justify-center" />,
    dataIndex: 'action',
    key: 'action',
    width: 100,
    render: (_: string, row: any) => (
      <div className="flex items-center justify-center gap-3 pe-0">
        <Tooltip
          size="sm"
          content={'Edit Client Contact'}
          placement="top"
          color="invert"
        >
          {/* <Link
            href={`/clients/${row?.contacts?.client_id}/contact/${row?.contacts?.user_id}/edit`}
            // target="_blank"
          > */}
            <ActionIcon
              as="span"
              size="sm"
              variant="outline"
              className="hover:text-gray-700 hover:cursor-pointer"
              onClick={() => onEditContact && onEditContact(row)}
            >
              <PencilIcon className="h-4 w-4" />
            </ActionIcon>
          {/* </Link> */}
        </Tooltip>
        <Tooltip
          size="sm"
          content={'View Client Contact'}
          placement="top"
          color="invert"
        >
          {/* <Link href="/clients/view" target="_blank"> */}
          <ActionIcon
            as="span"
            size="sm"
            variant="outline"
            className="hover:cursor-pointer hover:text-gray-700"
            onClick={() => onViewContact && onViewContact(row)}
          >
            <EyeIcon className="h-4 w-4" />
          </ActionIcon>
          {/* </Link> */}
        </Tooltip>

        <DeletePopover
          title={`Delete the contact`}
          description={`Are you sure you want to delete this #${row?.user_name} order?`}
          onDelete={() =>
            // onDeleteClientContact && onDeleteClientContact(row.client_id)
            onDeleteClientContact &&
            onDeleteClientContact(row?.user_id)
          }
        />
      </div>
    ),
  },
];
