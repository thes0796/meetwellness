'use client';

import { useParams } from 'next/navigation';
import EditClientForm from './components/edit-client-form';
import AddClientForm from './components/add-client-form';
import MainForm from './components/main-form';
import EditSubsidiaryForm from './components/edit-subsidiary-form';
import EditClientContactForm from './components/edit-contact-form';

export default function AddClientCOmponent() {
  const params = useParams();
  // console.log('params', params);
  return (
    <>
      {/* {params?.slug[1] === 'contact' && params?.slug[3] === 'edit' ? (
        <EditClientContactForm />
      ) : params?.slug[0] === 'subsidiary' && params?.slug[2] === 'edit' ? (
        <EditSubsidiaryForm />
      ) : params?.slug[1] === 'edit' ? (
        <EditClientForm />
      ) : ( */}
        <MainForm />
      {/* )} */}
    </>
  );
}
