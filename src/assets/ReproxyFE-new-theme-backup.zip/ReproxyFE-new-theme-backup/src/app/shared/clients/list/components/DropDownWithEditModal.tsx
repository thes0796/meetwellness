'use client';
import React, { useEffect, useState } from 'react';
import { Dropdown, Button, Modal, Input } from 'rizzui';
import toast from 'react-hot-toast';
import { PiPhoneCallDuotone, PiEnvelopeDuotone, PiUserBold, PiUserLight, PiPlusBold, PiPlusLight, PiTriangleFill } from 'react-icons/pi';
import { Text } from '@/components/ui/text';
import Project from './modal/project'
import {createProject} from '@/redux/slices/serviceProviderSlice/createProject'
import { fetchProjectById } from '@/redux/slices/serviceProviderSlice/getProject';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';

const DropdownWithEditModal = ({...props}) => {
  
  const dispatch = useAppDispatch();
  const projectData = props?.data
  const [items, setItems] = useState<any>(projectData);
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const [currentItem, setCurrentItem] = useState<any>(null);
  const [currentItemIndex, setCurrentItemIndex] = useState<any>(null);
  const [projectId, setProjectId] = useState<any>('')
  const [isAddNew, setIsAddNew] = useState<boolean>(false)
  
  const [isProject, setIsProject] = useState<boolean>(false)

  const handleMenuClick = (item: any, index: any) => {
    setCurrentItem(item);
    setCurrentItemIndex(index);
    setIsModalVisible(true);
    setIsProject(true)
  };



  const handleCancel = () => {
    setIsModalVisible(false);
    setCurrentItem(null)
    setIsProject(false)
    props.editProject()
    setIsAddNew(false)
  };

  const handleAddNew = async () => {
    try {
      const project_length = items.length - 1
      const newItem = items.length == 1 ? 'Default' : `Default ${project_length}`;
      let project_data = {
        project_name: newItem,
        ...(!!projectData[0]?.client_id ? { client_id: projectData.length > 0 ? projectData[0]?.client_id : '' } : {}),
        ...(!!projectData[0]?.branch_id ? {branch_id: projectData.length > 0 ? projectData[0]?.branch_id : '' } : {})
      }

      const resultAction = await dispatch(createProject(project_data))
      if(createProject.fulfilled.match(resultAction)) {
        const resultData = resultAction?.payload
        toast.success(<Text as="b">{resultData?.message_key}</Text>,  {
          duration: 5000,
        });
        setProjectId(resultData?.data?.project_id)
        // setIsModalVisible(true)
        // setIsProject(true)
      } else {
        if(resultAction.payload) {
          toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>, {
            duration: 5000,
          });
          // setLoading(false)
          return
        } else {
          toast.error('Authentication Failed', {
            duration: 5000,
          })
          // setLoading(false)
          return
        }
      }
    } catch (err: any) {
      toast.error(err, {
        duration: 5000,
      })
      console.error('error: ', err)
    }
    
  };

//   const menu = (
//     <Dropdown>
//       {items.map((item, index) => (
//         <Dropdown.Item key={index} onClick={() => handleMenuClick(item, index)}>
//           {item}
//         </Dropdown.Item>
//       ))}
//       {/* <Dropdown.Divider /> */}
//       <Dropdown.Item key="add-new">
//         <Button onClick={handleAddNew}>Add New</Button>
//       </Dropdown.Item>
//     </Dropdown>
//   );

const fetchProjectData = async (id: any) => {
  try {
    const resultAction = await dispatch(fetchProjectById(id))
    if(fetchProjectById.fulfilled.match(resultAction)) {
      const resultData = resultAction?.payload
      // toast.success(<Text as="b">{resultData?.message_key}</Text>,  {
      //   duration: 5000,
      // });
      setCurrentItem(resultData?.data)
      setIsModalVisible(true)
      setIsProject(true)
      setIsAddNew(true)
      setProjectId('')
    } else {
      if(resultAction.payload) {
        toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>, {
          duration: 5000,
        });
        // setLoading(false)
        return
      } else {
        toast.error('Authentication Failed', {
          duration: 5000,
        })
        // setLoading(false)
        return
      }
    }
  } catch (err: any) {
    toast.error(err, {
      duration: 5000,
    });
    console.error('error: ', err)
  }
}

useEffect(() => {
  if(!!projectId === true && projectId != '') {
    fetchProjectData(projectId)
    // setProjectId('')
  }
}, [projectId])

// console.log('items-=-==-=-', items)
  return (
    <>
      <Dropdown>
    
      <Dropdown.Trigger className='flex'>
        <Button variant="outline" className='px-2 justify-around' style={{maxWidth: '115px', minWidth: '115px'}}>
          {items && items.length == 1 ? items[0]?.project_name.length > 13 ? items[0]?.project_name.substring(0, 13) + '...' : items[0]?.project_name : items && items.length}
          <PiPlusBold className='ml-2 mr-0' color="#009129" fontSize="1.2em"/>
        </Button>
     </Dropdown.Trigger>
     <Dropdown.Menu className='max-h-80 overflow-y-scroll'>
      <Dropdown.Item key="add-new" onClick={handleAddNew}>
        <span className="grid gap-0.5 hover:cursor-pointer">
          <figure className={'flex items-center gap-3'}>
            <figcaption className="grid gap-0.5">
              <Text className="font-lexend text-sm font-semibold text-gray-900 dark:text-gray-700">
                + Add
              </Text>
            </figcaption>
          </figure>
        </span>
      </Dropdown.Item>
        {projectData && projectData.map((item:any, index:any) => (
          <Dropdown.Item key={index} onClick={() => handleMenuClick(item, index)} className='px-2 justify-between text-left'>
            {item?.project_name}
            <PiTriangleFill style={{ transform: 'rotate(90deg)' }}  />
          </Dropdown.Item>
        ))}
        
     </Dropdown.Menu>
    </Dropdown>
      

      <Modal
        isOpen={isModalVisible} 
        onClose={() => handleCancel()}
        customSize={"1080px"}
        className="z-[9990]"
      >
        
        {isProject && <Project handleCancel={handleCancel} data={currentItem} editProject={props.editProject} isAddNew={isAddNew} />}
      </Modal>
      
    </>
  );
};

export default DropdownWithEditModal;
