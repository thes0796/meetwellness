'use client';

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Element } from 'react-scroll';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, FormProvider, SubmitHandler } from 'react-hook-form';
import cn from '@/utils/class-names';
import { Text, Title } from '@/components/ui/text';
// import FormNav, {
//   formParts,
// } from '@/app/shared/ecommerce/product/create-edit/form-nav';
import { ActionIcon } from '@/components/ui/action-icon';
import { PiPlusBold, PiXBold, PiClock, PiEnvelopeSimple } from 'react-icons/pi';
// import ProductSummary from '@/app/shared/ecommerce/product/create-edit/product-summary';
// import { defaultValues } from '@/app/shared/ecommerce/product/create-edit/form-utils';
// import ProductMedia from '@/app/shared/ecommerce/product/create-edit/product-media';
// import PricingInventory from '@/app/shared/ecommerce/product/create-edit/pricing-inventory';
// import ProductIdentifiers from '@/app/shared/ecommerce/product/create-edit/product-identifiers';
// import ShippingInfo from '@/app/shared/ecommerce/product/create-edit/shipping-info';
// import ProductSeo from '@/app/shared/ecommerce/product/create-edit/product-seo';
// import DeliveryEvent from '@/app/shared/ecommerce/product/create-edit/delivery-event';
// import ProductVariants from '@/app/shared/ecommerce/product/create-edit/product-variants';
// import ProductTaxonomies from '@/app/shared/ecommerce/product/create-edit/product-tags';
// import FormFooter from '@/components/form-footer';
import { useAppDispatch, useAppSelector } from '@/redux/redux-hooks';
import {
  ProjectInfoFormInput,
  ProjectInfoFormSchema,
  defaultValues,
} from '@/utils/validators/create-project-info.schema';
import { useLayout } from '@/hooks/use-layout';
import { LAYOUT_OPTIONS } from '@/config/enums';
import { Button } from '@/components/ui/button';
import ProjectInformation from './components/projectInformation'
import ProjectWorkSchedule from './components/projectWorkSchedule';
import ProjectBreakSchedule from './components/projectBreakSchedule';
import ProjectTimesheetCycle from './components/projectTimesheetCycle';
import { updateSchedules } from '@/redux/slices/subsidiarySlice/updateSchedule'
import { updateProject } from '@/redux/slices/serviceProviderSlice/updateProject'

const MAP_STEP_TO_COMPONENT = {
  ['projectInformation']: ProjectInformation,
  ['projectWorkSchedule']: ProjectWorkSchedule,
  ['projectBreakSchedule']: ProjectBreakSchedule,
  ['projectTimesheetCycle']: ProjectTimesheetCycle,
};

interface IndexProps {
  handleCancel?: any;
  className?: string;
  data?: any;
  editProject?: any;
  isAddNew?: boolean;
}

export default function Project({
  handleCancel,
  data,
  className,
  editProject,
  isAddNew,
}: IndexProps) {
  // console.log('data---===-=-=-=-=', data)
  const dispatch = useAppDispatch();
  const { layout } = useLayout();
  const [isLoading, setLoading] = useState(false);
  const [clockValue, setClockValue] = useState<any>(!!data && data?.schedules.length > 0 ? data?.schedules[0]?.clock : "")
  const [billableValue, setBillableValue] = useState<boolean>(!!data && data?.schedules.length > 0 && data?.schedules[0].billable)
  const [isViewMode, setIsViewMode] = useState<boolean>(false)
  const [isEditable, setIsEditable] = useState<boolean>(false)
  const [selectedTimesheet, setSelectedTimesheet] = useState<any>(!! data && data?.schedules.length > 0 && data?.schedules[0].timesheet_cycle || "Daily")

  const formatDateTo12Hour = (date: any) => {
    const hours24 = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const period = hours24 >= 12 ? 'PM' : 'AM';
  
    // Convert 24-hour format to 12-hour format
    let hours12: any = hours24 % 12 || 12; // The hour '0' should be '12'
    hours12 = String(hours12).padStart(2, '0'); // Ensure hours are two digits
  
    return `${hours12}:${minutes} ${period}`;
  }

  const methods = useForm<ProjectInfoFormInput>({
    resolver: zodResolver(ProjectInfoFormSchema),
    defaultValues: defaultValues(data),
  });

  const onSubmit: SubmitHandler<ProjectInfoFormInput> = async (formData: any) => {
    // console.log('formData-=-=-=-=', formData, selectedTimesheet)
  
    setLoading(true);
    if(isViewMode) {
      setIsViewMode(false)
      setLoading(false);
      setIsEditable(true)
    } else if(isEditable || isAddNew) {
      const project_data = {
        project_id: data?.project_id,
        project_name: formData?.project_name,
        description: formData?.description,
      }
      const schedule_data = {
        schedule_id: data?.schedules[0].schedule_id,
        clock: clockValue,
        timezone: formData?.schedules[0].timezone,
        ...(formData?.work_time.filter((v: any) => !!v.start_time && !!v.end_time).length > 0 
        ? 
          {
            time_ranges: clockValue === '12hr' 
            ? 
              formData?.work_time.map((val: any) => {
                return formatDateTo12Hour(val.start_time) + '-' + formatDateTo12Hour(val.end_time)
              })
            :
              formData?.work_time.map((val: any) => 
                new Date(val.start_time).getHours().toString().padStart(2, '0') + ':' + new Date(val.start_time).getMinutes().toString().padStart(2, '0') + '-' + new Date(val.end_time).getHours().toString().padStart(2, '0') + ':' + new Date(val.end_time).getMinutes().toString().padStart(2, '0'))
          }
        : {}),
        
        ...(formData?.break_time.filter((v: any) => !!v.break_start_time && !!v.break_end_time ).length > 0
        ? 
          { breaks: clockValue === '12hr' 
          ? 
            formData?.break_time.map((val: any) => {
              return formatDateTo12Hour(val.break_start_time) + '-' + formatDateTo12Hour(val.break_end_time)
            })
          :
            formData?.break_time.map((val: any) => 
              new Date(val.break_start_time).getHours().toString().padStart(2, '0') + ':' + new Date(val.break_start_time).getMinutes().toString().padStart(2, '0') + '-' + new Date(val.break_end_time).getHours().toString().padStart(2, '0') + ':' + new Date(val.break_end_time).getMinutes().toString().padStart(2, '0')
          ) }
        : {}),
        
        billable: billableValue,
        ...(formData.next_due_date ? { next_due_date: formData.next_due_date } : {}),
        ...(selectedTimesheet ? { timesheet_cycle: selectedTimesheet } : {})
      }

      try {
        const resultAction = await dispatch(updateProject(project_data))
        if(updateProject.fulfilled.match(resultAction)) {
          const editedData = resultAction?.payload
          // toast.success(<Text as="b">{editedData?.message_key}</Text>,  {
          //   duration: 5000,
          // });
          // setLoading(false)
          // handleCancel()
          // editProject()
          
          try {
            const resultAction_1 = await dispatch(updateSchedules(schedule_data))
            if(updateSchedules.fulfilled.match(resultAction_1)) {
              const editedData1 = resultAction_1?.payload
              toast.success(<Text as="b">{editedData1?.message_key}</Text>,  {
                duration: 5000,
              });
              setLoading(false)
              handleCancel()
              editProject()
              setIsEditable(false)
            } else {
              if(resultAction_1.payload) {
                toast.error(<Text as="b">{resultAction_1.payload?.response?.data?.message_key}</Text>, {
                  duration: 5000,
                });
                setLoading(false)
                return
              } else {
                toast.error('Authentication Failed', {
                  duration: 5000,
                })
                setLoading(false)
                return
              }
            }
          } catch (er: any) {
            setLoading(false)
            toast.error(er, {
              duration: 5000,
            })
            console.log('er: ', er)
          }
        } else {
          if(resultAction.payload) {
            toast.error(<Text as="b">{resultAction.payload?.response?.data?.message_key}</Text>, {
              duration: 5000,
            });
            setLoading(false)
            return
          } else {
            toast.error('Authentication Failed', {
              duration: 5000,
            })
            setLoading(false)
            return
          }
        }
      } catch (e: any) {
        setLoading(false)
        toast.error(e, {
          duration: 5000,
        })
        return console.error('error: ', e)
      }
      
    } else {
      console.log('else------', formData)
      setLoading(false)
      handleCancel()
    }
  };

  const handleClockChange = (val: any) => {
    setClockValue(val)
  }

  const handleBillableChange = (e: any) => {
    setBillableValue(e.target.checked)
  }

  useEffect(() => {
    if(!!data && Object.keys(data).length > 0 && !isAddNew) {
      setIsViewMode(true)
    }
  }, [data])

  return (
    <div className="@container m-auto px-5 pb-8 pt-5 @lg:pt-6 @2xl:px-7">
      {/* <FormNav
        className={cn(layout === LAYOUT_OPTIONS.BERYLLIUM && '2xl:top-[72px]')}
      /> */}
      <div className="flex items-center justify-between">
        <Title as="h4" className="font-semibold">
          {isViewMode ? 'Project' : 'New Project'}
        </Title>
        <ActionIcon variant="text" onClick={() => handleCancel()}>
          <PiXBold className="h-5 w-5" />
        </ActionIcon>
      </div>
      <FormProvider {...methods}>
        <form
          onSubmit={methods.handleSubmit(onSubmit)}
          className={cn('[&_label.block>span]:font-medium', className)}
        >
          <div className="mb-10 grid gap-7 divide-y divide-dashed divide-gray-200 @2xl:gap-9 @3xl:gap-11">
            {Object.entries(MAP_STEP_TO_COMPONENT).map(([key, Component]) => (
              <Element
                key={key}
                name={key}
              >
                {<Component className="pt-7 @2xl:pt-9 @3xl:pt-11 px-7" data={data} handleClockChange={handleClockChange} clockValue={clockValue} isViewMode={isViewMode} handleBillableChange={handleBillableChange} billable={billableValue} setSelectedTimesheet={setSelectedTimesheet} selectedTimesheet={selectedTimesheet} />}
              </Element>
            ))}
          </div>

          {/* <FormFooter
            isLoading={isLoading}
            submitBtnText={'Apply'}
          /> */}
          <div className="left-0 right-0 -mb-8 flex items-center justify-end gap-4 px-4 py-4 md:px-5 lg:px-6 3xl:px-8 4xl:px-10 mb-1">
            <Button
              className="w-auto"
              variant="outline"
              onClick={() => handleCancel()}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="capitalize"
              isLoading={isLoading}
            >
              {isViewMode ? 'Edit' : 'Save'}
            </Button>
          </div>
        </form>
      </FormProvider>
    </div>
  );
}
