'use client';
import React from 'react'

const Onboard = () => {
  return (
    <div>
      Onboard
    </div>
  )
}

export default Onboard
