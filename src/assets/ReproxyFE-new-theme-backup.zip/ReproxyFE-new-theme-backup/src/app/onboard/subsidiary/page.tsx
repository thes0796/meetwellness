'use client';

import { useEffect, useState } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { PiArrowRightBold } from 'react-icons/pi';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import toast from 'react-hot-toast';
import { Stepper, Textarea } from 'rizzui';
import { useAuth } from 'AuthContext';
import { useRouter } from 'next/navigation';
import { useAppSelector } from '@/redux/redux-hooks';
import { Text } from '@/components/ui/text';
import logoImg from '@public/logo.svg';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import cn from '@/utils/class-names';
import { PiArrowLineRight } from 'react-icons/pi';
import { SUBSIDIARY } from '@/services/apis/subsidiaryAPI';
import FormGroup from '@/app/shared/form-group';
import AvatarUpload from '@/components/ui/file-upload/avatar-upload';
import { LOGIN } from '@/services/apis/loginAPI';

type FormData = {
  // Step 1
  email_address: string;
  user_name: string;
  name: string;
  phone: string;
  street_address: string;
  town: string;
  postcode: string;
  company_name: string;
  role: string;
  // Step 2
  email: string;
  client_name: string;
  trading_name: string;
  main_contact: string;
  phone_number: string;
  client_unique_name: string;

  branch_name: string;
  branch_unique_name: string;
  address_line_2: string;
  borough: string;
  profile_pic: string;
  country: string;
  sur_name: string;
};

type Option = {
  label: string;
  value: string;
};

export default function SignUpForm() {
  const route = useRouter();
  const { user, user_id } = useAuth();
  const loginResponse = useAppSelector((state) => state?.loginDetails);

  const [stepOnboard, setStepOnboard] = useState(1);
  const [loading, setLoading] = useState(false);
  const [valueSelect, setValueSelect] = useState(null);
  useEffect(() => {
    if (!loginResponse?.loginData || loginResponse?.loginData?.length === 0) {
      route.back();
    }
  }, []);
  const subsidiaryDetails = async () => {
    const { data: response } = await SUBSIDIARY.getSubsidiaryById(null, user);
    if (response) {
      const subData = response?.data?.data_list[0];
      setValue('branch_unique_name', subData?.branch_unique_name);
      setValue('email', subData?.email);
      setValue('phone', subData?.phone);
      setValue('address_line_2', subData?.address?.address_line_2);
      setValue('borough', subData?.address?.borough);
      setValue('branch_name', subData?.branch_name);
      setValue('postcode', subData?.address?.postcode);
      setValue('town', subData?.address?.town);
      setValue('street_address', subData?.address?.street_address);
    }
  };

  const subsidiaryPersonDetails = async () => {
    const { data: response } = await SUBSIDIARY.getSubsidiaryContactById(
      null,
      user
    );
    const subData = response?.data;
    setValue('user_name', subData?.user_name);
    setValue('phone', subData?.phone);
    setValue('name', subData?.contacts?.name);
    setValue('profile_pic', subData?.profile_pic);
  };

  useEffect(() => {
    if (stepOnboard === 1) {
      subsidiaryDetails();
    }
    if (stepOnboard === 2) {
      subsidiaryPersonDetails();
    }
  }, [stepOnboard]);

  const {
    register,
    watch,
    handleSubmit,
    formState: { errors },
    getValues,
    setValue,
    reset,
  } = useForm<FormData>();
  const onSubmit: SubmitHandler<FormData> = async (data) => {
    try {
      setLoading(true);

      // Steps
      if (stepOnboard === 1) {
        const subsidiaryData = {
          branch_unique_name: data?.branch_unique_name,
          email: data?.email,
          phone: data?.phone,
          address_line_2: data?.address_line_2,
          borough: data?.borough,
          branch_name: data?.branch_name,
          postcode: data?.postcode,
          town: data?.town,
          street_address: data?.street_address,
        };

        const { data: response } = await SUBSIDIARY.editSubsidiary(
          subsidiaryData,
          user
        );
        if (response) {
          toast.success(response?.message_key);
          setStepOnboard(2);
          reset();
        }
        setLoading(false);
      } else if (stepOnboard === 2) {
        const subsidiaryPersonData = {
          email_address: data?.email_address,
          phone: data?.phone,
          name: `${data.name} ${data.sur_name}`,
          profile_pic: data?.profile_pic,
        };

        const { data: response } = await SUBSIDIARY.updateSubsidiaryContact(
          subsidiaryPersonData,
          user
        );
        if (response) {
          const { data: response } = await LOGIN.setOnboarding(user);
          if (data) {
            toast.success(response?.message_key);
            setStepOnboard(2);
            route.push('/profile');
            reset();
          }
        }
        setLoading(false);
      }
      //  else if (stepOnboard === 3) {
      //   let inviteData = {
      //     email_address: data?.email_address,
      //   };
      //   console.log('inviteData', inviteData);
      //   const { data: response } = await SUBSIDIARY.createSubsidiaryContact(
      //     inviteData,
      //     user
      //   );
      //   if (response) {
      //     const { data: response } = await LOGIN.setOnboarding(user);
      //     if (data) {
      //       toast.success(response?.message_key);
      //       setStepOnboard(3);
      //       route.push('/profile');
      //     }
      //   }
      //   setLoading(false);
      // }
    } catch (error: any) {
      console.log('error::: ', error);
      toast.error(error?.response?.data?.message_key);
      setLoading(false);
    }
  };

  function AuthNavLink({
    href,
    children,
  }: React.PropsWithChildren<{
    href: string;
  }>) {
    const pathname = usePathname();
    function isActive(href: string) {
      if (pathname === href) {
        return true;
      }
      return false;
    }

    return (
      <Link
        href={href}
        className={cn(
          'inline-flex items-center gap-x-1 rounded-3xl p-2 py-1 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200 md:px-4 md:py-2.5 [&>svg]:w-4 [&>svg]:text-gray-500',
          isActive(href)
            ? 'bg-gray-100 text-gray-900 [&>svg]:text-gray-900'
            : ' '
        )}
      >
        {children}
      </Link>
    );
  }

  return (
    <>
      <header className="flex items-center justify-between p-4 lg:px-16 lg:py-6 2xl:px-24">
        <Link href={'/'}>
          <Image src={logoImg} className="dark:invert" priority alt="qwe" />
        </Link>
        {stepOnboard !== 1 && (
          <div className="flex items-center space-x-2 md:space-x-4">
            <AuthNavLink href={'/'}>
              <PiArrowLineRight className="h-4 w-4" />
              <span>Dashboard</span>
            </AuthNavLink>
          </div>
        )}
      </header>
      <div className="m-auto w-full max-w-xl">
        <Stepper
          currentIndex={stepOnboard - 1}
          className="mx-auto mb-5 w-full max-w-sm px-4"
        >
          <Stepper.Step title="Step 1" />
          <Stepper.Step title="Step 2" />
          <Stepper.Step title="Step 3" />
        </Stepper>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col gap-x-4 gap-y-5 px-4 md:grid md:grid-cols-2 lg:gap-5"
        >
          {stepOnboard === 1 && (
            <>
              <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
                Subsidiary Details
              </Text>
              <Input
                type="text"
                size="lg"
                label="Branch Name"
                placeholder="Enter your branch name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('branch_name', {
                  required: 'Branch name is required',
                })}
                error={errors.branch_name?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Branch unique name"
                placeholder="Enter your branch unique name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('branch_unique_name', {
                  required: 'Branch unique name is required',
                })}
                error={errors.branch_unique_name?.message}
              />
              <Input
                type="email"
                size="lg"
                label="Email"
                className="col-span-2 font-medium"
                inputClassName="text-sm"
                placeholder="Enter your email"
                {...register('email', {
                  required: 'Email is required',
                })}
                error={errors.email?.message}
                disabled
              />
              <Input
                type="number"
                size="lg"
                label="Phone"
                placeholder="Enter your phone"
                className="col-span-2 font-medium"
                inputClassName="text-sm"
                {...register('phone', {
                  required: 'Phone is required',
                })}
                error={errors.phone?.message}
              />
              <Textarea
                label="Street address"
                placeholder="Write you address"
                className="col-span-2 font-medium"
                {...register('street_address', {
                  required: 'Street address is required',
                })}
                error={errors.street_address?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Address line 2"
                placeholder="Enter your address line 2"
                className="col-span-2 font-medium"
                inputClassName="text-sm"
                {...register('address_line_2', {
                  required: 'Address line 2  is required',
                })}
                error={errors.address_line_2?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Borough"
                placeholder="Enter the borough"
                className="font-medium"
                inputClassName="text-sm"
                {...register('borough', {
                  required: 'Borough  is required',
                })}
                error={errors.borough?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Town"
                placeholder="Enter your town name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('town', {
                  required: 'Town name is required',
                })}
                error={errors.town?.message}
              />
              <Input
                type="number"
                size="lg"
                label="Postcode"
                placeholder="Enter your postcode"
                className="font-medium"
                inputClassName="text-sm"
                {...register('postcode', {
                  required: 'Postcode is required',
                })}
                error={errors.town?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Country"
                placeholder="Enter the country"
                className="font-medium"
                inputClassName="text-sm"
                {...register('country', {
                  required: 'Country is required',
                })}
                error={errors.country?.message}
              />
            </>
          )}

          {stepOnboard === 2 && (
            <>
              <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
                Profile
              </Text>
              <FormGroup
                title="Profile Photo"
                description="This will be displayed on your profile."
                className="col-span-2 flex w-full items-center justify-evenly pt-7 text-center @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <div className="col-span-2 flex flex-col items-center gap-4 @xl:flex-row">
                  <AvatarUpload
                    name="profile_pic"
                    setValue={setValue}
                    getValues={getValues}
                    // error={errors?.profile_pic}
                  />
                </div>
              </FormGroup>

              <Input
                type="text"
                size="lg"
                label="Name"
                placeholder="Enter your name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('name', {
                  required: 'Name is required',
                })}
                error={errors.name?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Surname"
                placeholder="Enter your surname"
                className="font-medium"
                inputClassName="text-sm"
                {...register('sur_name', {
                  required: 'Surname is required',
                })}
                error={errors.user_name?.message}
              />
              <Input
                type="email"
                size="lg"
                label="Email"
                className="font-medium"
                inputClassName="text-sm"
                placeholder="Enter your email"
                {...register('email_address', {
                  required: 'Email is required',
                })}
                error={errors.email_address?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Phone number"
                placeholder="Enter your phone number"
                className="font-medium"
                inputClassName="text-sm"
                {...register('phone', {
                  required: 'Phone number is required',
                })}
                error={errors.phone?.message}
              />
            </>
          )}

          {/* {stepOnboard === 3 && (
            <>
              <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
                Invite other persons
              </Text>
              <Input
                type="email"
                size="lg"
                label="Email"
                className="font-medium"
                inputClassName="text-sm"
                placeholder="Enter your email"
                {...register('email', {
                  required: 'Email is required',
                })}
                error={errors.email?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Full Name"
                placeholder="Enter your full name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('name', {
                  required: 'Full name is required',
                })}
                error={errors.name?.message}
              />
              <Input
                type="number"
                size="lg"
                label="Phone number"
                placeholder="Enter your phone number"
                className="font-medium"
                inputClassName="text-sm"
                {...register('phone', {
                  required: 'Phone number is required',
                })}
                error={errors.phone?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Role"
                placeholder="Enter your Role"
                className="font-medium"
                inputClassName="text-sm"
                {...register('role', {
                  required: 'Role is required',
                })}
                error={errors.role?.message}
              />
            </>
          )} */}

          <Button
            disabled={loading}
            isLoading={loading}
            size="lg"
            type="submit"
            className="col-span-2 mb-14 mt-2"
          >
            {stepOnboard === 1 ? (
              <span>Save & Next</span>
            ) : stepOnboard === 2 ? (
              <span>Submit</span>
            ) : (
              <span>Next</span>
            )}
            <PiArrowRightBold className="ms-2 mt-0.5 h-5 w-5" />
          </Button>
        </form>
      </div>
      <div className="fixed bottom-0 flex w-full items-center justify-between gap-10 px-5 pb-3">
        <Button
          disabled={stepOnboard === 1 || stepOnboard === 2}
          onClick={() => {
            setStepOnboard(stepOnboard - 1);
            reset();
          }}
          className=" "
        >
          Back
        </Button>
        <Button
          disabled={stepOnboard === 1}
          onClick={() => {
            if (stepOnboard === 2) {
              route.push('/profile');
            } else {
              setStepOnboard(stepOnboard + 1);
              reset();
            }
          }}
          className=" "
        >
          Skip
        </Button>
      </div>
    </>
  );
}
