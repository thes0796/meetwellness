'use client';

import { useEffect, useState } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { PiArrowRightBold } from 'react-icons/pi';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import toast from 'react-hot-toast';
import { Stepper, Textarea } from 'rizzui';
import { useAuth } from 'AuthContext';
import { useRouter } from 'next/navigation';
import { Onboard } from '@/services/apis/onboard';
import { useAppSelector } from '@/redux/redux-hooks';
import { Text } from '@/components/ui/text';
import logoImg from '@public/logo.svg';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import cn from '@/utils/class-names';
import { PiArrowLineRight } from 'react-icons/pi';
import { SUBSIDIARY } from '@/services/apis/subsidiaryAPI';
import { WORKERS } from '@/services/apis/workerAPI';
import { DatePicker } from '@/components/ui/datepicker';
import FormGroup from '@/app/shared/form-group';
import AvatarUpload from '@/components/ui/file-upload/avatar-upload';
import moment from 'moment';
import { LOGIN } from '@/services/apis/loginAPI';

type FormData = {
  first_name: string;
  middle_name: string;
  last_name: string;
  title: string;
  gender: string;
  date_of_birth: string;
  street_address: string;
  address_line_2: string;
  town: string;
  postcode: string;
  borough: string;
  is_eligible: boolean;
  ni_number: string;
  country_of_birth: string;
  profile_pic: string;
};

type Option = {
  label: string;
  value: string;
};

export default function SignUpForm() {
  const route = useRouter();
  const { user, user_id } = useAuth();
  console.log('user', user_id, user);
  const loginResponse = useAppSelector((state) => state?.loginDetails);
  console.log('loginResponse::: ', loginResponse);

  const [loading, setLoading] = useState(false);
  const [dateOfBirth, setDateOfBirth] = useState(new Date());
  const [branchId, setBranchId] = useState(null);

  useEffect(() => {
    if (!loginResponse?.loginData || loginResponse?.loginData?.length === 0) {
      route.back();
    }
  }, []);

  const workerDetails = async () => {
    const { data: response } = await WORKERS.getWorkersList(user);
    const workerData = response?.data?.data_list[0];
    setValue('first_name', workerData?.workers?.first_name);
    setValue('middle_name', workerData?.workers?.middle_name);
    setValue('last_name', workerData?.workers?.last_name);
    setValue('gender', workerData?.workers?.gender);
    setValue('street_address', workerData?.workers?.address?.street_address);
    setValue('address_line_2', workerData?.workers?.address?.address_line_2);
    setValue('town', workerData?.workers?.address?.town);
    setValue('postcode', workerData?.workers?.address?.postcode);
    setValue('borough', workerData?.workers?.address?.borough);
  };

  useEffect(() => {
    workerDetails();
  }, []);

  const {
    register,
    watch,
    handleSubmit,
    formState: { errors },
    getValues,
    setValue,
    reset,
  } = useForm<FormData>();

  const onSubmit: SubmitHandler<FormData> = async (data) => {
    try {
      setLoading(true);
      const workerData = {
        first_name: data.first_name,
        middle_name: data.middle_name,
        last_name: data.last_name,
        title: data.title,
        gender: data.gender,
        date_of_birth: moment(dateOfBirth).format('YYYY-MM-DD'),
        street_address: data.street_address,
        address_line_2: data.address_line_2,
        town: data.town,
        postcode: data.postcode,
        borough: data.borough,
        is_eligible: false,
        // ni_number: null,
        country_of_birth: data.country_of_birth,
        profile_pic: data.profile_pic,
      };
      const { data: response } = await WORKERS.updateWorkers(workerData, user);
      if (response) {
        const { data: response } = await LOGIN.setOnboarding(user);
        if (data) {
          toast.success(response?.message_key);
          reset();
          route.push('/profile');
        }
      }
      setLoading(false);
    } catch (error: any) {
      console.log('error::: ', error);
      toast.error(error?.response?.data?.message_key);
      setLoading(false);
    }
  };

  function AuthNavLink({
    href,
    children,
  }: React.PropsWithChildren<{
    href: string;
  }>) {
    const pathname = usePathname();
    function isActive(href: string) {
      if (pathname === href) {
        return true;
      }
      return false;
    }

    return (
      <Link
        href={href}
        className={cn(
          'inline-flex items-center gap-x-1 rounded-3xl p-2 py-1 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200 md:px-4 md:py-2.5 [&>svg]:w-4 [&>svg]:text-gray-500',
          isActive(href)
            ? 'bg-gray-100 text-gray-900 [&>svg]:text-gray-900'
            : ' '
        )}
      >
        {children}
      </Link>
    );
  }
  console.log('dateOfBirth', dateOfBirth);
  return (
    <>
      <header className="flex items-center justify-between p-4 lg:px-16 lg:py-6 2xl:px-24">
        <Link href={'/'}>
          <Image src={logoImg} className="dark:invert" priority alt="qwe" />
        </Link>

        <div className="flex items-center space-x-2 md:space-x-4">
          <AuthNavLink href={'/'}>
            <PiArrowLineRight className="h-4 w-4" />
            <span>Dashboard</span>
          </AuthNavLink>
        </div>
      </header>
      <div className="m-auto w-full max-w-xl">
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col gap-x-4 gap-y-5 px-4 md:grid md:grid-cols-2 lg:gap-5"
        >
          <>
            <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
              Worker Details
            </Text>
            <FormGroup
              title="Profile Photo"
              description="This will be displayed on your profile."
              className="col-span-2 flex w-full items-center justify-evenly pt-7 text-center @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
            >
              <div className="col-span-2 flex flex-col items-center gap-4 @xl:flex-row">
                <AvatarUpload
                  name="profile_pic"
                  setValue={setValue}
                  getValues={getValues}
                  // error={errors?.profile_pic}
                />
              </div>
            </FormGroup>
            <Input
              type="text"
              size="lg"
              label="Title"
              placeholder="Mr. / Mrs."
              className="font-medium"
              inputClassName="text-sm"
              {...register('title', {
                required: 'Title is required',
              })}
              error={errors.title?.message}
            />
            <Input
              type="text"
              size="lg"
              label="First Name"
              placeholder="Enter the first name"
              className="font-medium"
              inputClassName="text-sm"
              {...register('first_name', {
                required: 'First Name is required',
              })}
              error={errors.first_name?.message}
            />
            <Input
              type="text"
              size="lg"
              label="Middle Name"
              placeholder="Enter the middle name"
              className="font-medium"
              inputClassName="text-sm"
              {...register('middle_name', {
                required: 'Middle Name is required',
              })}
              error={errors.middle_name?.message}
            />
            <Input
              type="text"
              size="lg"
              label="Last Name"
              placeholder="Enter the last name"
              className="font-medium"
              inputClassName="text-sm"
              {...register('last_name', {
                required: 'Last Name is required',
              })}
              error={errors.last_name?.message}
            />
            <Input
              type="text"
              size="lg"
              label="Gender"
              placeholder="Enter your gender"
              className="font-medium"
              inputClassName="text-sm"
              {...register('gender', {
                required: 'Gender is required',
              })}
              error={errors.gender?.message}
            />
            <div className="space-y-1.5">
              <Text>Date of Birth</Text>
              <DatePicker
                selected={dateOfBirth}
                onChange={(e: Date) => {
                  setDateOfBirth(e);
                }}
                startDate={new Date()}
                endDate={new Date()}
                dateFormat="dd/MM/yyyy"
                placeholderText="Select Date"
                inputProps={{
                  variant: 'text',
                  inputClassName:
                    'p-[23px] pe-2 border-gray-300 [&_input]:text-ellipsis',
                }}
                maxDate={new Date()}
              />
            </div>
            <Textarea
              label="Street address"
              placeholder="Write you address"
              className="col-span-2 font-medium"
              {...register('street_address', {
                required: 'Street address is required',
              })}
              error={errors.street_address?.message}
            />
            <Input
              type="text"
              size="lg"
              label="Address line 2"
              placeholder="Enter your address line 2"
              className="col-span-2 font-medium"
              inputClassName="text-sm"
              {...register('address_line_2', {
                required: 'Address line 2  is required',
              })}
              error={errors.address_line_2?.message}
            />
            <Input
              type="text"
              size="lg"
              label="Borough"
              placeholder="Enter the borough"
              className="font-medium"
              inputClassName="text-sm"
              {...register('borough', {
                required: 'Borough  is required',
              })}
              error={errors.borough?.message}
            />
            <Input
              type="text"
              size="lg"
              label="Town"
              placeholder="Enter your town name"
              className="font-medium"
              inputClassName="text-sm"
              {...register('town', {
                required: 'Town name is required',
              })}
              error={errors.town?.message}
            />
            <Input
              type="number"
              size="lg"
              label="Postcode"
              placeholder="Enter your postcode"
              className="font-medium"
              inputClassName="text-sm"
              {...register('postcode', {
                required: 'Postcode is required',
              })}
              error={errors.town?.message}
            />
            <Input
              type="text"
              size="lg"
              label="Country"
              placeholder="Enter your country"
              className="font-medium"
              inputClassName="text-sm"
              {...register('country_of_birth', {
                required: 'Country is required',
              })}
              error={errors.country_of_birth?.message}
            />
          </>

          <Button
            disabled={loading}
            isLoading={loading}
            size="lg"
            type="submit"
            className="col-span-2 mb-14 mt-2"
          >
            <span>Submit</span>
            <PiArrowRightBold className="ms-2 mt-0.5 h-5 w-5" />
          </Button>
        </form>
      </div>
      <div className="fixed bottom-0 flex w-full items-center justify-end gap-10 px-5 pb-3">
        <Button
          onClick={() => {
            route.push('/profile');
          }}
          className=" "
        >
          Skip
        </Button>
      </div>
    </>
  );
}
