'use client';

import { useEffect, useState } from 'react';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { PiArrowRightBold } from 'react-icons/pi';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import toast from 'react-hot-toast';
import { Stepper, Textarea } from 'rizzui';
import { useAuth } from 'AuthContext';
import { useRouter } from 'next/navigation';
import { Onboard } from '@/services/apis/onboard';
import { useAppSelector } from '@/redux/redux-hooks';
import { Text } from '@/components/ui/text';
import logoImg from '@public/logo.svg';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import cn from '@/utils/class-names';
import { PiArrowLineRight } from 'react-icons/pi';
import { DatePicker } from '@/components/ui/datepicker';
import { Label } from 'recharts';
import { LOGIN } from '@/services/apis/loginAPI';
import FormGroup from '@/app/shared/form-group';
import AvatarUpload from '@/components/ui/file-upload/avatar-upload';
import { PhoneNumber } from '@/components/ui/phone-input';
import { CLIENTS } from '@/services/apis/clientAPI';

type FormData = {
  client_name: string;
  trading_name: string;
  main_contact: string;
  email: string;
  phone_number: string;
  street_address: string;
  town: string;
  postcode: string;
  client_unique_name: string;
  company_number: string;
  vat_number: string;
  main_contact_dial_code: string;
  profile_pic: string;
  role: string;
  user_name: string;
  email_address: string;
  phone: string;
  name: string;
  client_id: string;
  branch_name: string;
  branch_unique_name: string;
  job_title: string;
  job_description: string;
  number_of_positions: string;
  required_skills: string;
  employment_duration: string;
  special_requirements: string;
  start_date: string;
  address_line_2: string;
  borough: string;
  country: string;
  website: string;
  sur_name: string;
};
type Option = {
  label: string;
  value: string;
};

export default function SignUpForm() {
  const route = useRouter();
  const { user, user_id } = useAuth();
  const loginResponse = useAppSelector((state) => state?.loginDetails);

  const [stepOnboard, setStepOnboard] = useState(1);
  const [loading, setLoading] = useState(false);
  const [valueSelect, setValueSelect] = useState(null);
  const [clientId, setClientId] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneDialCode, setPhoneDialCode] = useState('');
  const [mainNumber, setMainNumber] = useState('');
  const [mainDialCode, setMainDialCode] = useState('');
  const [phoneNumberProfile, setPhoneNumberProfile] = useState('');
  const [phoneDialCodeProfile, setPhoneDialCodeProfile] = useState('');

  const handleChange = (value: any, country: any) => {
    const phoneNumber = value.replace(country.dialCode, '');
    setPhoneNumber(phoneNumber);
    setPhoneDialCode(country.dialCode);
  };

  const handleChangeMainPhone = (value: any, country: any) => {
    const phoneNumber = value.replace(country.dialCode, '');
    setMainNumber(phoneNumber);
    setMainDialCode(country.dialCode);
  };

  const handleChangeProfile = (value: any, country: any) => {
    const phoneNumber = value.replace(country.dialCode, '');
    setPhoneNumberProfile(phoneNumber);
    setPhoneDialCodeProfile(country.dialCode);
  };

  const {
    control,
    register,
    watch,
    handleSubmit,
    formState: { errors },
    getValues,
    setValue,
    reset,
  } = useForm<FormData>();

  const getUserById = async () => {
    setLoading(true);
    try {
      const response = await CLIENTS.getClientDetailById(user_id, user);
      if (response?.data?.status === 'SUCCESS') {
        setValue('name', response?.data?.data?.rows?.[0]?.first_name);
        setValue('sur_name', response?.data?.data?.rows?.[0]?.last_name);
        setValue(
          'email_address',
          response?.data?.data?.rows?.[0]?.email_address
        );
      }
    } catch (error: any) {
      toast.error(error?.response?.data?.message_key);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (user_id && stepOnboard === 1) {
      getUserById();
    }
  }, [user_id]);

  useEffect(() => {
    if (!loginResponse?.loginData || loginResponse?.loginData?.length === 0) {
      route.back();
    }
  }, []);

  // Filled field validation with Button
  const fields = watch();
  // const [isEveryFieldFilled, setIsEveryFieldFilled] = useState(false);
  // const checkIfEveryFieldFilled = () => {
  //   const areAllFilled = Object.values(fields).every((value) => !!value);
  //   setIsEveryFieldFilled(areAllFilled);
  // };
  // useEffect(() => {
  //   checkIfEveryFieldFilled();
  // }, [fields]);

  const onSubmit: SubmitHandler<FormData> = async (data) => {
    try {
      setLoading(true);
      // Steps
      if (stepOnboard === 1) {
        const profileData = {
          email_address: data.email_address,
          name: `${data.name} ${data.sur_name}`,
          phone: phoneNumberProfile,
          profile_pic: data.profile_pic,
          phone_dial_code: phoneDialCodeProfile,
        };
        const { data: response } = await Onboard.addClientContact(
          profileData,
          user
        );
        if (response) {
          toast.success(response?.message_key);
          setStepOnboard(2);
          reset();
        }
        setLoading(false);
      } else if (stepOnboard === 2) {
        const payload = {
          ...data,
          phone_number_dial_code: phoneDialCode,
          phone_number: phoneNumber,
          main_contact: mainNumber,
          main_contact_dial_code: mainDialCode,
        };
        const { data: response } = await Onboard.createAdminClient(payload);
        if (response) {
          const { data: response } = await LOGIN.setOnboarding(user);
          if (data) {
            setClientId(response?.data?.client_id);
            toast.success(response?.message_key);
            setStepOnboard(2);
            route.push('/profile');
            reset();
          }
        }
        setLoading(false);
      }
      //  else if (stepOnboard === 3) {
      //   data.client_id = clientId;
      //   const { data: response } = await Onboard.inviteClient(data);
      //   if (response) {
      //     toast.success(response?.message_key);
      //     setStepOnboard(4);
      //     reset();
      //   }
      //   setLoading(false);
      // } else if (stepOnboard === 4) {
      //   const { data: response } = await Onboard.addSubsidiary(data);
      //   if (response) {
      //     toast.success(response?.message_key);
      //     setStepOnboard(5);
      //     reset();
      //   }
      //   setLoading(false);
      // } else if (stepOnboard === 5) {
      //   const { data: response } = await Onboard.inviteServiceProvider(data);
      //   if (response) {
      //     toast.success(response?.message_key);
      //     setStepOnboard(5);
      //     route.push('/profile');
      //   }
      //   setLoading(false);
      // }
    } catch (error: any) {
      console.log('error::: ', error);
      toast.error(error?.response?.data?.message_key);
      setLoading(false);
    }
  };

  function AuthNavLink({
    href,
    children,
  }: React.PropsWithChildren<{
    href: string;
  }>) {
    const pathname = usePathname();
    function isActive(href: string) {
      if (pathname === href) {
        return true;
      }
      return false;
    }

    return (
      <Link
        href={href}
        className={cn(
          'inline-flex items-center gap-x-1 rounded-3xl p-2 py-1 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200 md:px-4 md:py-2.5 [&>svg]:w-4 [&>svg]:text-gray-500',
          isActive(href)
            ? 'bg-gray-100 text-gray-900 [&>svg]:text-gray-900'
            : ' '
        )}
      >
        {children}
      </Link>
    );
  }

  return (
    <>
      <header className="flex items-center justify-between p-4 lg:px-16 lg:py-6 2xl:px-24">
        <Link href={'/'}>
          <Image src={logoImg} className="dark:invert" priority alt="qwe" />
        </Link>
        {stepOnboard !== 1 && (
          <div className="flex items-center space-x-2 md:space-x-4">
            <AuthNavLink href={'/'}>
              <PiArrowLineRight className="h-4 w-4" />
              <span>Dashboard</span>
            </AuthNavLink>
          </div>
        )}
      </header>
      <div className="sm: mx-auto mt-4 w-full max-w-3xl sm:mt-28">
        <Stepper
          currentIndex={stepOnboard - 1}
          className="mx-auto mb-5 flex max-w-sm flex-wrap gap-2 sm:w-full "
        >
          <Stepper.Step title="Step 1" />
          <Stepper.Step title="Step 2" />
          {/* <Stepper.Step title="Step 3" />
          <Stepper.Step title="Step 4" />
          <Stepper.Step title="Step 5" />
          <Stepper.Step title="Step 6" /> */}
        </Stepper>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col gap-x-4 gap-y-5 px-4 md:grid md:grid-cols-2 lg:gap-5"
        >
          {stepOnboard === 1 && (
            <>
              <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
                Create profile
              </Text>
              <FormGroup
                title="Profile Photo"
                description="This will be displayed on your profile."
                className="col-span-2 flex w-full items-center justify-evenly pt-7 text-center @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <div className="col-span-2 flex flex-col items-center gap-4 @xl:flex-row">
                  <AvatarUpload
                    name="profile_pic"
                    setValue={setValue}
                    getValues={getValues}
                    // error={errors?.profile_pic}
                  />
                </div>
              </FormGroup>

              <Input
                type="text"
                size="lg"
                label="Name"
                placeholder="Enter your name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('name', {
                  required: 'Name is required',
                })}
                error={errors.name?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Surname"
                placeholder="Enter your surname"
                className="font-medium"
                inputClassName="text-sm"
                {...register('sur_name', {
                  required: 'Surname is required',
                })}
                error={errors.user_name?.message}
              />
              <Input
                type="email"
                size="lg"
                label="Email"
                className="col-span-2 font-medium"
                inputClassName="text-sm"
                placeholder="Enter your email"
                {...register('email_address', {
                  required: 'Email is required',
                })}
                error={errors.email_address?.message}
              />
              {/* <Input
                type="number"
                size="lg"
                label="Phone number"
                placeholder="Enter your phone number"
                className="font-medium"
                inputClassName="text-sm"
                {...register('phone', {
                  required: 'Phone number is required',
                })}
                error={errors.phone?.message}
              /> */}
              <Controller
                name="phone"
                control={control}
                render={({ field: { value, onChange } }) => (
                  <PhoneNumber
                    label="Phone number"
                    error={errors?.phone?.message}
                    country="gb"
                    value={value}
                    onChange={(value, country) =>
                      handleChangeProfile(value, country)
                    }
                    className="rtl:[&>.selected-flag]:right-0"
                    inputClassName="rtl:pr-12 p-[23px]"
                    buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                  />
                )}
              />
              <Input
                type="text"
                size="lg"
                label="Role"
                placeholder="Enter your Role"
                className="font-medium"
                inputClassName="text-sm"
                {...register('role', {
                  required: 'Role is required',
                })}
                error={errors.role?.message}
              />
            </>
          )}

          {stepOnboard === 2 && (
            <>
              <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
                Create Client profile
              </Text>
              <FormGroup
                title="Profile Photo"
                description="This will be displayed on your profile."
                className="col-span-2 flex w-full items-center justify-evenly pt-7 text-center @2xl:pt-9 @3xl:grid-cols-12 @3xl:pt-11"
              >
                <div className="col-span-2 flex flex-col items-center gap-4 @xl:flex-row">
                  <AvatarUpload
                    name="profile_pic"
                    setValue={setValue}
                    getValues={getValues}
                    // error={errors?.profile_pic}
                  />
                </div>
              </FormGroup>
              <Input
                type="text"
                size="lg"
                label="Client Name"
                placeholder="Enter your name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('client_name', {
                  required: 'Client name is required',
                })}
                error={errors.client_name?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Trading name"
                placeholder="Enter your user name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('trading_name', {
                  required: 'Trading name is required',
                })}
                error={errors.trading_name?.message}
              />
              <Input
                type="email"
                size="lg"
                label="Company Email"
                className="col-span-2 font-medium"
                inputClassName="text-sm"
                placeholder="Enter your email"
                {...register('email', {
                  required: 'Email is required',
                })}
                error={errors.email?.message}
                required
              />
              {/* <Input
                type="number"
                size="lg"
                label="Main contact"
                placeholder="Enter your contact number"
                className="font-medium"
                inputClassName="text-sm"
                {...register('main_contact', {
                  required: 'Contact number is required',
                })}
                error={errors.main_contact?.message}
              /> */}
              <Controller
                name="main_contact"
                control={control}
                render={({ field: { value, onChange } }) => (
                  <PhoneNumber
                    label="Main contact"
                    error={errors?.main_contact?.message}
                    country="gb"
                    value={value}
                    onChange={(value, country) =>
                      handleChangeMainPhone(value, country)
                    }
                    className="rtl:[&>.selected-flag]:right-0"
                    inputClassName="rtl:pr-12 p-[23px]"
                    buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                  />
                )}
              />
              <Controller
                name="phone_number"
                control={control}
                render={({ field: { value, onChange } }) => (
                  <PhoneNumber
                    label="Phone number"
                    error={errors?.phone_number?.message}
                    country="gb"
                    value={value}
                    onChange={(value, country) => handleChange(value, country)}
                    className="rtl:[&>.selected-flag]:right-0"
                    inputClassName="rtl:pr-12 p-[23px]"
                    buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                  />
                )}
              />
              {/* <Input
                type="number"
                size="lg"
                label="Phone number"
                placeholder="Enter your phone number"
                className="font-medium"
                inputClassName="text-sm"
                {...register('phone_number', {
                  required: 'Phone number is required',
                })}
                error={errors.phone_number?.message}
              /> */}
              <Input
                type="text"
                size="lg"
                label="Client unique name"
                placeholder="Enter your client unique name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('client_unique_name', {
                  required: 'Client unique name is required',
                })}
                error={errors.client_unique_name?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Company number"
                placeholder="Enter your company name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('company_number', {
                  required: 'Company number is required',
                })}
                error={errors.company_number?.message}
              />
              {/* <Input
                type="text"
                size="lg"
                label="Vat number"
                placeholder="Enter your vat number"
                className="font-medium"
                inputClassName="text-sm"
                {...register('vat_number', {
                  required: 'Vat number is required',
                })}
                error={errors.vat_number?.message}
              /> */}
              <Textarea
                label="Street address"
                placeholder="Write you address"
                className="col-span-2 font-medium"
                {...register('street_address', {
                  required: 'Street address is required',
                })}
                error={errors.street_address?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Address line 2"
                placeholder="Enter your address line 2"
                className="col-span-2 font-medium"
                inputClassName="text-sm"
                {...register('address_line_2', {
                  required: 'Address line 2  is required',
                })}
                error={errors.address_line_2?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Town"
                placeholder="Enter your town name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('town', {
                  required: 'Town name is required',
                })}
                error={errors.town?.message}
              />
              <Input
                type="number"
                size="lg"
                label="Postcode"
                placeholder="Enter your postcode"
                className="font-medium"
                inputClassName="text-sm"
                {...register('postcode', {
                  required: 'Postcode is required',
                })}
                error={errors.postcode?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Borough"
                placeholder="Enter the borough"
                className="font-medium"
                inputClassName="text-sm"
                {...register('borough', {
                  required: 'Borough  is required',
                })}
                error={errors.borough?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Country"
                placeholder="Enter the country"
                className="font-medium"
                inputClassName="text-sm"
                {...register('country', {
                  required: 'Country is required',
                })}
                error={errors.country?.message}
              />
              {/* <Input
                type="text"
                size="lg"
                label="Website"
                placeholder="Enter the Website"
                className="col-span-2 font-medium"
                inputClassName="text-sm"
                {...register('website', {
                  required: 'Website  is required',
                })}
                error={errors.website?.message}
              /> */}
            </>
          )}

          {/* {stepOnboard === 3 && (
            <>
              <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
                Invite Team Members
              </Text>
              <Input
                type="text"
                size="lg"
                label="Name"
                placeholder="Enter your name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('name', {
                  required: 'Name is required',
                })}
                error={errors.name?.message}
              />
              <Input
                type="text"
                size="lg"
                label="User Name"
                placeholder="Enter your username"
                className="font-medium"
                inputClassName="text-sm"
                {...register('user_name', {
                  required: 'User name is required',
                })}
                error={errors.user_name?.message}
              />
              <Input
                type="email"
                size="lg"
                label="Email"
                className="font-medium"
                inputClassName="text-sm"
                placeholder="Enter your email"
                {...register('email_address', {
                  required: 'Email is required',
                })}
                error={errors.email_address?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Phone number"
                placeholder="Enter your phone number"
                className="font-medium"
                inputClassName="text-sm"
                {...register('phone', {
                  required: 'Phone number is required',
                })}
                error={errors.phone?.message}
              />
            </>
          )}

          {stepOnboard === 4 && (
            <>
              <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
                Add Subsidiary
              </Text>
              <Input
                type="text"
                size="lg"
                label="Branch Name"
                placeholder="Enter your branch name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('branch_name', {
                  required: 'Branch name is required',
                })}
                error={errors.branch_name?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Branch unique name"
                placeholder="Enter your branch unique name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('branch_unique_name', {
                  required: 'Branch unique name is required',
                })}
                error={errors.branch_unique_name?.message}
              />
              <Input
                type="email"
                size="lg"
                label="Email"
                className="font-medium"
                inputClassName="text-sm"
                placeholder="Enter your email"
                {...register('email', {
                  required: 'Email is required',
                })}
                error={errors.email?.message}
              />
              <Controller
                name="phone_number"
                control={control}
                render={({ field: { value, onChange } }) => (
                  <PhoneNumber
                    label="Phone Number"
                    // error={errors?.phone}
                    country="gb"
                    value={value}
                    onChange={(value, country) => handleChange(value, country)}
                    className="rtl:[&>.selected-flag]:right-0"
                    inputClassName="rtl:pr-12 p-[23px]"
                    buttonClassName="rtl:[&>.selected-flag]:right-2 rtl:[&>.selected-flag_.arrow]:-left-6"
                  />
                )}
              />
              <Textarea
                label="Street address"
                placeholder="Write you address"
                className="col-span-2 font-medium"
                {...register('street_address', {
                  required: 'Street address is required',
                })}
                error={errors.street_address?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Town"
                placeholder="Enter your town name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('town', {
                  required: 'Town name is required',
                })}
                error={errors.town?.message}
              />
              <Input
                type="number"
                size="lg"
                label="Postcode"
                placeholder="Enter your postcode"
                className="font-medium"
                inputClassName="text-sm"
                {...register('postcode', {
                  required: 'Postcode is required',
                })}
                error={errors.town?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Country"
                placeholder="Enter the country"
                className="font-medium"
                inputClassName="text-sm"
                {...register('country', {
                  required: 'Country is required',
                })}
                error={errors.country?.message}
              />
            </>
          )}

          {stepOnboard === 5 && (
            <>
              <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
                Invite Service Provider
              </Text>
              <Input
                type="email"
                size="lg"
                label="Email"
                className="font-medium"
                inputClassName="text-sm"
                placeholder="Enter your email"
                {...register('email', {
                  required: 'Email is required',
                })}
                error={errors.email?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Full Name"
                placeholder="Enter your full name"
                className="font-medium"
                inputClassName="text-sm"
                {...register('name', {
                  required: 'Full name is required',
                })}
                error={errors.name?.message}
              />
              <Input
                type="number"
                size="lg"
                label="Phone number"
                placeholder="Enter your phone number"
                className="font-medium"
                inputClassName="text-sm"
                {...register('phone', {
                  required: 'Phone number is required',
                })}
                error={errors.phone?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Role"
                placeholder="Enter your Role"
                className="font-medium"
                inputClassName="text-sm"
                {...register('role', {
                  required: 'Role is required',
                })}
                error={errors.role?.message}
              />
            </>
          )}

          {stepOnboard === 6 && (
            <>
              <Text className="col-span-2 pt-3 text-center text-xl text-gray-700">
                Request worker
              </Text>
              <Input
                type="text"
                size="lg"
                label="Job Title"
                className="col-span-2 font-medium"
                inputClassName="text-sm"
                placeholder="Enter the job title"
                {...register('job_title', {
                  required: 'Job Title is required',
                })}
                error={errors.job_title?.message}
                required
              />

              <Textarea
                label="Job Description"
                placeholder="Write Job Description"
                className="col-span-2 font-medium"
                {...register('job_description', {
                  required: 'Street address is required',
                })}
                error={errors.job_description?.message}
              />
              <Input
                type="number"
                size="lg"
                label="Number of Positions"
                placeholder="Enter number of Positions"
                className="font-medium"
                inputClassName="text-sm"
                {...register('number_of_positions', {
                  required: 'Number of Positions is required',
                })}
                error={errors.number_of_positions?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Required Skills"
                placeholder="Enter Required Skills"
                className="font-medium"
                inputClassName="text-sm"
                {...register('required_skills', {
                  required: 'Required Skills is required',
                })}
                error={errors.required_skills?.message}
              />
              <div className="space-y-1.5">
                <Text>Start Date</Text>
                <DatePicker
                  selected={new Date()}
                  onChange={() => {}}
                  startDate={new Date()}
                  endDate={new Date()}
                  dateFormat="dd/MM/yyyy"
                  placeholderText="Select Date in a Range"
                  inputProps={{
                    variant: 'text',
                    inputClassName:
                      'p-[23px] pe-2 border-gray-300 [&_input]:text-ellipsis',
                  }}
                />
              </div>
              <Input
                type="text"
                size="lg"
                label="Employment Duration"
                placeholder="Enter employment duration"
                className="font-medium"
                inputClassName="text-sm"
                {...register('employment_duration', {
                  required: 'Employment Duration is required',
                })}
                error={errors.employment_duration?.message}
              />
              <Input
                type="text"
                size="lg"
                label="Special Requirements"
                placeholder="Enter special requirements"
                className="col-span-2 font-medium"
                inputClassName="text-sm"
                {...register('special_requirements', {
                  required: 'Special Requirements is required',
                })}
                error={errors.special_requirements?.message}
              />
            </>
          )} */}

          <Button
            disabled={loading}
            isLoading={loading}
            size="lg"
            type="submit"
            className="col-span-2 mb-14 mt-2"
          >
            {stepOnboard === 1 ? (
              <span>Save & Next</span>
            ) : stepOnboard === 2 ? (
              <span>Submit</span>
            ) : (
              <span>Next</span>
            )}
            <PiArrowRightBold className="ms-2 mt-0.5 h-5 w-5" />
          </Button>
        </form>
      </div>
      <div className="fixed bottom-0 flex w-full items-center justify-between gap-10 px-5 pb-3">
        <Button
          disabled={stepOnboard === 1 || stepOnboard === 2}
          onClick={() => {
            setStepOnboard(stepOnboard - 1);
            reset();
          }}
          className=" "
        >
          Back
        </Button>
        <Button
          disabled={stepOnboard === 1}
          onClick={() => {
            if (stepOnboard === 2) {
              route.push('/profile');
            } else {
              setStepOnboard(stepOnboard + 1);
              reset();
            }
          }}
          className=" "
        >
          Skip
        </Button>
      </div>
    </>
  );
}
