import Timesheet from '@/app/shared/time-sheet';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Timesheet'),
};

export default function TimesheetPage() {
  return <Timesheet />;
}
