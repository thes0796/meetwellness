import SubsidiaryComponent from '@/app/shared/subsidiary';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('subsidiary'),
};

export default function ClientsPage() {
  return <SubsidiaryComponent />;
}

