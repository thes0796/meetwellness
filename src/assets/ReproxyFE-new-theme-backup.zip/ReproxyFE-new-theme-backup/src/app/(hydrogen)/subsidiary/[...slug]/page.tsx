import AddSubsidiaryComponent from '@/app/shared/subsidiary/new/new-subsidiary';
import { metaObject } from '@/config/site.config';
// import MultiStepFormPage from '@/app/multi-step/page'
// import MultiStepFormPage from '@/app/multi-step/form-two/page'

export const metadata = {
  ...metaObject('Service Provider'),
};

export default function AddClientsPage() {
  return <AddSubsidiaryComponent />;
}
