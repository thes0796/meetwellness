import AddClientComponent from '@/app/shared/clients/new/new-client';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Client'),
};

export default function AddClientsPage() {
  return <AddClientComponent />;
}
