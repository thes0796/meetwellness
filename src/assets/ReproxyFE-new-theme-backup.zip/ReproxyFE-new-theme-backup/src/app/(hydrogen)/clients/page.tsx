import ClientsComponent from '@/app/shared/clients';
import ClientForm from '@/app/shared/clients/new/components/add-client-form';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Clients'),
};

export default function ClientsPage() {
  return <ClientsComponent />;
}

