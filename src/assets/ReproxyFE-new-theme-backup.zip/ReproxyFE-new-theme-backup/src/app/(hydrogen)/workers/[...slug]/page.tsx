import WorkersComponent from '@/app/shared/workers';
import WorkerForm from '@/app/shared/workers/new/components/new-worker-form';
import AddWorkerCOmponent from '@/app/shared/workers/new/newWorker';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Add Worker'),
};

export default function AddWorkersPage() {
  return <AddWorkerCOmponent />;
}
