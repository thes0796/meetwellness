import WorkersComponent from '@/app/shared/workers';
import WorkerForm from '@/app/shared/workers/new/components/new-worker-form';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Workers'),
};

export default function WorkersPage() {
  return <WorkersComponent />;
}

