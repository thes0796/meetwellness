import AddSPComponent from '@/app/shared/service-provider/new/new-service-provider';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Service Provider'),
};

export default function AddClientsPage() {
  return <AddSPComponent />;
}
