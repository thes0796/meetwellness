import ServiceProviderComponent from '@/app/shared/service-provider';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('service-provider'),
};

export default function ClientsPage() {
  return <ServiceProviderComponent />;
}

