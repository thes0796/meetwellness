import Rota from '@/app/shared/rota';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Rota'),
};

export default function RotaPage() {
  return <Rota />;
}
