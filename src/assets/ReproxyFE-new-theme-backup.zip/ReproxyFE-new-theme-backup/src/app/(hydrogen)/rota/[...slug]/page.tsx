import RotaComponent from '@/app/shared/rota/page/rota';
import { metaObject } from '@/config/site.config';

export const metadata = {
  ...metaObject('Rota'),
};

export default function AddRotaPage() {
  return <RotaComponent title={''} />;
}
