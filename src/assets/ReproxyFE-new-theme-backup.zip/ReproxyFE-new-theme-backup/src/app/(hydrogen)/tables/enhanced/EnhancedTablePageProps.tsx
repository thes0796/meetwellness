export interface PageHeader {
  title: string;
  breadcrumb: {name: string}[];
}

export interface EnhancedTablePageProps {
  data: any[];
  myListData: any[],
  pageHeader: PageHeader;
  workersSettings: any[]; 
  setIsWorkerDeleted: (isDeleted: boolean) => void;
}