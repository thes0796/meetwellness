"use client"
import React, { useState, useEffect } from 'react'
import { routes } from '@/config/routes';
import { invoiceData } from '@/data/invoice-data';
import InvoiceTable from '@/app/shared/invoice/invoice-list/table';
import WorkersTable from '@/app/shared/workers/list/table'
import TableLayout from '../table-layout';
import { metaObject } from '@/config/site.config';
import { EnhancedTablePageProps } from './EnhancedTablePageProps';

// export const metadata = {
//   ...metaObject('Enhanced Table'),
// };

 export default function EnhancedTablePage({ 
  data,
  myListData,
  pageHeader,
  workersSettings,
  setIsWorkerDeleted
 }: EnhancedTablePageProps) {


  return (
    <TableLayout
      title={pageHeader.title}
      breadcrumb={pageHeader.breadcrumb}
      data={data}
      fileName="invoice_data"
      header="ID,Name,Username,Avatar,Email,Due Date,Amount,Status,Created At"
    >
      {myListData && myListData.length > 0 ?
        <WorkersTable data={myListData} workersSettings={workersSettings} setIsWorkerDeleted={setIsWorkerDeleted} />
        : 
        <p className='text-center leading-10 font-semibold text-lg'>No Data</p>
      }
    </TableLayout>
  );
}
