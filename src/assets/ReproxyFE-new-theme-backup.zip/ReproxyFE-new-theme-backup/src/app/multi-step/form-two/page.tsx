import MultiStepFormTwo from '@/app/shared/multi-step/multi-step-2';

export default function MultiStepFormPage() {
  return <MultiStepFormTwo />;
}
